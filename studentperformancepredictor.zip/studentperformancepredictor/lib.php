<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library functions for the Student Performance Predictor block.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Get the text representation of a risk level.
 * 
 * @param int $risklevel Risk level (1=low, 2=medium, 3=high)
 * @return string Text representation
 */
function block_studentperformancepredictor_get_risk_text($risklevel) {
    switch ($risklevel) {
        case 1:
            return get_string('lowrisk_label', 'block_studentperformancepredictor');
        case 2:
            return get_string('mediumrisk_label', 'block_studentperformancepredictor');
        case 3:
            return get_string('highrisk_label', 'block_studentperformancepredictor');
        default:
            return get_string('unknownrisk', 'block_studentperformancepredictor');
    }
}

/**
 * Get the CSS class for a risk level.
 * 
 * @param int $risklevel Risk level (1=low, 2=medium, 3=high)
 * @return string CSS class
 */
function block_studentperformancepredictor_get_risk_class($risklevel) {
    switch ($risklevel) {
        case 1:
            return 'spp-risk-low';
        case 2:
            return 'spp-risk-medium';
        case 3:
            return 'spp-risk-high';
        default:
            return 'spp-risk-unknown';
    }
}

/**
 * Get the most recent prediction for a student in a course.
 * 
 * @param int $courseid Course ID
 * @param int $userid User ID
 * @return object|false Prediction record or false if none
 */
function block_studentperformancepredictor_get_student_prediction($courseid, $userid) {
    global $DB;
    $sql = "SELECT p.* FROM {block_spp_predictions} p 
            WHERE p.courseid = :courseid AND p.userid = :userid 
            ORDER BY p.timemodified DESC";
    return $DB->get_record_sql($sql, ['courseid' => $courseid, 'userid' => $userid]);
}

/**
 * Get suggestions for a prediction.
 * 
 * @param int $predictionid Prediction ID
 * @param int $limit Maximum number of suggestions to return
 * @return array Suggestion records
 */
function block_studentperformancepredictor_get_suggestions($predictionid, $limit = 5) {
    global $DB;
    $sql = "SELECT s.*, cm.id as cmid, cm.name as cmname, m.name as modulename
            FROM {block_spp_suggestions} s
            LEFT JOIN {course_modules} cm ON cm.id = s.cmid
            LEFT JOIN {modules} m ON m.id = cm.module
            WHERE s.predictionid = :predictionid
            ORDER BY s.priority DESC, s.timecreated ASC";
    return $DB->get_records_sql($sql, ['predictionid' => $predictionid], 0, $limit);
}

/**
 * Get risk statistics for a course.
 * 
 * @param int $courseid Course ID
 * @return object Statistics object with highrisk, mediumrisk, lowrisk, and total properties
 */
function block_studentperformancepredictor_get_course_risk_stats($courseid) {
    global $DB;
    $stats = new stdClass();
    $stats->highrisk = 0;
    $stats->mediumrisk = 0;
    $stats->lowrisk = 0;
    $stats->total = 0;

    // Get total number of students
    $context = context_course::instance($courseid);
    $students = get_enrolled_users($context, 'moodle/course:isincompletionreports');
    $stats->total = count($students);

    if ($stats->total === 0) {
        return $stats;
    }

    // Count students at each risk level
    $sql = "SELECT riskvalue, COUNT(*) as count 
            FROM {block_spp_predictions} 
            WHERE courseid = :courseid 
            GROUP BY riskvalue";
    $rs = $DB->get_records_sql($sql, ['courseid' => $courseid]);

    foreach ($rs as $row) {
        if ($row->riskvalue == 1) {
            $stats->lowrisk = $row->count;
        } else if ($row->riskvalue == 2) {
            $stats->mediumrisk = $row->count;
        } else if ($row->riskvalue == 3) {
            $stats->highrisk = $row->count;
        }
    }

    return $stats;
}

/**
 * Trigger a prediction refresh for a course.
 * 
 * @param int $courseid Course ID
 * @param int $userid Optional user ID who requested the refresh
 * @return bool Success
 */
function block_studentperformancepredictor_trigger_prediction_refresh($courseid, $userid = 0) {
    global $USER;

    // Use current user if not specified
    if (empty($userid)) {
        $userid = $USER->id;
    }

    // Queue an adhoc task to refresh predictions for the course
    $task = new \block_studentperformancepredictor\task\refresh_predictions();
    $task->set_custom_data([
        'courseid' => $courseid,
        'userid' => $userid,
        'timequeued' => time()
    ]);

    return \core\task\manager::queue_adhoc_task($task);
}

/**
 * Mark a suggestion as viewed
 *
 * @param int $suggestionid Suggestion ID
 * @return bool Success
 */
function block_studentperformancepredictor_mark_suggestion_viewed($suggestionid) {
    global $DB;
    return $DB->set_field('block_spp_suggestions', 'viewed', 1, ['id' => $suggestionid]);
}

/**
 * Mark a suggestion as completed
 *
 * @param int $suggestionid Suggestion ID
 * @return bool Success
 */
function block_studentperformancepredictor_mark_suggestion_completed($suggestionid) {
    global $DB;
    $suggestion = $DB->get_record('block_spp_suggestions', ['id' => $suggestionid]);
    if (!$suggestion) {
        return false;
    }
    $suggestion->viewed = 1; // Also mark as viewed
    $suggestion->completed = 1;
    return $DB->update_record('block_spp_suggestions', $suggestion);
}

/**
 * Checks if there is an active model for the given course.
 *
 * @param int $courseid Course ID
 * @return bool True if there is an active model
 */
function block_studentperformancepredictor_has_active_model($courseid) {
    global $DB;

    // First check if the trainstatus field exists
    $dbman = $DB->get_manager();
    $table = new xmldb_table('block_spp_models');
    $field = new xmldb_field('trainstatus');

    if ($dbman->table_exists($table) && $dbman->field_exists($table, $field)) {
        // If the field exists, use it in the query
        $params = ['courseid' => $courseid, 'active' => 1, 'trainstatus' => 'complete'];
        return $DB->record_exists('block_spp_models', $params);
    } else {
        // If the field doesn't exist, just check for active models
        $params = ['courseid' => $courseid, 'active' => 1];
        return $DB->record_exists('block_spp_models', $params);
    }
}

/**
 * Checks if the necessary database tables for the plugin exist.
 *
 * @return bool True if all required tables exist
 */
function block_studentperformancepredictor_tables_exist() {
    global $DB;
    $dbman = $DB->get_manager();

    $tables = [
        'block_spp_models',
        'block_spp_predictions',
        'block_spp_suggestions',
        'block_spp_datasets',
        'block_spp_training_log'
    ];

    foreach ($tables as $tablename) {
        $table = new xmldb_table($tablename);
        if (!$dbman->table_exists($table)) {
            return false;
        }
    }

    return true;
}

/**
 * Ensures the dataset directory for a course exists and is writable.
 *
 * @param int $courseid Course ID
 * @return string Path to the dataset directory
 * @throws moodle_exception if directory cannot be created or is not writable
 */
function block_studentperformancepredictor_ensure_dataset_directory($courseid) {
    global $CFG;

    $relpath = 'blocks_studentperformancepredictor' . DIRECTORY_SEPARATOR . 'datasets' . DIRECTORY_SEPARATOR . intval($courseid);
    $dirpath = make_upload_directory($relpath);

    if (!$dirpath || !is_dir($dirpath) || !is_writable($dirpath)) {
        throw new moodle_exception('directorynotwritable', 'block_studentperformancepredictor', '', $dirpath);
    }

    return $dirpath;
}

/**
 * Generates a prediction for a student in a course by calling the Python backend.
 *
 * @param int $courseid Course ID
 * @param int $userid User ID
 * @return int|false Prediction ID or false on failure
 */
function block_studentperformancepredictor_generate_prediction($courseid, $userid) {
    global $DB, $CFG;

    // Get the active model for the course
    $model = $DB->get_record('block_spp_models', ['courseid' => $courseid, 'active' => 1]);
    if (!$model) {
        debugging('No active model found for course ' . $courseid, DEBUG_DEVELOPER);
        return false;
    }

    // Call the Python backend for prediction
    $apiurl = get_config('block_studentperformancepredictor', 'python_api_url');
    if (empty($apiurl)) {
        $apiurl = 'http://localhost:5000/predict';
    }

    $apikey = get_config('block_studentperformancepredictor', 'python_api_key');
    if (empty($apikey)) {
        $apikey = 'changeme';
    }

    // Collect student data for prediction
    // Get basic student data
    $user = $DB->get_record('user', ['id' => $userid], 'id, firstname, lastname, email');

    // Get course engagement data
    $sql = "SELECT COUNT(*) FROM {logstore_standard_log} 
            WHERE userid = :userid AND courseid = :courseid 
            AND timecreated > :weekago";
    $logscount = $DB->count_records_sql($sql, [
        'userid' => $userid, 
        'courseid' => $courseid,
        'weekago' => time() - (7 * 24 * 3600) // Last week
    ]);

    // Get assignment submissions
    $sql = "SELECT COUNT(*) FROM {assign_submission} s
            JOIN {assign} a ON a.id = s.assignment
            WHERE s.userid = :userid AND a.course = :courseid";
    $submissioncount = $DB->count_records_sql($sql, [
        'userid' => $userid,
        'courseid' => $courseid
    ]);

    // Get grades
    $gradesum = 0;
    $gradecount = 0;
    $sql = "SELECT gg.finalgrade, gi.grademax
            FROM {grade_items} gi
            JOIN {grade_grades} gg ON gg.itemid = gi.id
            WHERE gi.courseid = :courseid AND gg.userid = :userid
            AND gg.finalgrade IS NOT NULL";
    $grades = $DB->get_records_sql($sql, [
        'courseid' => $courseid,
        'userid' => $userid
    ]);

    foreach ($grades as $grade) {
        if ($grade->grademax > 0) {
            $gradesum += ($grade->finalgrade / $grade->grademax);
            $gradecount++;
        }
    }

    $gradeavg = $gradecount > 0 ? $gradesum / $gradecount : 0;

    // Prepare data to send to backend
    $features = [
        $logscount,             // Activity level
        $submissioncount,       // Assignment submissions
        $gradeavg,              // Average grade percentage
        $gradecount             // Number of graded items
    ];

    // Create payload for backend
    $payload = [
        'model_id' => $model->modelid ?? null,
        'features' => $features
    ];

    // Send prediction request to backend
    $curl = new curl();
    $options = [
        'CURLOPT_TIMEOUT' => 60,
        'CURLOPT_RETURNTRANSFER' => true,
        'CURLOPT_HTTPHEADER' => [
            'Content-Type: application/json',
            'X-API-Key: ' . $apikey
        ]
    ];

    $response = $curl->post($apiurl, json_encode($payload), $options);
    $httpcode = $curl->get_info()['http_code'] ?? 0;

    if ($httpcode === 200) {
        $result = json_decode($response, true);

        // Check if we have a valid response
        if (!$result || !isset($result['prediction'])) {
            debugging('Invalid response from prediction backend: ' . $response, DEBUG_DEVELOPER);
            return false;
        }

        // Calculate risk level based on prediction
        $passprob = isset($result['probabilities']) && is_array($result['probabilities']) 
            ? max($result['probabilities']) 
            : ($result['prediction'] == 1 ? 0.75 : 0.25);

        // Determine risk level based on pass probability
        $lowrisk = get_config('block_studentperformancepredictor', 'lowrisk');
        if (empty($lowrisk)) {
            $lowrisk = 0.7; // Default
        }

        $mediumrisk = get_config('block_studentperformancepredictor', 'mediumrisk');
        if (empty($mediumrisk)) {
            $mediumrisk = 0.4; // Default
        }

        if ($passprob >= $lowrisk) {
            $riskvalue = 1; // Low risk
        } else if ($passprob >= $mediumrisk) {
            $riskvalue = 2; // Medium risk
        } else {
            $riskvalue = 3; // High risk
        }

        // Save prediction to database
        $prediction = new stdClass();
        $prediction->courseid = $courseid;
        $prediction->userid = $userid;
        $prediction->modelid = $model->id;
        $prediction->passprob = $passprob;
        $prediction->riskvalue = $riskvalue;
        $prediction->predictiondata = json_encode($result);
        $prediction->timecreated = time();
        $prediction->timemodified = time();

        $id = $DB->insert_record('block_spp_predictions', $prediction);

        // Generate suggestions based on the prediction
        if ($id) {
            block_studentperformancepredictor_generate_suggestions($id, $courseid, $userid, $riskvalue);
        }

        return $id;
    } else {
        debugging('Prediction backend error: HTTP ' . $httpcode . ' - ' . $response, DEBUG_DEVELOPER);
        return false;
    }
}

/**
 * Generate suggestions based on a prediction.
 *
 * @param int $predictionid Prediction ID
 * @param int $courseid Course ID
 * @param int $userid User ID
 * @param int $risklevel Risk level (1=low, 2=medium, 3=high)
 * @return bool Success
 */
function block_studentperformancepredictor_generate_suggestions($predictionid, $courseid, $userid, $risklevel) {
    global $DB;

    // Get course modules for potential suggestions
    $modinfo = get_fast_modinfo($courseid);

    // Limit to certain module types based on risk level
    $suggestedModules = [];

    if ($risklevel == 3) { // High risk
        $suggestedModules = ['quiz', 'assign', 'resource', 'forum', 'workshop'];
    } else if ($risklevel == 2) { // Medium risk
        $suggestedModules = ['quiz', 'assign', 'resource', 'forum'];
    } else { // Low risk
        $suggestedModules = ['forum', 'resource'];
    }

    // Find suitable modules
    $suggestions = [];
    $count = 0;

    foreach ($modinfo->cms as $cm) {
        if (!$cm->uservisible || !in_array($cm->modname, $suggestedModules)) {
            continue;
        }

        // Check if user has already viewed/completed this module
        $completion = new completion_info(get_course($courseid));
        if ($completion->is_enabled($cm) && $completion->get_data($cm, false, $userid)->completionstate == COMPLETION_COMPLETE) {
            continue; // Skip already completed modules
        }

        // Generate appropriate suggestion reason
        $reason = '';
        switch ($cm->modname) {
            case 'quiz':
                $reason = get_string('suggestion_quiz_' . ($risklevel == 3 ? 'high' : ($risklevel == 2 ? 'medium' : 'low')), 
                                   'block_studentperformancepredictor');
                break;
            case 'assign':
                $reason = get_string('suggestion_assign_' . ($risklevel == 3 ? 'high' : ($risklevel == 2 ? 'medium' : 'low')), 
                                   'block_studentperformancepredictor');
                break;
            case 'forum':
                $reason = get_string('suggestion_forum_' . ($risklevel == 3 ? 'high' : ($risklevel == 2 ? 'medium' : 'low')), 
                                   'block_studentperformancepredictor');
                break;
            case 'resource':
                $reason = get_string('suggestion_resource_' . ($risklevel == 3 ? 'high' : ($risklevel == 2 ? 'medium' : 'low')), 
                                   'block_studentperformancepredictor');
                break;
            case 'workshop':
                $reason = get_string('suggestion_workshop_high', 'block_studentperformancepredictor');
                break;
        }

        // Set priority based on risk level and module type
        $priority = 5; // Default
        if ($risklevel == 3) {
            $priority += 5; // High risk
            if ($cm->modname == 'quiz' || $cm->modname == 'assign') {
                $priority += 2; // Critical modules for high risk
            }
        } else if ($risklevel == 2) {
            $priority += 3; // Medium risk
        }

        // Create suggestion record
        $suggestion = new stdClass();
        $suggestion->predictionid = $predictionid;
        $suggestion->courseid = $courseid;
        $suggestion->userid = $userid;
        $suggestion->cmid = $cm->id;
        $suggestion->resourcetype = $cm->modname;
        $suggestion->resourceid = $cm->instance;
        $suggestion->priority = $priority;
        $suggestion->reason = $reason;
        $suggestion->timecreated = time();
        $suggestion->viewed = 0;
        $suggestion->completed = 0;

        $suggestions[] = $suggestion;
        $count++;

        // Limit to 3 module suggestions
        if ($count >= 3) {
            break;
        }
    }

    // Add general study suggestion based on risk level
    $generalSuggestion = new stdClass();
    $generalSuggestion->predictionid = $predictionid;
    $generalSuggestion->courseid = $courseid;
    $generalSuggestion->userid = $userid;
    $generalSuggestion->cmid = 0; // No specific course module
    $generalSuggestion->resourcetype = 'general';
    $generalSuggestion->resourceid = 0;
    $generalSuggestion->timecreated = time();
    $generalSuggestion->viewed = 0;
    $generalSuggestion->completed = 0;

    if ($risklevel == 3) {
        $generalSuggestion->reason = get_string('suggestion_instructor_help', 'block_studentperformancepredictor');
        $generalSuggestion->priority = 9;
    } else if ($risklevel == 2) {
        $generalSuggestion->reason = get_string('suggestion_engagement', 'block_studentperformancepredictor');
        $generalSuggestion->priority = 7;
    } else {
        $generalSuggestion->reason = get_string('suggestion_time_management', 'block_studentperformancepredictor');
        $generalSuggestion->priority = 5;
    }

    $suggestions[] = $generalSuggestion;

    // Insert all suggestions
    foreach ($suggestions as $suggestion) {
        $DB->insert_record('block_spp_suggestions', $suggestion);
    }

    return true;
}

/**
 * Refresh predictions via backend for all students in a course
 *
 * @param int $courseid The course ID
 * @return array Result with success count and errors
 */
function block_studentperformancepredictor_refresh_predictions_via_backend($courseid) {
    global $DB;

    $context = context_course::instance($courseid);
    $students = get_enrolled_users($context, 'moodle/course:isincompletionreports');

    $success = 0;
    $errors = 0;

    foreach ($students as $student) {
        try {
            $predictionid = block_studentperformancepredictor_generate_prediction($courseid, $student->id);
            if ($predictionid) {
                $success++;
            } else {
                $errors++;
            }
        } catch (Exception $e) {
            $errors++;
            debugging('Error generating prediction for student ' . $student->id . ': ' . $e->getMessage(), DEBUG_DEVELOPER);
        }
    }

    // Update the last refresh time
    set_config('lastrefresh_' . $courseid, time(), 'block_studentperformancepredictor');

    return [
        'success' => $success,
        'errors' => $errors,
        'total' => count($students)
    ];
}

/**
 * Train a model via the Python backend API
 *
 * @param int $courseid Course ID
 * @param int $datasetid Dataset ID
 * @param string|null $algorithm Algorithm type (optional)
 * @return int|false Model ID or false on failure
 */
function block_studentperformancepredictor_train_model_via_backend($courseid, $datasetid, $algorithm = null) {
    global $DB, $USER;

    // Verify dataset exists
    if (!$DB->record_exists('block_spp_datasets', ['id' => $datasetid, 'courseid' => $courseid])) {
        debugging('Dataset not found: ' . $datasetid, DEBUG_DEVELOPER);
        return false;
    }

    // Get API configuration
    $apiurl = get_config('block_studentperformancepredictor', 'python_api_url');
    if (empty($apiurl)) {
        $apiurl = 'http://localhost:5000/train';
    }

    $apikey = get_config('block_studentperformancepredictor', 'python_api_key');
    if (empty($apikey)) {
        $apikey = 'changeme';
    }

    // Prepare training request
    $payload = [
        'courseid' => $courseid,
        'datasetid' => $datasetid,
        'algorithm' => $algorithm,
        'userid' => $USER->id
    ];

    // Call the Python backend
    $curl = new curl();
    $options = [
        'CURLOPT_TIMEOUT' => 300, // 5 minutes, training can take time
        'CURLOPT_RETURNTRANSFER' => true,
        'CURLOPT_HTTPHEADER' => [
            'Content-Type: application/json',
            'X-API-Key: ' . $apikey
        ]
    ];

    $response = $curl->post($apiurl, json_encode($payload), $options);
    $httpcode = $curl->get_info()['http_code'] ?? 0;

    if ($httpcode === 200) {
        $result = json_decode($response, true);

        // Check if we have a valid response
        if (!$result || !isset($result['model_id'])) {
            debugging('Invalid response from training backend: ' . $response, DEBUG_DEVELOPER);
            return false;
        }

        // Create new model record
        $model = new stdClass();
        $model->courseid = $courseid;
        $model->datasetid = $datasetid;
        $model->modelname = isset($algorithm) ? ucfirst($algorithm) . ' Model' : 'Prediction Model';
        $model->modelname .= ' ' . date('Y-m-d');
        $model->algorithmtype = $result['algorithm'] ?? $algorithm ?? 'randomforest';
        $model->accuracy = isset($result['metrics']['accuracy']) ? $result['metrics']['accuracy'] : 0;
        $model->modelid = $result['model_id'];
        $model->modelpath = $result['model_path'] ?? '';
        $model->active = 0; // Not active by default
        $model->trainstatus = 'complete';
        $model->usermodified = $USER->id;
        $model->timecreated = time();
        $model->timemodified = time();

        // Store metrics if available
        if (isset($result['metrics'])) {
            $model->featureslist = json_encode($result['metrics']);
        } else {
            $model->featureslist = '[]';
        }

        $modelid = $DB->insert_record('block_spp_models', $model);

        return $modelid;
    } else {
        debugging('Training backend error: HTTP ' . $httpcode . ' - ' . $response, DEBUG_DEVELOPER);
        return false;
    }
}