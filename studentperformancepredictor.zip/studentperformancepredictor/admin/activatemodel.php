<?php
// This file is part of Moodle - http://moodle.org/
/**
 * Activate a trained model for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 */
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/moodlelib.php');
require_once($CFG->libdir . '/tablelib.php');
require_once($CFG->libdir . '/weblib.php');
require_login();
$context = context_system::instance();
require_capability('block/studentperformancepredictor:managemodels', $context);
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/activatemodel.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('activatemodel', 'block_studentperformancepredictor'));
$PAGE->set_heading(get_string('activatemodel', 'block_studentperformancepredictor'));

global $DB, $OUTPUT;

// Only show models grouped by course, and allow activation/deactivation per course
$courseid = optional_param('courseid', 0, PARAM_INT);
if ($courseid) {
    $models = $DB->get_records('block_spp_models', ['courseid' => $courseid]);
} else {
    $models = $DB->get_records('block_spp_models', []);
}

if (optional_param('modelid', 0, PARAM_INT) && confirm_sesskey()) {
    $modelid = required_param('modelid', PARAM_INT);
    $courseid = required_param('courseid', PARAM_INT);
    $model = $DB->get_record('block_spp_models', ['id' => $modelid], '*', MUST_EXIST);
    // Deactivate all models for this course
    $DB->set_field('block_spp_models', 'active', 0, ['courseid' => $model->courseid]);
    // Activate selected model
    $DB->set_field('block_spp_models', 'active', 1, ['id' => $modelid]);
    redirect(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]), get_string('modelactivated', 'block_studentperformancepredictor'), 2);
}

if (optional_param('deactivate', 0, PARAM_INT) && confirm_sesskey()) {
    $courseid = required_param('courseid', PARAM_INT);
    // Deactivate all models for this course
    $DB->set_field('block_spp_models', 'active', 0, ['courseid' => $courseid]);
    redirect(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]), get_string('modeldeactivated', 'block_studentperformancepredictor'), 2);
}

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('activatemodel', 'block_studentperformancepredictor'));

$table = new html_table();
$table->head = [
    get_string('modelid', 'block_studentperformancepredictor'),
    get_string('modelname', 'block_studentperformancepredictor'),
    get_string('courseid'),
    get_string('accuracy', 'block_studentperformancepredictor'),
    get_string('active', 'block_studentperformancepredictor'),
    get_string('actions')
];
$table->data = [];
foreach ($models as $model) {
    $isactive = $model->active ? get_string('yes') : get_string('no');
    $actions = '';
    if (!$model->active) {
        $activateurl = new moodle_url('/blocks/studentperformancepredictor/admin/activatemodel.php', [
            'modelid' => $model->id,
            'courseid' => $model->courseid,
            'sesskey' => sesskey()
        ]);
        $actions = html_writer::link($activateurl, get_string('activate', 'block_studentperformancepredictor'), ['class' => 'btn btn-sm btn-primary']);
    } else {
        $deactivateurl = new moodle_url('/blocks/studentperformancepredictor/admin/activatemodel.php', [
            'deactivate' => 1,
            'courseid' => $model->courseid,
            'sesskey' => sesskey()
        ]);
        $actions = html_writer::link($deactivateurl, get_string('deactivate', 'block_studentperformancepredictor'), ['class' => 'btn btn-sm btn-secondary']);
    }
    $table->data[] = [
        $model->id,
        format_string($model->modelname ?? ('Model ' . $model->id)),
        $model->courseid,
        isset($model->accuracy) ? round($model->accuracy * 100, 2) . '%' : '-',
        $isactive,
        $actions
    ];
}
echo html_writer::table($table);
echo $OUTPUT->footer();