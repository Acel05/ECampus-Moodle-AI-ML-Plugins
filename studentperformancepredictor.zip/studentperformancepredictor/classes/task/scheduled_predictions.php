<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
* Scheduled task for refreshing predictions periodically.
*
* @package    block_studentperformancepredictor
* @copyright  2023 Your Name <[Email]>
* @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/

namespace block_studentperformancepredictor\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Task to periodically refresh predictions.
 */
class scheduled_predictions extends \core\task\scheduled_task {
    /**
     * Get a descriptive name for this task.
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_scheduled_predictions', 'block_studentperformancepredictor');
    }

    /**
     * Execute the task.
     */
    public function execute() {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

        mtrace("Starting scheduled prediction refresh task");

        // Find courses with active models
        $courses = $DB->get_records_sql(
            "SELECT DISTINCT c.id, c.fullname 
            FROM {course} c 
            JOIN {block_spp_models} m ON m.courseid = c.id 
            WHERE m.active = 1"
        );

        if (empty($courses)) {
            mtrace("No courses with active models found");
            return;
        }

        mtrace("Found " . count($courses) . " courses with active models");

        foreach ($courses as $course) {
            mtrace("Processing course: " . $course->fullname . " (ID: " . $course->id . ")");

            try {
                $context = \context_course::instance($course->id);
                $students = get_enrolled_users($context, 'moodle/course:isincompletionreports');

                $success = 0;
                $errors = 0;

                foreach ($students as $student) {
                    try {
                        $predictionid = block_studentperformancepredictor_generate_prediction($course->id, $student->id);

                        if ($predictionid) {
                            $success++;
                        } else {
                            $errors++;
                        }
                    } catch (\Exception $e) {
                        $errors++;
                        mtrace("Error generating prediction for student ID " . $student->id . ": " . $e->getMessage());
                    }
                }

                // Update the last refresh time for this course
                set_config('lastrefresh_' . $course->id, time(), 'block_studentperformancepredictor');

                mtrace("Completed predictions for course ID " . $course->id . ": " . $success . " successful, " . $errors . " errors");
            } catch (\Exception $e) {
                mtrace("Error processing course ID " . $course->id . ": " . $e->getMessage());
            }
        }

        mtrace("Scheduled prediction refresh completed");
    }
}