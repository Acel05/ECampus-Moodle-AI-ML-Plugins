<?php
// blocks/studentperformancepredictor/admin/viewdataset.php

require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters
$id = required_param('id', PARAM_INT);
$courseid = required_param('courseid', PARAM_INT);

// Set up page
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Get dataset
$dataset = $DB->get_record('block_spp_datasets', array('id' => $id, 'courseid' => $courseid), '*', MUST_EXIST);

// Set up page layout
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/viewdataset.php', array('id' => $id, 'courseid' => $courseid)));
$PAGE->set_context($context);
$PAGE->set_title(get_string('datasetname', 'block_studentperformancepredictor') . ': ' . $dataset->name);
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_pagelayout('standard');

// Output starts here
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('datasetname', 'block_studentperformancepredictor') . ': ' . format_string($dataset->name));

// Display dataset details
$table = new html_table();
$table->attributes['class'] = 'generaltable';
$table->head = array(
    get_string('datasetproperty', 'block_studentperformancepredictor'),
    get_string('datasetvalue', 'block_studentperformancepredictor')
);
$table->data = array();

$table->data[] = array(get_string('datasetname', 'block_studentperformancepredictor'), format_string($dataset->name));
$table->data[] = array(get_string('datasetdescription', 'block_studentperformancepredictor'), $dataset->description ? format_text($dataset->description) : '');
$table->data[] = array(get_string('datasetformat', 'block_studentperformancepredictor'), $dataset->fileformat);
$table->data[] = array(get_string('uploaded', 'block_studentperformancepredictor'), userdate($dataset->timecreated));

// Display columns
$columns = json_decode($dataset->columns);
if ($columns && is_array($columns) && count($columns) > 0) {
    $columnlist = html_writer::start_tag('ul');
    foreach ($columns as $column) {
        $columnlist .= html_writer::tag('li', s($column));
    }
    $columnlist .= html_writer::end_tag('ul');
    $table->data[] = array(get_string('columns', 'block_studentperformancepredictor'), $columnlist);
}

echo html_writer::table($table);

// Add a "Back" button
echo ' ';
echo html_writer::link(
    new moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', 
        array('courseid' => $courseid)),
    get_string('back', 'core'),
    array('class' => 'btn btn-secondary')
);
echo html_writer::end_div();

// Output footer
echo $OUTPUT->footer();