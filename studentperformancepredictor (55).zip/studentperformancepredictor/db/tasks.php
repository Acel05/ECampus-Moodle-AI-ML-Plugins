<?php
// blocks/studentperformancepredictor/db/tasks.php

defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => 'block_studentperformancepredictor\task\scheduled_predictions',
        'blocking' => 0,
        'minute' => '0',
        'hour' => '0', 
        'day' => '*/7', // Run once a week instead of every 6 hours
        'month' => '*',
        'dayofweek' => '0', // Sunday
        'disabled' => 0,
    ],
];