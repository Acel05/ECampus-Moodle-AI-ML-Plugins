// blocks/studentperformancepredictor/amd/src/prediction_viewer.js

define(['jquery', 'core/ajax', 'core/notification', 'core/modal_factory', 'core/modal_events', 'core/str'],
function($, Ajax, Notification, ModalFactory, ModalEvents, Str) {
    /**
     * Initialize suggestion management and prediction features.
     */
    var init = function() {
        // This function will initialize all event listeners when the page loads.

        // Handle marking suggestions as viewed
        $(document).on('click', '.spp-mark-viewed', function(e) {
            e.preventDefault();
            var button = $(this);
            var suggestionId = button.data('id');
            if (!suggestionId) {
                return;
            }
            button.prop('disabled', true);
            Ajax.call([{
                methodname: 'block_studentperformancepredictor_mark_suggestion_viewed',
                args: { suggestionid: suggestionId },
                done: function(response) {
                    if (response.status) {
                        Str.get_string('viewed', 'block_studentperformancepredictor').done(function(s) {
                            button.replaceWith('<span class="badge bg-secondary">' + s + '</span>');
                        });
                    } else {
                        Notification.addNotification({ message: response.message, type: 'error' });
                        button.prop('disabled', false);
                    }
                },
                fail: Notification.exception
            }]);
        });

        // Handle marking suggestions as completed
        $(document).on('click', '.spp-mark-completed', function(e) {
            e.preventDefault();
            var button = $(this);
            var suggestionId = button.data('id');
            if (!suggestionId) {
                return;
            }
            button.prop('disabled', true);
            Ajax.call([{
                methodname: 'block_studentperformancepredictor_mark_suggestion_completed',
                args: { suggestionid: suggestionId },
                done: function(response) {
                    if (response.status) {
                        Str.get_string('completed', 'block_studentperformancepredictor').done(function(s) {
                            button.replaceWith('<span class="badge bg-success">' + s + '</span>');
                        });
                    } else {
                        Notification.addNotification({ message: response.message, type: 'error' });
                        button.prop('disabled', false);
                    }
                },
                fail: Notification.exception
            }]);
        });

        // Handle teacher refresh predictions button
        $(document).on('click', '.spp-refresh-predictions', function(e) {
            e.preventDefault();
            var button = $(this);
            var courseId = button.data('course-id');

            if (!courseId) {
                Notification.addNotification({ message: 'Course ID not found.', type: 'error' });
                return;
            }

            button.prop('disabled', true);

            Str.get_strings([
                {key: 'refreshconfirmation', component: 'block_studentperformancepredictor'},
                {key: 'refresh', component: 'block_studentperformancepredictor'},
                {key: 'cancel', component: 'core'}
            ]).done(function(strings) {
                ModalFactory.create({
                    type: ModalFactory.types.SAVE_CANCEL,
                    title: strings[0],
                    body: strings[0]
                }).done(function(modal) {
                    modal.setSaveButtonText(strings[1]);
                    modal.getRoot().on(ModalEvents.save, function() {
                        Ajax.call([{
                            methodname: 'block_studentperformancepredictor_refresh_predictions',
                            args: { courseid: courseId },
                            done: function(response) {
                                if (response.status) {
                                    Notification.addNotification({ message: response.message, type: 'success' });
                                    setTimeout(function() {
                                        window.location.reload();
                                    }, 1500);
                                } else {
                                    Notification.addNotification({ message: response.message, type: 'error' });
                                    button.prop('disabled', false);
                                }
                            },
                            fail: function(ex) {
                                Notification.exception(ex);
                                button.prop('disabled', false);
                            }
                        }]);
                    });
                    modal.getRoot().on(ModalEvents.cancel, function() {
                        button.prop('disabled', false);
                    });
                    modal.show();
                });
            }).fail(Notification.exception);
        });

        // Handle student generate prediction and teacher/admin update prediction buttons
        $(document).on('click', '.spp-generate-prediction, .spp-update-prediction', function(e) {
            e.preventDefault();
            var button = $(this);
            var courseId = button.data('course-id');
            var userId = button.data('user-id');
            var originalText = button.html();
            
            button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' + originalText);

            // Using Moodle's core/ajax web service for the request.
            Ajax.call([{
                methodname: 'block_studentperformancepredictor_generate_student_prediction',
                args: {
                    courseid: courseId,
                    userid: userId
                },
                done: function(response) {
                    if (response.success) {
                        Notification.addNotification({ message: response.message, type: 'success' });
                        // Reload the page to show the new prediction data.
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    } else {
                        Notification.addNotification({ message: response.message, type: 'error' });
                        button.prop('disabled', false).html(originalText);
                    }
                },
                fail: function(ex) {
                    Notification.exception(ex);
                    button.prop('disabled', false).html(originalText);
                }
            }]);
        });
    };

    return {
        init: init
    };
});