<?php
// blocks/studentperformancepredictor/db/services.php

defined('MOODLE_INTERNAL') || die();

$functions = [
    // Mark a suggestion as viewed by the student.
    'block_studentperformancepredictor_mark_suggestion_viewed' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'mark_suggestion_viewed',
        'description' => 'Mark a suggestion as viewed by the student.',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:view',
    ],
    // Mark a suggestion as completed by the student.
    'block_studentperformancepredictor_mark_suggestion_completed' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'mark_suggestion_completed',
        'description' => 'Mark a suggestion as completed by the student.',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:view',
    ],
    // Get predictions for a student in a course.
    'block_studentperformancepredictor_get_student_predictions' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'get_student_predictions',
        'description' => 'Get predictions for a student in a course.',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:view',
    ],
    // Trigger model training for a course.
    'block_studentperformancepredictor_trigger_model_training' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'trigger_model_training',
        'description' => 'Trigger model training for a course.',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:managemodels',
    ],
    // Refresh predictions for a course.
    'block_studentperformancepredictor_refresh_predictions' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'refresh_predictions',
        'description' => 'Refresh predictions for a course.',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:viewallpredictions',
    ],
    // Generate a new prediction for a student.
    'block_studentperformancepredictor_generate_student_prediction' => [
        'classname'   => 'block_studentperformancepredictor\external\api',
        'methodname'  => 'generate_student_prediction',
        'description' => 'Generates a new performance prediction for a specific student.',
        'type'        => 'write',
        'ajax'        => true,
        'capabilities'=> 'block/studentperformancepredictor:view',
    ],
];

$services = [
    'Student Performance Predictor' => [
        'functions' => [
            'block_studentperformancepredictor_mark_suggestion_viewed',
            'block_studentperformancepredictor_mark_suggestion_completed',
            'block_studentperformancepredictor_get_student_predictions',
            'block_studentperformancepredictor_trigger_model_training',
            'block_studentperformancepredictor_refresh_predictions',
            'block_studentperformancepredictor_generate_student_prediction',
        ],
        'restrictedusers' => 0,
        'enabled' => 1,
        'shortname' => 'studentperformancepredictor',
        'downloadfiles' => 0,
    ],
];