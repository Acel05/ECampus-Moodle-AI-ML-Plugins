<?php
// blocks/studentperformancepredictor/db/messages.php

defined('MOODLE_INTERNAL') || die();

$messageproviders = [
    'model_training_success' => [
        'defaults' => [
            'popup' => MESSAGE_PERMITTED + MESSAGE_DEFAULT_ENABLED,
            'email' => MESSAGE_PERMITTED + MESSAGE_DEFAULT_ENABLED
        ],
    ],
    'model_training_error' => [
        'defaults' => [
            'popup' => MESSAGE_PERMITTED + MESSAGE_DEFAULT_ENABLED,
            'email' => MESSAGE_PERMITTED + MESSAGE_DEFAULT_ENABLED
        ],
    ],
];