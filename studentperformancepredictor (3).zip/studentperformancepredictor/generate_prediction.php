<?php
// blocks/studentperformancepredictor/generate_prediction.php

require_once('../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get courseid as an optional parameter first to ensure the variable is always defined.
$courseid = optional_param('courseid', 0, PARAM_INT);

try {
    // Manually check for the required courseid. If it's missing, Moodle will throw a standard error.
    if (!$courseid) {
        throw new moodle_exception('missingparam', 'error', '', 'courseid');
    }

    $userid = optional_param('userid', $USER->id, PARAM_INT); // Default to current user

    // Set up page and context for permission checks
    $course = get_course($courseid);
    $context = context_course::instance($courseid);

    // Security checks
    require_login($course);
    require_sesskey();

    // Capability checks
    if ($USER->id == $userid) {
        require_capability('block/studentperformancepredictor:view', $context);
    } else {
        require_capability('block/studentperformancepredictor:viewallpredictions', $context);
    }

    // Generate a new prediction by calling the library function
    $prediction = block_studentperformancepredictor_generate_new_prediction($courseid, $userid);

    if ($prediction) {
        $redirecturl = new moodle_url('/course/view.php', ['id' => $courseid]);
        // After successfully generating the prediction, redirect the user back with a success message.
        redirect($redirecturl, get_string('predictiongenerated', 'block_studentperformancepredictor'), 2, \core\output\notification::NOTIFY_SUCCESS);
    } else {
        // The generate_new_prediction function returned false
        throw new moodle_exception('predictionerror', 'block_studentperformancepredictor');
    }

} catch (Exception $e) {
    // If any exception occurs, redirect with an error message.
    // This safely handles the redirect and prevents the "mutated session" error.
    $redirecturl = $courseid ? new moodle_url('/course/view.php', ['id' => $courseid]) : new moodle_url('/my/');
    redirect($redirecturl, $e->getMessage(), 5, \core\output\notification::NOTIFY_ERROR);
}