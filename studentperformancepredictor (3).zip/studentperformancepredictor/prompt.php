I have a plugin Student Performance Predictor for my moodle and here is the code and the directory of the plugin.
STUDENTPERFORMANCE
├── admin
│   ├── activatemodel.php
│   ├── ajax_delete_dataset.php
│   ├── ajax_refresh_predictions.php
│   ├── ajax_toggle_model.php
│   ├── managedatasets.php
│   ├── managemodels.php
│   ├── refreshpredictions.php
│   ├── train_model.php
│   ├── upload_dataset.php
│   ├── direct_train.php
│   ├── viewdataset.php
├── amd
│   ├── src
│       ├── admin_interface.js
│       ├── chart_renderer.js
│       ├── prediction_viewer.js
├── classes
│   ├── analytics
│       ├── data_preprocessor.php
│       ├── model_trainer.php
│       ├── predictor.php
│       ├── suggestion_generator.php
│       ├── training_manager.php
│   ├── event
│       ├── model_trained.php
│   ├── external
│       ├── api.php
│   ├── output
│       ├── renderer.php
│       ├── student_view.php
│       ├── teacher_view.php
│   ├── privacy
│       ├── provider.php
│   ├── task
│       ├── adhoc_train_model.php
│       ├── refresh_predictions.php
│       ├── scheduled_predictions.php
│       ├── train_model.php
├── datasets
│   ├── dataset_1.csv
├── db
│   ├── access.php
│   ├── install.xml
│   ├── services.php
│   ├── tasks.php
│   ├── upgrade.php
├── lang
│   ├──  en
│   ├──├── block_studentperformancepredictor.php
├── models
│   ├── 
├── pix
│   ├── icon.png
├── templates
│   ├── admin_settings.mustache
│   ├── prediction_details.mustache
│   ├── student_dashboard.mustache
│   ├── teacher_dashboard.mustache
.env
block_studentperformancepredictor.php
lib.php
ml_backend.py
README.md
reports.php
styles.css
version.php

That is the directory of the plugin and below is the code for each of the file above
<?php
// This file is part of Moodle - http://moodle.org/
/**
 * Activate a trained model for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 */
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/moodlelib.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php'); // Include lib.php for new functions
require_login();

global $DB, $OUTPUT, $USER; // Added $USER to global

// Get parameters
$courseid = required_param('courseid', PARAM_INT);
$modelid = optional_param('modelid', 0, PARAM_INT);
$deactivate = optional_param('deactivate', 0, PARAM_INT);
$sesskey = required_param('sesskey', PARAM_ALPHANUMEXT);

// Validate sesskey
require_sesskey($sesskey);

// Set up course context for capability check
$course = get_course($courseid);
$context = context_course::instance($courseid); // FIX: Changed from context_system::instance()
$PAGE->set_course($course); // Set course for the page context

// Check permissions within the specific course context
require_capability('block/studentperformancepredictor:managemodels', $context);

// Set up page layout for consistency, though this page primarily redirects
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/activatemodel.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('activatemodel', 'block_studentperformancepredictor'));
$PAGE->set_heading(format_string($course->fullname)); // Use course fullname as heading
$PAGE->set_pagelayout('admin'); // Use admin layout

if ($modelid && $deactivate === 0) { // Activate a model
    $model = $DB->get_record('block_spp_models', ['id' => $modelid], '*', MUST_EXIST);

    // Ensure model belongs to this course
    if ($model->courseid != $courseid) {
        \core\notification::error(get_string('modelnotincourse', 'block_studentperformancepredictor'));
        redirect(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]));
    }

    // Begin transaction
    $transaction = $DB->start_delegated_transaction();
    try {
        // Deactivate all other models for this course
        $DB->set_field('block_spp_models', 'active', 0, ['courseid' => $model->courseid]);

        // Activate selected model
        $DB->set_field('block_spp_models', 'active', 1, ['id' => $modelid]);

        // Trigger prediction refresh for the course using the new active model
        block_studentperformancepredictor_trigger_prediction_refresh($courseid, $USER->id);

        $transaction->allow_commit();
        \core\notification::success(get_string('modelactivated', 'block_studentperformancepredictor'));

    } catch (Exception $e) {
        $transaction->rollback();
        \core\notification::error(get_string('errorupdatingmodel', 'block_studentperformancepredictor') . ': ' . $e->getMessage());
        debugging('Model activation error: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
    redirect(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]));

} else if ($deactivate === 1) { // Deactivate all models for this course
    // Begin transaction
    $transaction = $DB->start_delegated_transaction();
    try {
        $DB->set_field('block_spp_models', 'active', 0, ['courseid' => $courseid]);
        $transaction->allow_commit();
        \core\notification::success(get_string('modeldeactivated', 'block_studentperformancepredictor'));
    } catch (Exception $e) {
        $transaction->rollback();
        \core\notification::error(get_string('errorupdatingmodel', 'block_studentperformancepredictor') . ': ' . $e->getMessage());
        debugging('Model deactivation error: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
    redirect(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]));

} else {
    // Invalid access or missing parameters, redirect with error
    \core\notification::error(get_string('invalidrequest', 'block_studentperformancepredictor'));
    redirect(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]));
}

// No HTML output required for this action page, as it always redirects.

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AJAX handler for deleting datasets.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);
require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Set up response
$response = array(
    'success' => false,
    'message' => ''
);

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = get_string('invalidrequest', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Get parameters
$courseid = required_param('courseid', PARAM_INT);
$datasetid = required_param('datasetid', PARAM_INT);

// Validate session key
require_sesskey();

// Set up context
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Get the dataset
$dataset = $DB->get_record('block_spp_datasets', array('id' => $datasetid), '*', MUST_EXIST);

// Ensure the dataset belongs to this course
if ($dataset->courseid != $courseid) {
    $response['message'] = get_string('datasetnotincourse', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Begin transaction
$transaction = $DB->start_delegated_transaction();
$success = true;
$error_message = '';

// Delete the dataset file
if (!empty($dataset->filepath) && file_exists($dataset->filepath)) {
    if (!unlink($dataset->filepath)) {
        $success = false;
        $error_message = get_string('filedeleteerror', 'block_studentperformancepredictor');
    }
}

// Delete the database record
if ($success) {
    if (!$DB->delete_records('block_spp_datasets', array('id' => $datasetid))) {
        $success = false;
        $error_message = get_string('databasedeleteerror', 'block_studentperformancepredictor');
    }
}

// Also delete all models trained from this dataset (for this course)
if ($success) {
    $models = $DB->get_records('block_spp_models', array('datasetid' => $datasetid, 'courseid' => $courseid));
    foreach ($models as $model) {
        // Optionally, delete model files from disk if stored
        if (!empty($model->modelpath) && file_exists($model->modelpath)) {
            @unlink($model->modelpath);
        }
        $DB->delete_records('block_spp_models', array('id' => $model->id));
    }
}

if ($success) {
    // Commit transaction
    $transaction->allow_commit();
    $response['success'] = true;
    $response['message'] = get_string('datasetdeleted', 'block_studentperformancepredictor');
} else {
    // Rollback transaction
    $transaction->rollback();
    $response['message'] = $error_message;
    debugging('Dataset deletion error: ' . $error_message, DEBUG_DEVELOPER);
}

// Return JSON response
echo json_encode($response);

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AJAX handler for refreshing predictions.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);
require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Set up response
$response = [
    'success' => false,
    'message' => ''
];

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = get_string('invalidrequest', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Get parameters
$courseid = required_param('courseid', PARAM_INT);

// Validate session key
require_sesskey();

// Set up context
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:viewallpredictions', $context);

// Check if there's an active model
if (!block_studentperformancepredictor_has_active_model($courseid)) {
    $response['message'] = get_string('noactivemodel', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Trigger prediction refresh: orchestrate backend prediction for all students
try {
    // This function should call the Python backend /predict endpoint for each student in the course
    // using the active model, and update the Moodle DB with the returned predictions/probabilities.
    block_studentperformancepredictor_trigger_prediction_refresh($courseid);
    $response['success'] = true;
    $response['message'] = get_string('predictionsrefreshqueued', 'block_studentperformancepredictor');
} catch (Exception $e) {
    $response['message'] = get_string('predictionsrefresherror', 'block_studentperformancepredictor') . ': ' . $e->getMessage();
    if (function_exists('debugging')) {
        debugging('Prediction refresh error: ' . $e->getMessage(), defined('DEBUG_DEVELOPER') ? DEBUG_DEVELOPER : 0);
    }
}

// Return JSON response (always backend-driven)
echo json_encode($response);

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AJAX handler for toggling model active status.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);
require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Set up response
$response = array(
    'success' => false,
    'message' => ''
);

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = get_string('invalidrequest', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Get parameters
$courseid = required_param('courseid', PARAM_INT);
$modelid = required_param('modelid', PARAM_INT);
$active = required_param('active', PARAM_INT);

// Validate session key
require_sesskey();

// Set up context
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Get the model
$model = $DB->get_record('block_spp_models', array('id' => $modelid), '*', MUST_EXIST);

// Ensure the model belongs to this course
if ($model->courseid != $courseid) {
    $response['message'] = get_string('modelnotincourse', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Begin transaction
$transaction = $DB->start_delegated_transaction();
$success = true;
$error_message = '';

// If activating this model, deactivate all other models for this course
if ($active) {
    $DB->set_field('block_spp_models', 'active', 0, array('courseid' => $courseid));
}

// Update this model's active status
$model->active = $active;
$model->timemodified = time();
$model->usermodified = $USER->id;

if (!$DB->update_record('block_spp_models', $model)) {
    $success = false;
    $error_message = get_string('errorupdatingmodel', 'block_studentperformancepredictor');
}

if ($success) {
    // If activating, trigger backend-driven prediction refresh for this course
    if ($active) {
        // This will call the Python backend /predict endpoint for all students using the new active model
        try {
            block_studentperformancepredictor_trigger_prediction_refresh($courseid);
        } catch (Exception $e) {
            // Log but do not fail activation if refresh fails
            if (function_exists('debugging')) {
                debugging('Prediction refresh error after model activation: ' . $e->getMessage(), defined('DEBUG_DEVELOPER') ? DEBUG_DEVELOPER : 0);
            }
        }
    }
    // Commit transaction
    $transaction->allow_commit();
    $response['success'] = true;
    if ($active) {
        $response['message'] = get_string('modelactivated', 'block_studentperformancepredictor');
    } else {
        $response['message'] = get_string('modeldeactivated', 'block_studentperformancepredictor');
    }
} else {
    // Rollback transaction
    $transaction->rollback();
    $response['message'] = $error_message;
    if (function_exists('debugging')) {
        debugging('Model toggle error: ' . $error_message, defined('DEBUG_DEVELOPER') ? DEBUG_DEVELOPER : 0);
    }
}

// Return JSON response
echo json_encode($response);

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
* Manage training datasets page for Student Performance Predictor.
*
* @package    block_studentperformancepredictor
* @copyright  2023 Your Name <your.email@example.com>
* @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/

require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters - use optional_param with default for global admin page
$courseid = optional_param('courseid', 0, PARAM_INT);

// If we don't have a courseid, but we're in the site admin section,
// redirect to course selection page
if ($courseid == 0) {
    // Display a list of courses to select from
    $PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php'));
    $PAGE->set_context(context_system::instance());
    $PAGE->set_title(get_string('managedatasets', 'block_studentperformancepredictor'));
    $PAGE->set_heading(get_string('managedatasets', 'block_studentperformancepredictor'));
    $PAGE->set_pagelayout('admin');

    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('selectcourse', 'block_studentperformancepredictor'));

    // Get courses where the user has appropriate capability
    $courses = [];
    $allcourses = get_courses();

    foreach ($allcourses as $course) {
        if ($course->id == SITEID) {
            continue;
        }
        $coursecontext = context_course::instance($course->id);
        if (has_capability('block/studentperformancepredictor:managemodels', $coursecontext)) {
            $courses[$course->id] = $course;
        }
    }

    if (empty($courses)) {
        echo $OUTPUT->notification(get_string('nocoursesavailable', 'block_studentperformancepredictor'), 'error');
    } else {
        $table = new html_table();
        $table->head = [
            get_string('coursename', 'block_studentperformancepredictor'),
            get_string('actions', 'block_studentperformancepredictor')
        ];

        foreach ($courses as $course) {
            $row = [];
            $row[] = format_string($course->fullname);
            $row[] = html_writer::link(
                new moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', 
                ['courseid' => $course->id]),
                get_string('managedatasets', 'block_studentperformancepredictor'),
                ['class' => 'btn btn-primary btn-sm']
            );
            $table->data[] = $row;
        }

        echo html_writer::table($table);
    }

    echo $OUTPUT->footer();
    exit;
}

// Set up page for a specific course
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Set up page layout
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('managedatasets', 'block_studentperformancepredictor'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_pagelayout('standard');

// Get all datasets for this course
$datasets = $DB->get_records('block_spp_datasets', ['courseid' => $courseid], 'timemodified DESC');

// Output starts here
echo $OUTPUT->header();

// Print heading
echo $OUTPUT->heading(get_string('managedatasets', 'block_studentperformancepredictor'));

// Initialize admin interface JavaScript
$PAGE->requires->js_call_amd('block_studentperformancepredictor/admin_interface', 'init', [$courseid]);

// Upload new dataset form
echo $OUTPUT->heading(get_string('uploadnewdataset', 'block_studentperformancepredictor'), 3);

$form = html_writer::start_tag('form', [
    'id' => 'spp-dataset-upload-form',
    'class' => 'mb-4',
    'enctype' => 'multipart/form-data',
    'method' => 'post',
    'action' => new moodle_url('/blocks/studentperformancepredictor/admin/upload_dataset.php')
]);

// Dataset name field
$form .= html_writer::start_div('form-group');
$form .= html_writer::label(get_string('datasetname', 'block_studentperformancepredictor'), 'dataset-name', true);
$form .= html_writer::empty_tag('input', ['type' => 'text', 'name' => 'dataset_name', 'id' => 'dataset-name', 'class' => 'form-control', 'required' => 'required']);
$form .= html_writer::end_div();

// Dataset description field
$form .= html_writer::start_div('form-group');
$form .= html_writer::label(get_string('datasetdescription', 'block_studentperformancepredictor'), 'dataset-description', false);
$form .= html_writer::tag('textarea', '', ['name' => 'dataset_description', 'id' => 'dataset-description', 'class' => 'form-control', 'rows' => 3]);
$form .= html_writer::end_div();

// Dataset file upload field
$form .= html_writer::start_div('form-group');
$form .= html_writer::label(get_string('datasetfile', 'block_studentperformancepredictor'), 'dataset-file', true);
$form .= html_writer::empty_tag('input', ['type' => 'file', 'name' => 'dataset_file', 'id' => 'dataset-file', 'class' => 'form-control-file', 'required' => 'required']);
$form .= html_writer::end_div();

// Dataset format field
$form .= html_writer::start_div('form-group');
$form .= html_writer::label(get_string('datasetformat', 'block_studentperformancepredictor'), 'dataset-format', true);
$form .= html_writer::start_tag('select', ['name' => 'dataset_format', 'id' => 'dataset-format', 'class' => 'form-control', 'required' => 'required']);
$form .= html_writer::tag('option', get_string('csvformat', 'block_studentperformancepredictor'), ['value' => 'csv']);
$form .= html_writer::tag('option', get_string('jsonformat', 'block_studentperformancepredictor'), ['value' => 'json']);
$form .= html_writer::end_tag('select');
$form .= html_writer::end_div();

// Hidden course ID field
$form .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'courseid', 'value' => $courseid]);
$form .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

// Submit button
$form .= html_writer::start_div('form-group');
$form .= html_writer::empty_tag('input', ['type' => 'submit', 'value' => get_string('upload', 'block_studentperformancepredictor'), 'class' => 'btn btn-primary']);
$form .= html_writer::end_div();

// Status display area
$form .= html_writer::div('', 'mt-3', ['id' => 'spp-upload-status']);

$form .= html_writer::end_tag('form');

echo $form;

// Existing datasets list
if (!empty($datasets)) {
    echo $OUTPUT->heading(get_string('existingdatasets', 'block_studentperformancepredictor'), 3);
    // Warn that deleting a dataset will also delete all models trained from it (backend-driven)
    echo $OUTPUT->notification(get_string('datasetdeletecascade', 'block_studentperformancepredictor'), 'info');

    $table = new html_table();
    $table->head = [
        get_string('datasetname', 'block_studentperformancepredictor'),
        get_string('datasetformat', 'block_studentperformancepredictor'),
        get_string('uploaded', 'block_studentperformancepredictor'),
        get_string('actions', 'block_studentperformancepredictor')
    ];

    foreach ($datasets as $dataset) {
        $row = [];
        $row[] = format_string($dataset->name);
        $row[] = format_string($dataset->fileformat);
        $row[] = userdate($dataset->timecreated);

        $actions = html_writer::link(
            new moodle_url('/blocks/studentperformancepredictor/admin/viewdataset.php', 
                ['id' => $dataset->id, 'courseid' => $courseid]), 
            get_string('view', 'block_studentperformancepredictor'),
            ['class' => 'btn btn-sm btn-secondary']
        );

        // Delete button triggers backend-driven cascade delete (dataset + models + files)
        $actions .= ' ' . html_writer::link('#', 
            get_string('delete', 'block_studentperformancepredictor'),
            [
                'class' => 'btn btn-sm btn-danger spp-delete-dataset', 
                'data-dataset-id' => $dataset->id,
                'title' => get_string('datasetdeletecascadetitle', 'block_studentperformancepredictor')
            ]
        );

        $row[] = $actions;
        $table->data[] = $row;
    }

    echo html_writer::table($table);
}

// Output footer
echo $OUTPUT->footer();

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
* Manage prediction models page for Student Performance Predictor.
*
* @package    block_studentperformancepredictor
* @copyright  2023 Your Name <your.email@example.com>
* @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/

require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');
require_once($CFG->libdir . '/tablelib.php'); // For html_table
require_once($CFG->libdir . '/weblib.php'); // For html_writer, s, get_string

// Get parameters - use optional_param with default for global admin page
$courseid = optional_param('courseid', 0, PARAM_INT);

// If we don't have a courseid, but we're in the site admin section, 
// redirect to course selection page
if ($courseid == 0) {
    // Display a list of courses to select from
    $PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php'));
    $PAGE->set_context(context_system::instance());
    $PAGE->set_title(get_string('managemodels', 'block_studentperformancepredictor'));
    $PAGE->set_heading(get_string('managemodels', 'block_studentperformancepredictor'));
    $PAGE->set_pagelayout('admin');

    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('selectcourse', 'block_studentperformancepredictor'));

    // Get courses where the user has appropriate capability
    $courses = [];
    $allcourses = get_courses();

    foreach ($allcourses as $course) {
        if ($course->id == SITEID) {
            continue;
        }
        $coursecontext = context_course::instance($course->id);
        if (has_capability('block/studentperformancepredictor:managemodels', $coursecontext)) {
            $courses[$course->id] = $course;
        }
    }

    if (empty($courses)) {
        echo $OUTPUT->notification(get_string('nocoursesavailable', 'block_studentperformancepredictor'), 'error');
    } else {
        $table = new html_table();
        $table->head = [
            get_string('coursename', 'block_studentperformancepredictor'),
            get_string('actions', 'block_studentperformancepredictor')
        ];

        foreach ($courses as $course) {
            $row = [];
            $row[] = format_string($course->fullname);
            $row[] = html_writer::link(
                new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', 
                ['courseid' => $course->id]),
                get_string('managemodels', 'block_studentperformancepredictor'),
                ['class' => 'btn btn-primary btn-sm']
            );
            $table->data[] = $row;
        }

        echo html_writer::table($table);
    }

    echo $OUTPUT->footer();
    exit;
}

// Set up page for a specific course
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Set up page layout
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('managemodels', 'block_studentperformancepredictor'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_pagelayout('standard');

// Get active model information
$activemodel = $DB->get_record('block_spp_models', ['courseid' => $courseid, 'active' => 1]);

// Get all models for this course
$models = $DB->get_records('block_spp_models', ['courseid' => $courseid], 'timemodified DESC');

// Get available datasets for model training
$datasets = $DB->get_records('block_spp_datasets', ['courseid' => $courseid], 'timemodified DESC');

// Get algorithm options (must match backend-supported algorithms)
$algorithmoptions = [
    'randomforest' => get_string('algorithm_randomforest', 'block_studentperformancepredictor'),
    'svm' => get_string('algorithm_svm', 'block_studentperformancepredictor'),
    'logisticregression' => get_string('algorithm_logisticregression', 'block_studentperformancepredictor'),
    'decisiontree' => get_string('algorithm_decisiontree', 'block_studentperformancepredictor'),
    'knn' => get_string('algorithm_knn', 'block_studentperformancepredictor')
];

// Output starts here
echo $OUTPUT->header();

// Print heading
echo $OUTPUT->heading(get_string('managemodels', 'block_studentperformancepredictor'));

// Link to task monitor and refresh
echo html_writer::div(
    html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/admin/viewtasks.php', ['courseid' => $courseid]),
        get_string('viewtasks', 'block_studentperformancepredictor'),
        ['class' => 'btn btn-info mb-3 mr-2']
    ) .
    html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]), 
        get_string('refresh', 'block_studentperformancepredictor'),
        ['class' => 'btn btn-secondary mb-3']
    ),
    'mb-3'
);

// Initialize admin interface JavaScript
$PAGE->requires->js_call_amd('block_studentperformancepredictor/admin_interface', 'init', [$courseid]);

// Current active model
if (!empty($activemodel)) {
    echo $OUTPUT->heading(get_string('currentmodel', 'block_studentperformancepredictor'), 3);

    $table = new html_table();
    $table->head = [
        get_string('modelname', 'block_studentperformancepredictor'),
        get_string('algorithm', 'block_studentperformancepredictor'),
        get_string('accuracy', 'block_studentperformancepredictor'),
        get_string('status', 'block_studentperformancepredictor'),  
        get_string('created', 'block_studentperformancepredictor'),
        get_string('actions', 'block_studentperformancepredictor')
    ];

    $row = [];
    $row[] = format_string($activemodel->modelname);
    $row[] = isset($algorithmoptions[$activemodel->algorithmtype]) ? 
            $algorithmoptions[$activemodel->algorithmtype] : $activemodel->algorithmtype;
    $row[] = round($activemodel->accuracy * 100, 2) . '%';
    $row[] = html_writer::tag('span', get_string('active', 'block_studentperformancepredictor'), 
                            ['class' => 'badge badge-success']);
    $row[] = userdate($activemodel->timemodified);
    $row[] = html_writer::link('#', get_string('deactivate', 'block_studentperformancepredictor'), 
                            ['class' => 'btn btn-sm btn-secondary spp-toggle-model-status', 
                                 'data-model-id' => $activemodel->id,
                                 'data-is-active' => 1]);

    $table->data[] = $row;
    echo html_writer::table($table);
}

// Train new model form
echo $OUTPUT->heading(get_string('trainnewmodel', 'block_studentperformancepredictor'), 3);

if (empty($datasets)) {
    echo $OUTPUT->notification(get_string('nodatasets', 'block_studentperformancepredictor'), 'warning');
    echo html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', ['courseid' => $courseid]), 
        get_string('uploadnewdataset', 'block_studentperformancepredictor'),
        ['class' => 'btn btn-primary']
    );
} else {
    $form = html_writer::start_tag('form', [
        'id' => 'spp-train-model-form', 
        'class' => 'form-inline mb-3',
        'method' => 'post',
        'action' => new moodle_url('/blocks/studentperformancepredictor/admin/train_model.php')
    ]);

    // Dataset selection
    $form .= html_writer::start_div('form-group mr-2');
    $form .= html_writer::label(get_string('selectdataset', 'block_studentperformancepredictor'), 'datasetid', true, ['class' => 'mr-2']);
    $form .= html_writer::start_tag('select', ['id' => 'datasetid', 'name' => 'datasetid', 'class' => 'form-control', 'required' => 'required']);
    $form .= html_writer::tag('option', '', ['value' => '']);
    foreach ($datasets as $dataset) {
        $form .= html_writer::tag('option', format_string($dataset->name), ['value' => $dataset->id]);
    }
    $form .= html_writer::end_tag('select');
    $form .= html_writer::end_div();

    // Algorithm selection
    $form .= html_writer::start_div('form-group mr-2');
    $form .= html_writer::label(get_string('selectalgorithm', 'block_studentperformancepredictor'), 'algorithm', true, ['class' => 'mr-2']);
    $form .= html_writer::start_tag('select', ['id' => 'algorithm', 'name' => 'algorithm', 'class' => 'form-control']);
    foreach ($algorithmoptions as $value => $label) {
        $form .= html_writer::tag('option', $label, ['value' => $value]);
    }
    $form .= html_writer::end_tag('select');
    $form .= html_writer::end_div();

    // Add hidden fields for CSRF protection
    $form .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

    // Submit button
    $form .= html_writer::start_div('form-group');
    $form .= html_writer::empty_tag('input', ['type' => 'submit', 'value' => get_string('trainmodel', 'block_studentperformancepredictor'), 'class' => 'btn btn-primary']);
    $form .= html_writer::empty_tag('input', [
        'type' => 'hidden',
        'name' => 'courseid',
        'value' => $courseid
    ]);
    $form .= html_writer::end_div();

    $form .= html_writer::end_tag('form');

    echo $form;
}

// All models list
if (!empty($models)) {
    echo $OUTPUT->heading(get_string('allmodels', 'block_studentperformancepredictor'), 3);

    $table = new html_table();
    $table->head = [
        get_string('modelname', 'block_studentperformancepredictor'),
        get_string('algorithm', 'block_studentperformancepredictor'),
        get_string('accuracy', 'block_studentperformancepredictor'),
        get_string('created', 'block_studentperformancepredictor'),
        get_string('status', 'block_studentperformancepredictor'),
        get_string('actions', 'block_studentperformancepredictor')
    ];

    foreach ($models as $model) {
        $row = [];
        $row[] = format_string($model->modelname);
        $row[] = isset($algorithmoptions[$model->algorithmtype]) ? 
                  $algorithmoptions[$model->algorithmtype] : $model->algorithmtype;
        $row[] = isset($model->accuracy) ? (is_numeric($model->accuracy) ? round($model->accuracy * 100, 2) . '%' : '-') : '-';
        $row[] = userdate($model->timemodified);

        // Show error message if model failed
        $statuscell = '';
        $trainstatus = isset($model->trainstatus) ? $model->trainstatus : 'complete';
        if ($trainstatus === 'failed') {
            $icon = html_writer::span('&#9888;', 'mr-1 text-warning', ['title' => 'Error']); // ⚠️
            $errordiv = !empty($model->errormessage)
                ? html_writer::div($icon . html_writer::tag('strong', 'Error: ') . s($model->errormessage), 'text-danger bg-warning-light p-2 rounded small mt-1', ['style' => 'border:1px solid #f5c6cb; background-color:#fff3cd;'])
                : '';
            $statuscell = html_writer::tag('span', get_string('inactive', 'block_studentperformancepredictor'), ['class' => 'badge badge-danger']) . $errordiv;
        } else if ($model->active) {
            $statuscell = html_writer::tag('span', get_string('active', 'block_studentperformancepredictor'), ['class' => 'badge badge-success']);
        } else {
            $statuscell = html_writer::tag('span', get_string('inactive', 'block_studentperformancepredictor'), ['class' => 'badge badge-secondary']);
        }
        $row[] = $statuscell;

        if ($model->active) {
            // Add a deactivate button for the active model
            $actions = html_writer::start_tag('form', [
                'action' => new moodle_url('/blocks/studentperformancepredictor/admin/activatemodel.php'),
                'method' => 'post',
                'style' => 'display:inline-block;margin:0;'
            ]);
            $actions .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'deactivate',
                'value' => 1
            ]);
            $actions .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'courseid',
                'value' => $courseid
            ]);
            $actions .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'sesskey',
                'value' => sesskey()
            ]);
            $actions .= html_writer::empty_tag('input', [
                'type' => 'submit',
                'value' => get_string('deactivate', 'block_studentperformancepredictor'),
                'class' => 'btn btn-sm btn-secondary'
            ]);
            $actions .= html_writer::end_tag('form');
        } else {
            // Use a form for activation to POST to activatemodel.php
            $actions = html_writer::start_tag('form', [
                'action' => new moodle_url('/blocks/studentperformancepredictor/admin/activatemodel.php'),
                'method' => 'post',
                'style' => 'display:inline-block;margin:0;'
            ]);
            $actions .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'modelid',
                'value' => $model->id
            ]);
            $actions .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'courseid',
                'value' => $courseid
            ]);
            $actions .= html_writer::empty_tag('input', [
                'type' => 'hidden',
                'name' => 'sesskey',
                'value' => sesskey()
            ]);
            $actions .= html_writer::empty_tag('input', [
                'type' => 'submit',
                'value' => get_string('activate', 'block_studentperformancepredictor'),
                'class' => 'btn btn-sm btn-primary'
            ]);
            $actions .= html_writer::end_tag('form');
        }

        $row[] = $actions;
        $table->data[] = $row;
    }

    echo html_writer::table($table);
}

// Output footer
echo $OUTPUT->footer();

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
* Refresh predictions page for Student Performance Predictor.
*
* @package    block_studentperformancepredictor
* @copyright  2023 Your Name <your.email@example.com>
* @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/

require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters.
$courseid = required_param('courseid', PARAM_INT);

// Set up page.
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions.
require_login($course);
require_capability('block/studentperformancepredictor:viewallpredictions', $context);

// Set up page layout.
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/refreshpredictions.php', array('courseid' => $courseid)));
$PAGE->set_context($context);
$PAGE->set_title(get_string('refreshpredictions', 'block_studentperformancepredictor'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_pagelayout('standard');

// Add required JavaScript
$PAGE->requires->js_call_amd('block_studentperformancepredictor/prediction_viewer', 'init');

// Check if there's an active model.
$hasactivemodel = block_studentperformancepredictor_has_active_model($courseid);

// Output starts here.
echo $OUTPUT->header();

// Print heading.
echo $OUTPUT->heading(get_string('refreshpredictions', 'block_studentperformancepredictor'));

if (!$hasactivemodel) {
    echo $OUTPUT->notification(get_string('noactivemodel', 'block_studentperformancepredictor'), 'warning');
    echo html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', array('courseid' => $courseid)), 
        get_string('managemodels', 'block_studentperformancepredictor'),
        array('class' => 'btn btn-primary')
    );
} else {
    // Get statistics on current predictions.
    $stats = block_studentperformancepredictor_get_course_risk_stats($courseid);

    echo html_writer::start_div('spp-prediction-stats mb-4');

    echo html_writer::start_div('card');
    echo html_writer::start_div('card-body');

    echo html_writer::tag('h5', get_string('currentpredictionstats', 'block_studentperformancepredictor'), array('class' => 'card-title'));

    echo html_writer::start_tag('ul', array('class' => 'list-group list-group-flush'));
    echo html_writer::tag('li', get_string('totalstudents', 'block_studentperformancepredictor') . ': ' . $stats->total, array('class' => 'list-group-item'));
    echo html_writer::tag('li', get_string('highrisk_label', 'block_studentperformancepredictor') . ': ' . $stats->highrisk . 
        ' (' . round(($stats->highrisk / max(1, $stats->total)) * 100) . '%)', array('class' => 'list-group-item spp-risk-high'));
    echo html_writer::tag('li', get_string('mediumrisk_label', 'block_studentperformancepredictor') . ': ' . $stats->mediumrisk . 
        ' (' . round(($stats->mediumrisk / max(1, $stats->total)) * 100) . '%)', array('class' => 'list-group-item spp-risk-medium'));
    echo html_writer::tag('li', get_string('lowrisk_label', 'block_studentperformancepredictor') . ': ' . $stats->lowrisk . 
        ' (' . round(($stats->lowrisk / max(1, $stats->total)) * 100) . '%)', array('class' => 'list-group-item spp-risk-low'));
    echo html_writer::end_tag('ul');

    echo html_writer::end_div(); // card-body
    echo html_writer::end_div(); // card

    echo html_writer::end_div(); // spp-prediction-stats

    // Refresh button and explanation.
    echo html_writer::start_div('spp-refresh-container mb-4');

    echo html_writer::tag('p', get_string('refreshexplanation', 'block_studentperformancepredictor'));

    echo html_writer::start_div('spp-refresh-action');
    echo html_writer::tag('button', get_string('refreshallpredictions', 'block_studentperformancepredictor'), 
                        array('class' => 'btn btn-primary spp-refresh-predictions', 
                             'data-course-id' => $courseid));
    echo html_writer::end_div();

    echo html_writer::end_div();

    // Show the last refresh time if available
    $lastrefreshtime = get_config('block_studentperformancepredictor', 'lastrefresh_' . $courseid);
    if (!empty($lastrefreshtime)) {
        echo html_writer::start_div('spp-last-refresh mb-4');
        echo html_writer::tag('p', get_string('lastrefreshtime', 'block_studentperformancepredictor', userdate($lastrefreshtime)), 
            array('class' => 'text-muted'));
        echo html_writer::end_div();
    }

    // Get information about students with no predictions (backend-driven)
    // This count reflects the state after the last backend prediction refresh.
    $sql = "SELECT COUNT(DISTINCT u.id) 
            FROM {user} u
            JOIN {user_enrolments} ue ON ue.userid = u.id
            JOIN {enrol} e ON e.id = ue.enrolid
            LEFT JOIN {block_spp_predictions} p ON p.userid = u.id AND p.courseid = :courseid
            WHERE e.courseid = :courseid2
            AND p.id IS NULL";

    $params = [
        'courseid' => $courseid,
        'courseid2' => $courseid
    ];

    $studentswithoutpredictions = $DB->count_records_sql($sql, $params);

    if ($studentswithoutpredictions > 0) {
        echo html_writer::start_div('spp-missing-predictions');
        echo $OUTPUT->notification(
            get_string('studentswithoutpredictions_backend', 'block_studentperformancepredictor', $studentswithoutpredictions), 
            'info'
        );
        echo html_writer::end_div();
    }

    // Add a link back to the admin menu.
    echo html_writer::div(
        html_writer::link(
            new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', array('courseid' => $courseid)), 
            get_string('backtomodels', 'block_studentperformancepredictor'),
            array('class' => 'btn btn-secondary')
        ),
        'mt-3'
    );
}

// Output footer.
echo $OUTPUT->footer();

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Test backend connection for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

// Check admin permissions
admin_externalpage_setup('blocksettingstudentperformancepredictor');

// Page setup
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/testbackend.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('testbackend', 'block_studentperformancepredictor', '', true));
$PAGE->set_heading(get_string('testbackend', 'block_studentperformancepredictor', '', true));

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('testbackend', 'block_studentperformancepredictor', '', true));

// Get the API URL and key from settings
$apiurl = get_config('block_studentperformancepredictor', 'python_api_url');
if (empty($apiurl)) {
    $apiurl = 'http://localhost:5000';
}

$apikey = get_config('block_studentperformancepredictor', 'python_api_key');
if (empty($apikey)) {
    $apikey = 'changeme';
}

// Make a request to the health check endpoint
$healthurl = rtrim($apiurl, '/') . '/health';
$curl = new curl();
$options = [
    'CURLOPT_TIMEOUT' => 10,
    'CURLOPT_RETURNTRANSFER' => true,
    'CURLOPT_HTTPHEADER' => [
        'Content-Type: application/json',
        'X-API-Key: ' . $apikey
    ]
];

echo html_writer::tag('h4', get_string('testingconnection', 'block_studentperformancepredictor', '', true));
echo html_writer::tag('p', get_string('testingbackendurl', 'block_studentperformancepredictor', $healthurl, true));

try {
    $response = $curl->get($healthurl, [], $options);
    $httpcode = $curl->get_info()['http_code'] ?? 0;

    if ($httpcode === 200) {
        // Success - show green alert
        echo $OUTPUT->notification(
            get_string('backendconnectionsuccess', 'block_studentperformancepredictor', '', true),
            'success'
        );

        // Show response details
        try {
            $data = json_decode($response, true);
            if (is_array($data)) {
                echo html_writer::tag('h5', get_string('backenddetails', 'block_studentperformancepredictor', '', true));
                echo html_writer::start_tag('pre', ['class' => 'bg-light p-3 rounded']);
                echo html_writer::tag('code', s(json_encode($data, JSON_PRETTY_PRINT)));
                echo html_writer::end_tag('pre');
            } else {
                echo html_writer::tag('p', s($response));
            }
        } catch (Exception $e) {
            echo html_writer::tag('p', s($response));
        }
    } else {
        // Connection failed - show red alert
        echo $OUTPUT->notification(
            get_string('backendconnectionfailed', 'block_studentperformancepredictor', $httpcode, true),
            'error'
        );

        // Show response
        echo html_writer::tag('h5', get_string('errormessage', 'block_studentperformancepredictor', '', true));
        echo html_writer::start_tag('pre', ['class' => 'bg-light p-3 rounded text-danger']);
        echo html_writer::tag('code', s($response));
        echo html_writer::end_tag('pre');
    }
} catch (Exception $e) {
    // Connection error - show red alert
    echo $OUTPUT->notification(
        get_string('backendconnectionerror', 'block_studentperformancepredictor', $e->getMessage(), true),
        'error'
    );
}

// Backend troubleshooting guide
echo html_writer::tag('h4', get_string('troubleshootingguide', 'block_studentperformancepredictor', '', true));
echo html_writer::start_tag('ol');
echo html_writer::tag('li', get_string('troubleshoot1', 'block_studentperformancepredictor', '', true));
echo html_writer::tag('li', get_string('troubleshoot2', 'block_studentperformancepredictor', '', true));
echo html_writer::tag('li', get_string('troubleshoot3', 'block_studentperformancepredictor', '', true));
echo html_writer::tag('li', get_string('troubleshoot4', 'block_studentperformancepredictor', '', true));
echo html_writer::tag('li', get_string('troubleshoot5', 'block_studentperformancepredictor', '', true));
echo html_writer::end_tag('ol');

// Provide command to start the backend
echo html_writer::tag('h5', get_string('startbackendcommand', 'block_studentperformancepredictor', '', true));
echo html_writer::start_tag('pre', ['class' => 'bg-dark text-light p-3 rounded']);
echo html_writer::tag('code', 'cd ' . $CFG->dirroot . '/blocks/studentperformancepredictor' . PHP_EOL . 'python -m uvicorn ml_backend:app --host 0.0.0.0 --port 5000');
echo html_writer::end_tag('pre');

// Back button
echo html_writer::div(
    $OUTPUT->single_button(
        new moodle_url('/admin/settings.php', ['section' => 'blocksettingstudentperformancepredictor']),
        get_string('backsettings', 'block_studentperformancepredictor', '', true),
        'get'
    ),
    'mt-4'
);

echo $OUTPUT->footer();

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Train model handler for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// Basic Moodle config
require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/moodlelib.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

use block_studentperformancepredictor\analytics\training_manager;

// Check system context
$context = context_system::instance();
$PAGE->set_context($context);

// Get and validate parameters
$courseid = required_param('courseid', PARAM_INT);
$datasetid = required_param('datasetid', PARAM_INT);
$algorithm = optional_param('algorithm', null, PARAM_ALPHANUMEXT);

// Set up page
$url = new moodle_url('/blocks/studentperformancepredictor/admin/train_model.php', array('courseid' => $courseid));
$PAGE->set_url($url);
$PAGE->set_pagelayout('admin');

// Security checks
require_login();
require_sesskey();

// Course context
$course = get_course($courseid);
$coursecontext = context_course::instance($courseid);
require_capability('block/studentperformancepredictor:managemodels', $coursecontext);

// Set up page title
$PAGE->set_title($course->shortname . ': ' . get_string('training_model', 'block_studentperformancepredictor'));
$PAGE->set_heading($course->fullname);

// Verify dataset exists
if (!$DB->record_exists('block_spp_datasets', array('id' => $datasetid, 'courseid' => $courseid))) {
    \core\notification::add(
        get_string('dataset_not_found', 'block_studentperformancepredictor'),
        \core\notification::ERROR
    );
    redirect($url);
}

// Check for pending training
if (training_manager::has_pending_training($courseid)) {
    \core\notification::add(
        get_string('training_already_scheduled', 'block_studentperformancepredictor'),
        \core\notification::WARNING
    );
    redirect($url);
}

// Schedule training (backend-driven orchestration)
try {
    // This will queue a training task that calls the Python backend /train endpoint
    if (training_manager::schedule_training($courseid, $datasetid, $algorithm)) {
        \core\notification::success(get_string('model_training_queued_backend', 'block_studentperformancepredictor'));
    } else {
        throw new \moodle_exception('trainingschedulefailed', 'block_studentperformancepredictor');
    }
} catch (\Exception $e) {
    \core\notification::error($e->getMessage());
}

// Redirect back to manage models page
redirect(new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', array('courseid' => $courseid)));

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upload dataset handler for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);
require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');
require_once($CFG->libdir . '/moodlelib.php'); // For get_string, required_param, optional_param, require_sesskey, clean_filename
require_once($CFG->libdir . '/accesslib.php'); // For get_course, context_course, require_capability
require_once($CFG->libdir . '/enrollib.php'); // For require_login
require_once($CFG->libdir . '/filelib.php'); // For file handling
require_once($CFG->libdir . '/adminlib.php'); // For admin functions
require_once($CFG->libdir . '/weblib.php'); // For web utilities

// Set up response array
$response = array(
    'success' => false,
    'message' => ''
);

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = get_string('invalidrequest', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Get parameters
$courseid = required_param('courseid', PARAM_INT);
$datasetname = required_param('dataset_name', PARAM_TEXT);
$datasetformat = required_param('dataset_format', PARAM_ALPHA);
$datasetdesc = optional_param('dataset_description', '', PARAM_TEXT);

// Validate session key
require_sesskey();

// Set up context
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Verify file upload
if (!isset($_FILES['dataset_file']) || empty($_FILES['dataset_file']['name'])) {
    $response['message'] = get_string('nofileuploaded', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

$file = $_FILES['dataset_file'];

// Check for upload errors
if ($file['error'] !== UPLOAD_ERR_OK) {
    $errormessage = get_string('fileuploaderror', 'block_studentperformancepredictor');
    switch ($file['error']) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            $errormessage = get_string('filetoolarge', 'block_studentperformancepredictor');
            break;
        case UPLOAD_ERR_PARTIAL:
            $errormessage = get_string('filepartialuploaded', 'block_studentperformancepredictor');
            break;
        case UPLOAD_ERR_NO_FILE:
            $errormessage = get_string('nofileuploaded', 'block_studentperformancepredictor');
            break;
    }
    $response['message'] = $errormessage;
    echo json_encode($response);
    die();
}

// Check file extension
$filename = $file['name'];
$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

if ($datasetformat === 'csv' && $extension !== 'csv') {
    $response['message'] = get_string('invalidfileextension', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
} else if ($datasetformat === 'json' && $extension !== 'json') {
    $response['message'] = get_string('invalidfileextension', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Create dataset directory
try {
    $datasetdir = block_studentperformancepredictor_ensure_dataset_directory($courseid);
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    echo json_encode($response);
    die();
}

// Store the file with a unique name
$newfilename = $courseid . '_' . time() . '_' . clean_filename($filename);
$filepath = $datasetdir . '/' . $newfilename;

if (!move_uploaded_file($file['tmp_name'], $filepath)) {
    $response['message'] = get_string('fileuploadfailed', 'block_studentperformancepredictor');
    echo json_encode($response);
    die();
}

// Extract column headers
$columns = array();

if ($datasetformat === 'csv') {
    $handle = fopen($filepath, 'r');
    if ($handle !== false) {
        $headers = fgetcsv($handle);
        foreach ($headers as $header) {
            $columns[] = $header;
        }
        fclose($handle);
    }
} else if ($datasetformat === 'json') {
    $content = file_get_contents($filepath);
    $jsonData = json_decode($content, true);
    if (is_array($jsonData) && !empty($jsonData)) {
        $firstRow = reset($jsonData);
        $columns = array_keys($firstRow);
    }
}

// Save dataset record to database
$dataset = new stdClass();
$dataset->courseid = $courseid;
$dataset->name = $datasetname;
$dataset->description = $datasetdesc;
$dataset->filepath = $filepath;
$dataset->fileformat = $datasetformat;
$dataset->columns = json_encode($columns);
$dataset->timecreated = time();
$dataset->timemodified = time();
$dataset->usermodified = $USER->id;

try {
    $datasetid = $DB->insert_record('block_spp_datasets', $dataset);
    $response['success'] = true;
    $response['message'] = get_string('datasetsaved_backend', 'block_studentperformancepredictor');
    $response['datasetid'] = $datasetid;
} catch (Exception $e) {
    $response['message'] = get_string('datasetsaveerror', 'block_studentperformancepredictor') . ': ' . $e->getMessage();
    if (function_exists('debugging')) {
        debugging('Dataset upload error: ' . $e->getMessage(), defined('DEBUG_DEVELOPER') ? DEBUG_DEVELOPER : 0);
    }
}

// Optionally, trigger ad-hoc model training task (backend-driven)
// Uncomment the following block if you want to auto-train a model after upload
/*
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/classes/task/train_model.php');
$adhoc = new \block_studentperformancepredictor\task\train_model();
$adhoc->set_custom_data([
    'courseid' => $courseid,
    'datasetid' => $datasetid,
    'algorithm' => null // Or pass a selected algorithm from UI
]);
\core\task\manager::queue_adhoc_task($adhoc);
*/

// Return JSON response
// All orchestration is backend-driven
echo json_encode($response);

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * View dataset details for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters
$id = required_param('id', PARAM_INT);
$courseid = required_param('courseid', PARAM_INT);

// Set up page
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Get dataset
$dataset = $DB->get_record('block_spp_datasets', array('id' => $id, 'courseid' => $courseid), '*', MUST_EXIST);

// Set up page layout
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/viewdataset.php', array('id' => $id, 'courseid' => $courseid)));
$PAGE->set_context($context);
$PAGE->set_title(get_string('datasetname', 'block_studentperformancepredictor') . ': ' . $dataset->name);
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_pagelayout('standard');

// Output starts here
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('datasetname', 'block_studentperformancepredictor') . ': ' . format_string($dataset->name));

// Display dataset details
$table = new html_table();
$table->attributes['class'] = 'generaltable';
$table->head = array(get_string('property', 'moodle'), get_string('value', 'moodle'));
$table->data = array();

$table->data[] = array(get_string('datasetname', 'block_studentperformancepredictor'), format_string($dataset->name));
$table->data[] = array(get_string('datasetdescription', 'block_studentperformancepredictor'), $dataset->description ? format_text($dataset->description) : '');
$table->data[] = array(get_string('datasetformat', 'block_studentperformancepredictor'), $dataset->fileformat);
$table->data[] = array(get_string('uploaded', 'block_studentperformancepredictor'), userdate($dataset->timecreated));

// Display columns
$columns = json_decode($dataset->columns);
if ($columns && is_array($columns) && count($columns) > 0) {
    $columnlist = html_writer::start_tag('ul');
    foreach ($columns as $column) {
        $columnlist .= html_writer::tag('li', s($column));
    }
    $columnlist .= html_writer::end_tag('ul');
    $table->data[] = array(get_string('columns', 'block_studentperformancepredictor'), $columnlist);
}

echo html_writer::table($table);

// Add a "Train model" button (backend-driven orchestration)
echo html_writer::start_div('mt-4');
echo html_writer::div(
    get_string('trainmodel_backenddesc', 'block_studentperformancepredictor'),
    'mb-2 text-muted'
);
echo html_writer::link(
    new moodle_url('/blocks/studentperformancepredictor/admin/train_model.php', 
        array('courseid' => $courseid, 'datasetid' => $dataset->id)),
    get_string('trainmodel', 'block_studentperformancepredictor'),
    array('class' => 'btn btn-primary')
);

// Add a "Back" button
echo ' ';
echo html_writer::link(
    new moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', 
        array('courseid' => $courseid)),
    get_string('back', 'core'),
    array('class' => 'btn btn-secondary')
);
echo html_writer::end_div();

// Output footer
echo $OUTPUT->footer();

<?php
// This file is part of Moodle - http://moodle.org/
/**
 * View model training tasks for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/tablelib.php'); // For html_table
require_once($CFG->dirroot . '/lib/accesslib.php'); // For require_login, require_capability
require_once($CFG->dirroot . '/lib/moodlelib.php'); // For userdate, s
require_once($CFG->libdir . '/weblib.php'); // For html_writer, s, get_string

require_login();
$courseid = optional_param('courseid', 0, PARAM_INT);

// Default to system context if no course specified
if ($courseid) {
    $context = context_course::instance($courseid);
    $course = get_course($courseid);
    $PAGE->set_course($course);
    $pageheading = format_string($course->fullname);
} else {
    $context = context_system::instance();
    $pageheading = get_string('viewtasks', 'block_studentperformancepredictor');
}

require_capability('block/studentperformancepredictor:managemodels', $context);

// Set up page
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/viewtasks.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('viewtasks', 'block_studentperformancepredictor'));
$PAGE->set_heading($pageheading);
$PAGE->set_pagelayout('admin');

// Get all train_model tasks (adhoc and scheduled)
global $DB;
$table = new html_table();
$table->head = [
    get_string('id', 'moodle'),
    get_string('taskname', 'block_studentperformancepredictor'),
    get_string('status', 'block_studentperformancepredictor'),
    get_string('courseid', 'moodle'),
    get_string('algorithm', 'block_studentperformancepredictor'),
    get_string('timecreated', 'moodle'),
    get_string('nextruntime', 'block_studentperformancepredictor'),
    get_string('lastruntime', 'moodle'),
    get_string('output', 'tool_task'),
];
$table->data = [];

// Filter by course if specified
$tasksql = "component = :component";
$taskparams = ['component' => 'block_studentperformancepredictor'];

if ($courseid) {
    $tasksql .= " AND " . $DB->sql_like('customdata', ':courseid');
    $taskparams['courseid'] = '%"courseid":' . $courseid . '%';
}

// Get all adhoc tasks for this plugin/course
$tasks = $DB->get_records_select('task_adhoc', $tasksql, $taskparams, 'id DESC');

foreach ($tasks as $task) {
    $customdata = json_decode($task->customdata);

    // Task information
    $taskname = explode('\\', $task->classname);
    $taskname = end($taskname);

    // Get model information if available
    $model = null;
    if (isset($customdata->modelid)) {
        $model = $DB->get_record('block_spp_models', ['id' => $customdata->modelid]);
    }

    // Task status
    if ($task->nextruntime && $task->nextruntime > time()) {
        $status = get_string('taskqueued', 'block_studentperformancepredictor');
        $statusclass = 'badge badge-info';
    } else if ($task->timestarted && !$task->timecompleted) {
        $status = get_string('taskrunning', 'block_studentperformancepredictor');
        $statusclass = 'badge badge-warning';
    } else {
        $status = get_string('complete', 'completion');
        $statusclass = 'badge badge-success';
    }

    // Course info
    $thiscourse = isset($customdata->courseid) ? $customdata->courseid : '-';

    // Algorithm info
    $algorithm = isset($customdata->algorithm) ? $customdata->algorithm : 
                 (isset($model->algorithmtype) ? $model->algorithmtype : '-');

    // Time values
    $timecreated = isset($task->timestart) && $task->timestart ? userdate($task->timestart) : 
                  (isset($task->timecreated) ? userdate($task->timecreated) : '-');

    $nextrun = $task->nextruntime ? userdate($task->nextruntime) : '-';
    $lastrun = $task->lastruntime ? userdate($task->lastruntime) : '-';

    // Error message handling
    $errormessage = '-';
    if (isset($model) && $model && !empty($model->errormessage)) {
        $icon = html_writer::span('&#9888;', 'mr-1 text-warning', ['title' => 'Error']); // ⚠️
        $errormessage = html_writer::div(
            $icon . html_writer::tag('strong', 'Error: ') . s($model->errormessage), 
            'text-danger bg-warning-light p-2 rounded small', 
            ['style' => 'border:1px solid #f5c6cb; background-color:#fff3cd;']
        );
    }

    $output = $task->faildelay ? get_string('failed', 'core') : ($task->output ?? '-');

    $table->data[] = [
        $task->id,
        $taskname,
        html_writer::span($status, $statusclass),
        $thiscourse,
        $algorithm,
        $timecreated,
        $nextrun,
        $lastrun,
        $output . ($errormessage !== '-' ? '<br>' . $errormessage : ''),
    ];
}

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('viewtasks', 'block_studentperformancepredictor'));

if (empty($table->data)) {
    echo $OUTPUT->notification(get_string('notasks', 'block_studentperformancepredictor'), 'info');
} else {
    echo html_writer::table($table);
}

// Back to models button
if ($courseid) {
    echo html_writer::div(
        html_writer::link(
            new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]),
            get_string('backtomodels', 'block_studentperformancepredictor'),
            ['class' => 'btn btn-secondary']
        ),
        'mt-3'
    );
}

echo $OUTPUT->footer();

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Admin interface JS for Student Performance Predictor.
 *
 * @module     block_studentperformancepredictor/admin_interface
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['jquery', 'core/ajax', 'core/str', 'core/notification', 'core/modal_factory', 'core/modal_events'], 
function($, Ajax, Str, Notification, ModalFactory, ModalEvents) {

    /**
     * Initialize admin interface.
     * 
     * @param {int} courseId Course ID
     */
    var init = function(courseId) {
        try {
            // Handle dataset upload form
            $('#spp-dataset-upload-form').on('submit', function(e) {
                e.preventDefault();

                // Validate form
                var form = $(this)[0];
                if (!form.checkValidity()) {
                    if (typeof form.reportValidity === 'function') {
                        form.reportValidity();
                    }
                    return;
                }

                var formData = new FormData(form);
                var submitButton = $(this).find('input[type="submit"]');
                var originalText = submitButton.val();
                submitButton.prop('disabled', true);

                // Load 'uploading' string asynchronously for button and status
                Str.get_string('uploading', 'moodle').done(function(uploadingStr) {
                    submitButton.val(uploadingStr);
                    $('#spp-upload-status').html(
                        '<div class="spp-loading"><i class="fa fa-spinner fa-spin"></i>' + uploadingStr + '</div>'
                    );
                }).fail(function() {
                    submitButton.val('Uploading...');
                    $('#spp-upload-status').html(
                        '<div class="spp-loading"><i class="fa fa-spinner fa-spin"></i>Uploading...</div>'
                    );
                });

                $.ajax({
                    url: M.cfg.wwwroot + '/blocks/studentperformancepredictor/admin/upload_dataset.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        submitButton.prop('disabled', false);
                        submitButton.val(originalText);
                        $('#spp-upload-status').empty();

                        try {
                            // Properly handle response which might be string or object
                            var responseData;
                            if (typeof response === 'string') {
                                try {
                                    responseData = JSON.parse(response);
                                } catch (e) {
                                    console.error('Invalid JSON response', response);
                                    Notification.exception(new Error('Invalid server response'));
                                    return;
                                }
                            } else {
                                responseData = response;
                            }

                            if (responseData && responseData.success) {
                                // Show success message
                                var msg = responseData.message;
                                if (!msg) {
                                    Str.get_string('datasetsaved', 'block_studentperformancepredictor').done(function(s) {
                                        Notification.addNotification({ message: s, type: 'success' });
                                    });
                                } else {
                                    Notification.addNotification({ message: msg, type: 'success' });
                                }
                                setTimeout(function() { window.location.reload(); }, 1500);
                            } else {
                                var msg = responseData ? responseData.message : '';
                                if (!msg) {
                                    Str.get_string('datasetsaveerror', 'block_studentperformancepredictor').done(function(s) {
                                        Notification.addNotification({ message: s, type: 'error' });
                                    });
                                } else {
                                    Notification.addNotification({ message: msg, type: 'error' });
                                }
                            }
                        } catch (e) {
                            console.error('Error handling response:', e);
                            Str.get_string('datasetsaveerror', 'block_studentperformancepredictor').done(function(s) {
                                Notification.addNotification({ message: s, type: 'error' });
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX error:', status, error);
                        submitButton.prop('disabled', false);
                        submitButton.val(originalText);
                        $('#spp-upload-status').empty();

                        // Get response error message if available
                        var errorMessage = error;
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (response && response.message) {
                                errorMessage = response.message;
                            }
                        } catch (e) {
                            // Use default error message if JSON parsing fails
                        }

                        Str.get_string('uploaderror', 'block_studentperformancepredictor').done(function(s) {
                            Notification.addNotification({ message: s + ': ' + errorMessage, type: 'error' });
                        });
                    }
                });
            });

            // Handle model training form
            $('#spp-train-model-form').on('submit', function(e) {
                e.preventDefault();
                var datasetId = $('#datasetid').val();
                var algorithm = $('#algorithm').val();
                if (!datasetId) {
                    Str.get_string('selectdataset', 'block_studentperformancepredictor').done(function(s) {
                        Notification.addNotification({ message: s, type: 'error' });
                    });
                    return;
                }
                var submitButton = $(this).find('input[type="submit"]');
                var originalText = submitButton.val();
                submitButton.prop('disabled', true);
                Str.get_string('training', 'block_studentperformancepredictor').done(function(trainingStr) {
                    submitButton.val(trainingStr);
                });

                // Using traditional form submission for better file handling compatibility
                var form = $(this)[0];
                form.submit();
            });

            // Handle dataset deletion
            $('.spp-delete-dataset').on('click', function(e) {
                e.preventDefault();

                var button = $(this);
                var datasetId = button.data('dataset-id');

                button.prop('disabled', true);

                // Confirm deletion.
                Str.get_strings([
                    {key: 'confirmdeletedataset', component: 'block_studentperformancepredictor'},
                    {key: 'delete', component: 'core'},
                    {key: 'cancel', component: 'core'}
                ]).done(function(strings) {
                    ModalFactory.create({
                        type: ModalFactory.types.SAVE_CANCEL,
                        title: strings[0],
                        body: strings[0]
                    }).done(function(modal) {
                        modal.setSaveButtonText(strings[1]);

                        // When the user confirms deletion
                        modal.getRoot().on(ModalEvents.save, function() {
                            $.ajax({
                                url: M.cfg.wwwroot + '/blocks/studentperformancepredictor/admin/ajax_delete_dataset.php',
                                type: 'POST',
                                data: {
                                    datasetid: datasetId,
                                    courseid: courseId,
                                    sesskey: M.cfg.sesskey
                                },
                                dataType: 'json',
                                success: function(response) {
                                    if (response.success) {
                                        // Reload page to update dataset list.
                                        window.location.reload();
                                    } else {
                                        button.prop('disabled', false);

                                        // Show error message.
                                        Notification.addNotification({
                                            message: response.message,
                                            type: 'error'
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    button.prop('disabled', false);

                                    // Try to parse error message from response
                                    var errorMessage = error;
                                    try {
                                        var response = JSON.parse(xhr.responseText);
                                        if (response && response.message) {
                                            errorMessage = response.message;
                                        }
                                    } catch (e) {
                                        // Use default error message
                                    }

                                    // Show error message.
                                    Str.get_string('actionerror', 'block_studentperformancepredictor').done(function(s) {
                                        Notification.addNotification({
                                            message: s + ': ' + errorMessage,
                                            type: 'error'
                                        });
                                    });
                                }
                            });
                        });

                        // When the modal is cancelled, re-enable the button
                        modal.getRoot().on(ModalEvents.cancel, function() {
                            button.prop('disabled', false);
                        });

                        modal.show();
                    }).catch(function(error) {
                        console.error('Error creating modal:', error);
                        button.prop('disabled', false);
                    });
                }).catch(function(error) {
                    console.error('Error loading strings:', error);
                    button.prop('disabled', false);
                });
            });

        } catch (e) {
            console.error('Error initializing admin interface:', e);
            // Show a generic error notification
            Str.get_string('jserror', 'moodle').done(function(s) {
                Notification.exception(new Error(s + ': ' + e.message));
            });
        }
    };

    return {
        init: init
    };
});

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Chart renderer for Student Performance Predictor.
 *
 * @module     block_studentperformancepredictor/chart_renderer
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['jquery', 'core/chartjs', 'core/str'], function($, Chart, Str) {

    /**
     * Initialize student prediction chart.
     */
    var init = function() {
        var chartElement = document.getElementById('spp-prediction-chart');
        if (!chartElement) {
            return;
        }

        try {
            var chartData = {};
            try {
                chartData = JSON.parse(chartElement.dataset.chartdata || '{"passprob":0,"failprob":100}');
            } catch (e) {
                console.error('Error parsing chart data:', e);
                chartData = {"passprob":0,"failprob":100};
            }

            var ctx = chartElement.getContext('2d');

            Str.get_strings([
                {key: 'passingchance', component: 'block_studentperformancepredictor'},
                {key: 'failingchance', component: 'block_studentperformancepredictor'}
            ]).done(function(labels) {
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: labels,
                        datasets: [{
                            data: [chartData.passprob, chartData.failprob],
                            backgroundColor: [
                                '#28a745', // Green for passing
                                '#dc3545'  // Red for failing
                            ],
                            borderWidth: 1,
                            hoverBackgroundColor: [
                                '#218838', // Darker green on hover
                                '#c82333'  // Darker red on hover
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        cutoutPercentage: 70,
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 15,
                                boxWidth: 12
                            }
                        },
                        tooltips: {
                            callbacks: {
                                label: function(tooltipItem, data) {
                                    var dataset = data.datasets[tooltipItem.datasetIndex];
                                    var value = dataset.data[tooltipItem.index];
                                    return data.labels[tooltipItem.index] + ': ' + value + '%';
                                }
                            }
                        },
                        animation: {
                            animateScale: true,
                            animateRotate: true,
                            duration: 1000
                        }
                    }
                });
            }).fail(function() {
                // Fallback labels if string loading fails
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Passing', 'Failing'],
                        datasets: [{
                            data: [chartData.passprob, chartData.failprob],
                            backgroundColor: ['#28a745', '#dc3545'],
                            borderWidth: 1,
                            hoverBackgroundColor: ['#218838', '#c82333']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        cutoutPercentage: 70
                    }
                });
            });
        } catch (e) {
            console.error('Error initializing chart:', e);
            Str.get_string('charterror', 'block_studentperformancepredictor').done(function(msg) {
                chartElement.innerHTML = '<div class="alert alert-warning">' + msg + '</div>';
            }).fail(function() {
                chartElement.innerHTML = '<div class="alert alert-warning">Chart error</div>';
            });
        }
    };

    /**
     * Initialize teacher view chart.
     */
    var initTeacherChart = function() {
        var chartElement = document.getElementById('spp-teacher-chart');
        if (!chartElement) {
            return;
        }

        try {
            var chartData = {};
            try {
                chartData = JSON.parse(chartElement.dataset.chartdata || '{"labels":[],"data":[]}');
            } catch (e) {
                console.error('Error parsing chart data:', e);
                chartData = {"labels":[],"data":[]};
            }

            var ctx = chartElement.getContext('2d');

            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        data: chartData.data,
                        backgroundColor: [
                            '#dc3545',  // High risk - Red
                            '#ffc107',  // Medium risk - Yellow
                            '#28a745'   // Low risk - Green
                        ],
                        borderWidth: 1,
                        hoverBackgroundColor: [
                            '#c82333',  // Darker red on hover
                            '#e0a800',  // Darker yellow on hover
                            '#218838'   // Darker green on hover
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            boxWidth: 12
                        }
                    },
                    tooltips: {
                        callbacks: {
                            label: function(tooltipItem, data) {
                                var dataset = data.datasets[tooltipItem.datasetIndex];
                                var total = dataset.data.reduce(function(previousValue, currentValue) {
                                    return previousValue + currentValue;
                                });
                                var currentValue = dataset.data[tooltipItem.index];
                                var percentage = Math.round((currentValue / total) * 100);
                                return data.labels[tooltipItem.index] + ': ' + currentValue + ' (' + percentage + '%)';
                            }
                        }
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true,
                        duration: 1000
                    }
                }
            });
        } catch (e) {
            console.error('Error initializing teacher chart:', e);
            Str.get_string('charterror', 'block_studentperformancepredictor').done(function(msg) {
                chartElement.innerHTML = '<div class="alert alert-warning">' + msg + '</div>';
            }).fail(function() {
                chartElement.innerHTML = '<div class="alert alert-warning">Chart error</div>';
            });
        }
    };

    /**
     * Initialize admin view chart.
     */
    var initAdminChart = function() {
        var chartElement = document.getElementById('spp-admin-chart');
        if (!chartElement) {
            return;
        }

        try {
            var chartData = {};
            try {
                chartData = JSON.parse(chartElement.dataset.chartdata || '{"labels":[],"data":[]}');
            } catch (e) {
                console.error('Error parsing chart data:', e);
                chartData = {"labels":[],"data":[]};
            }

            var ctx = chartElement.getContext('2d');

            Str.get_string('studentcount', 'block_studentperformancepredictor').done(function(label) {
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: chartData.labels,
                        datasets: [{
                            label: label,
                            data: chartData.data,
                            backgroundColor: [
                                '#dc3545',  // High risk - Red
                                '#ffc107',  // Medium risk - Yellow
                                '#28a745'   // Low risk - Green
                            ],
                            borderWidth: 1,
                            hoverBackgroundColor: [
                                '#c82333',  // Darker red on hover
                                '#e0a800',  // Darker yellow on hover
                                '#218838'   // Darker green on hover
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                    precision: 0
                                },
                                gridLines: {
                                    drawBorder: true,
                                    color: 'rgba(0, 0, 0, 0.1)'
                                }
                            }],
                            xAxes: [{
                                gridLines: {
                                    display: false
                                }
                            }]
                        },
                        legend: {
                            display: false
                        },
                        tooltips: {
                            callbacks: {
                                label: function(tooltipItem, data) {
                                    var dataset = data.datasets[tooltipItem.datasetIndex];
                                    var total = dataset.data.reduce(function(previousValue, currentValue) {
                                        return previousValue + currentValue;
                                    });
                                    var currentValue = dataset.data[tooltipItem.index];
                                    var percentage = Math.round((currentValue / total) * 100);
                                    return data.labels[tooltipItem.index] + ': ' + currentValue + ' (' + percentage + '%)';
                                }
                            }
                        },
                        animation: {
                            duration: 1000,
                            easing: 'easeOutQuart'
                        }
                    }
                });
            }).fail(function() {
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: chartData.labels,
                        datasets: [{
                            label: 'Student count',
                            data: chartData.data,
                            backgroundColor: ['#dc3545', '#ffc107', '#28a745'],
                            borderWidth: 1,
                            hoverBackgroundColor: ['#c82333', '#e0a800', '#218838']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false
                    }
                });
            });
        } catch (e) {
            console.error('Error initializing admin chart:', e);
            Str.get_string('charterror', 'block_studentperformancepredictor').done(function(msg) {
                chartElement.innerHTML = '<div class="alert alert-warning">' + msg + '</div>';
            }).fail(function() {
                chartElement.innerHTML = '<div class="alert alert-warning">Chart error</div>';
            });
        }
    };

    return {
        init: init,
        initTeacherChart: initTeacherChart,
        initAdminChart: initAdminChart
    };
});

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Prediction viewer JS for Student Performance Predictor.
 *
 * @module     block_studentperformancepredictor/prediction_viewer
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['jquery', 'core/ajax', 'core/notification', 'core/modal_factory', 'core/modal_events', 'core/str'], 
function($, Ajax, Notification, ModalFactory, ModalEvents, Str) {
    /**
     * Initialize suggestion management.
     */
    var init = function() {
        // Handle marking suggestions as viewed
        $(document).on('click', '.spp-mark-viewed', function(e) {
            e.preventDefault();
            var button = $(this);
            var suggestionId = button.data('id');
            button.prop('disabled', true);
            button.addClass('disabled');

            var promise = Ajax.call([{
                methodname: 'block_studentperformancepredictor_mark_suggestion_viewed',
                args: { suggestionid: suggestionId }
            }]);

            promise[0].done(function(response) {
                if (response.status) {
                    Str.get_string('viewed', 'block_studentperformancepredictor').done(function(viewedStr) {
                        button.replaceWith('<span class="badge bg-secondary">' + viewedStr + '</span>');
                    }).fail(function() {
                        button.replaceWith('<span class="badge bg-secondary">Viewed</span>');
                    });
                } else {
                    button.prop('disabled', false);
                    button.removeClass('disabled');
                    Notification.addNotification({ message: response.message, type: 'error' });
                }
            }).fail(function(error) {
                button.prop('disabled', false);
                button.removeClass('disabled');
                Notification.exception(error);
            });
        });

        // Handle marking suggestions as completed
        $(document).on('click', '.spp-mark-completed', function(e) {
            e.preventDefault();
            var button = $(this);
            var suggestionId = button.data('id');
            button.prop('disabled', true);
            button.addClass('disabled');

            var promise = Ajax.call([{
                methodname: 'block_studentperformancepredictor_mark_suggestion_completed',
                args: { suggestionid: suggestionId }
            }]);

            promise[0].done(function(response) {
                if (response.status) {
                    Str.get_strings([
                        {key: 'completed', component: 'block_studentperformancepredictor'},
                        {key: 'viewed', component: 'block_studentperformancepredictor'}
                    ]).done(function(strings) {
                        button.replaceWith('<span class="badge bg-success">' + strings[0] + '</span>');
                        var viewedBtn = button.closest('.spp-suggestion-actions').find('.spp-mark-viewed');
                        if (viewedBtn.length) {
                            viewedBtn.replaceWith('<span class="badge bg-secondary">' + strings[1] + '</span>');
                        }
                    }).fail(function() {
                        button.replaceWith('<span class="badge bg-success">Completed</span>');
                        var viewedBtn = button.closest('.spp-suggestion-actions').find('.spp-mark-viewed');
                        if (viewedBtn.length) {
                            viewedBtn.replaceWith('<span class="badge bg-secondary">Viewed</span>');
                        }
                    });
                } else {
                    button.prop('disabled', false);
                    button.removeClass('disabled');
                    Notification.addNotification({ message: response.message, type: 'error' });
                }
            }).fail(function(error) {
                button.prop('disabled', false);
                button.removeClass('disabled');
                Notification.exception(error);
            });
        });

        // Handle teacher refresh predictions button
        $('.spp-refresh-predictions').on('click', function(e) {
            e.preventDefault();
            var button = $(this);
            button.prop('disabled', true);
            button.addClass('disabled');

            var courseId = button.data('course-id');
            if (!courseId) {
                courseId = $('.block_studentperformancepredictor').data('course-id');
            }

            if (!courseId) {
                button.prop('disabled', false);
                button.removeClass('disabled');
                Str.get_string('error:nocourseid', 'block_studentperformancepredictor').done(function(msg) {
                    Notification.addNotification({ message: msg, type: 'error' });
                }).fail(function() {
                    Notification.addNotification({ message: 'No course ID', type: 'error' });
                });
                return;
            }

            Str.get_strings([
                {key: 'refreshconfirmation', component: 'block_studentperformancepredictor'},
                {key: 'refresh', component: 'block_studentperformancepredictor'},
                {key: 'cancel', component: 'moodle'},
                {key: 'refreshing', component: 'block_studentperformancepredictor'}
            ]).done(function(strings) {
                ModalFactory.create({
                    type: ModalFactory.types.SAVE_CANCEL,
                    title: strings[0],
                    body: strings[0]
                }).done(function(modal) {
                    modal.setSaveButtonText(strings[1]);

                    modal.getRoot().on(ModalEvents.save, function() {
                        var loadingMessage = $('<div class="spp-loading"><i class="fa fa-spinner fa-spin"></i> ' + strings[3] + '</div>');
                        button.after(loadingMessage);

                        var promise = Ajax.call([{
                            methodname: 'block_studentperformancepredictor_refresh_predictions',
                            args: { courseid: courseId }
                        }]);

                        promise[0].done(function(response) {
                            button.prop('disabled', false);
                            button.removeClass('disabled');
                            loadingMessage.remove();

                            if (response.status) {
                                Notification.addNotification({ message: response.message, type: 'success' });
                                setTimeout(function() { window.location.reload(); }, 1500);
                            } else {
                                Notification.addNotification({ message: response.message, type: 'error' });
                            }
                        }).fail(function(error) {
                            button.prop('disabled', false);
                            button.removeClass('disabled');
                            loadingMessage.remove();
                            Notification.exception(error);
                        });
                    });

                    modal.getRoot().on(ModalEvents.cancel, function() {
                        button.prop('disabled', false);
                        button.removeClass('disabled');
                    });

                    modal.show();
                });
            });
        });
    }

    return {
        init: init
    };
});

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Data preprocessor for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\analytics;

defined('MOODLE_INTERNAL') || die();

/**
 * Data preprocessor for student performance data.
 *
 * NOTE: As of the unified plugin architecture, all ML feature engineering and preprocessing
 * for model training and prediction is handled by the Python backend. This class is only
 * used for minimal validation or formatting before sending data to the backend.
 * Advanced preprocessing methods below are legacy and not used in the new workflow.
 */
class data_preprocessor {
    /** @var int Course ID */
    protected $courseid;

    /**
     * Constructor.
     * 
     * @param int $courseid Course ID
     */
    public function __construct($courseid) {
        $this->courseid = $courseid;
    }

    /**
     * Preprocess a dataset for training.
     *
     * In the new architecture, this should only perform minimal validation/formatting.
     * All ML preprocessing is handled by the Python backend.
     *
     * @param array $dataset Raw dataset
     * @return array Preprocessed dataset
     */
    public function preprocess_dataset($dataset) {
        // Minimal validation/formatting only. No ML feature engineering here.
        return $dataset;
    }

    /**
     * Legacy: Handle missing values in the dataset (not used in new backend-driven workflow).
     *
     * @param array $dataset Dataset with possible missing values
     * @return array Dataset with handled missing values
     */
    protected function handle_missing_values($dataset) {
        if (empty($dataset)) {
            return $dataset;
        }

        $columns = array_keys($dataset[0]);
        $columnMeans = array();
        $columnModes = array();
        $numRows = count($dataset);

        // Calculate means for numeric columns and modes for categorical columns
        foreach ($columns as $column) {
            $numericValues = array();
            $categoricalValues = array();
            foreach ($dataset as $row) {
                if (isset($row[$column]) && $row[$column] !== '' && $row[$column] !== null) {
                    if (is_numeric($row[$column])) {
                        $numericValues[] = $row[$column];
                    } else {
                        $categoricalValues[] = $row[$column];
                    }
                }
            }
            if (!empty($numericValues)) {
                $columnMeans[$column] = array_sum($numericValues) / count($numericValues);
            }
            if (!empty($categoricalValues)) {
                $valuesCount = array_count_values($categoricalValues);
                arsort($valuesCount);
                $columnModes[$column] = key($valuesCount);
            }
        }

        // Fill missing values with mean (numeric) or mode (categorical)
        foreach ($dataset as $i => $row) {
            foreach ($columns as $column) {
                if (!isset($row[$column]) || $row[$column] === '' || $row[$column] === null) {
                    if (isset($columnMeans[$column]) && (!isset($columnModes[$column]) || is_numeric($columnMeans[$column]))) {
                        $dataset[$i][$column] = $columnMeans[$column];
                    } else if (isset($columnModes[$column])) {
                        $dataset[$i][$column] = $columnModes[$column];
                    } else {
                        $dataset[$i][$column] = '';
                    }
                }
            }
        }
        return $dataset;
    }

    /**
     * Legacy: Encode categorical features to numeric values (not used in new backend-driven workflow).
     * 
     * @param array $dataset Dataset with categorical features
     * @return array Dataset with encoded features
     */
    protected function encode_categorical_features($dataset) {
        if (empty($dataset)) {
            return $dataset;
        }

        $columns = array_keys($dataset[0]);

        // Find categorical columns (non-numeric values)
        foreach ($columns as $column) {
            $hasNonNumeric = false;

            // Check a sample of rows to determine if column is categorical
            $sampleSize = min(10, count($dataset));
            for ($i = 0; $i < $sampleSize; $i++) {
                if (isset($dataset[$i][$column]) && !is_numeric($dataset[$i][$column])) {
                    $hasNonNumeric = true;
                    break;
                }
            }

            if ($hasNonNumeric) {
                // Create a mapping of unique values to numeric codes
                $uniqueValues = array();
                foreach ($dataset as $row) {
                    if (isset($row[$column]) && !isset($uniqueValues[$row[$column]])) {
                        $uniqueValues[$row[$column]] = count($uniqueValues);
                    }
                }

                // Apply the mapping
                foreach ($dataset as $i => $row) {
                    if (isset($row[$column])) {
                        $dataset[$i][$column] = isset($uniqueValues[$row[$column]]) ? 
                                             $uniqueValues[$row[$column]] : 0;
                    }
                }
            }
        }

        return $dataset;
    }

    /**
     * Legacy: Normalize numeric features to the range [0,1] (not used in new backend-driven workflow).
     * 
     * @param array $dataset Dataset with numeric features
     * @return array Dataset with normalized features
     */
    protected function normalize_features($dataset) {
        if (empty($dataset)) {
            return $dataset;
        }

        $columns = array_keys($dataset[0]);

        // Find min and max for each column
        $mins = array();
        $maxs = array();

        foreach ($columns as $column) {
            $values = array();
            foreach ($dataset as $row) {
                if (isset($row[$column]) && is_numeric($row[$column])) {
                    $values[] = $row[$column];
                }
            }

            if (!empty($values)) {
                $mins[$column] = min($values);
                $maxs[$column] = max($values);
            } else {
                $mins[$column] = 0;
                $maxs[$column] = 1;
            }
        }

        // Apply min-max normalization
        foreach ($dataset as $i => $row) {
            foreach ($columns as $column) {
                if (isset($row[$column]) && is_numeric($row[$column]) && 
                    $maxs[$column] > $mins[$column]) {
                    $dataset[$i][$column] = ($row[$column] - $mins[$column]) / 
                                         ($maxs[$column] - $mins[$column]);
                }
            }
        }

        return $dataset;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Model trainer for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\analytics;

defined('MOODLE_INTERNAL') || die();

/**
 * Model trainer for student performance prediction.
 *
 * This class is responsible for orchestrating the model training process
 * by calling the Python backend API. No ML logic is performed in PHP.
 */
class model_trainer {
    /** @var int Course ID */
    protected $courseid;

    /** @var int Dataset ID */
    protected $datasetid;

    /** @var data_preprocessor Preprocessor instance */
    protected $preprocessor;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     * @param int $datasetid Dataset ID
     */
    public function __construct($courseid, $datasetid) {
        global $CFG;

        $this->courseid = $courseid;
        $this->datasetid = $datasetid;
        $this->preprocessor = new data_preprocessor($courseid);
    }

    /**
     * Train a new model by calling the Python backend API.
     *
     * @param string $algorithm Algorithm type to use
     * @param array $options Training options
     * @return int ID of the newly created model
     * @throws \moodle_exception on error
     */
    public function train_model($algorithm = null, $options = array()) {
        global $DB, $USER, $CFG;

        if (function_exists('mtrace')) {
            mtrace("Starting model training process via backend API...");
        }

        // Validate inputs
        if (empty($this->courseid) || empty($this->datasetid)) {
            throw new \moodle_exception('invalidinput', 'block_studentperformancepredictor', '',
                'Course ID or Dataset ID is missing');
        }

        // Verify dataset exists and belongs to the course
        $dataset = $DB->get_record('block_spp_datasets',
            array('id' => $this->datasetid, 'courseid' => $this->courseid));
        if (!$dataset) {
            throw new \moodle_exception('invaliddataset', 'block_studentperformancepredictor');
        }
        $dataset_filepath = $dataset->filepath; // Get the full path

        // If no algorithm specified, use the default from settings
        if (empty($algorithm)) {
            $algorithm = get_config('block_studentperformancepredictor', 'defaultalgorithm');
            if (empty($algorithm)) {
                $algorithm = 'randomforest'; // Default fallback
            }
        }

        // Call Python backend for training
        $apiurl = get_config('block_studentperformancepredictor', 'python_api_url');
        if (empty($apiurl)) {
            $apiurl = 'http://localhost:5000/train';
        } else {
            // Ensure API URL ends with the train endpoint
            if (substr($apiurl, -6) !== '/train') {
                $apiurl = rtrim($apiurl, '/') . '/train';
            }
        }

        $apikey = get_config('block_studentperformancepredictor', 'python_api_key');
        if (empty($apikey)) {
            $apikey = 'changeme';
        }

        $payload = [
            'courseid' => $this->courseid,
            'dataset_filepath' => $dataset_filepath, // FIX: Send the full filepath as expected by Python backend
            'algorithm' => $algorithm,
            'userid' => $USER->id
        ];

        // Add any custom options to the payload
        if (!empty($options)) {
            $payload = array_merge($payload, $options);
        }

        $curl = new \curl();
        $curl_options = [
            'CURLOPT_TIMEOUT' => 300, // 5 minutes timeout for training
            'CURLOPT_RETURNTRANSFER' => true,
            'CURLOPT_HTTPHEADER' => [
                'Content-Type: application/json',
                'X-API-Key: ' . $apikey
            ]
        ];

        if (function_exists('mtrace')) {
            mtrace("Sending request to backend API: " . json_encode($payload));
        }

        $response = $curl->post($apiurl, json_encode($payload), $curl_options);
        $httpcode = $curl->get_info()['http_code'] ?? 0;

        if ($httpcode === 200) {
            $data = json_decode($response, true);
            if (!is_array($data) || !isset($data['model_id'])) {
                throw new \moodle_exception('trainingfailed', 'block_studentperformancepredictor', '',
                    'Invalid response from backend: ' . $response);
            }

            if (function_exists('mtrace')) {
                mtrace("Received successful response from backend. Model ID: " . $data['model_id']);
            }

            // Extract model details from response
            $model_id = $data['model_id'];
            $model_path = isset($data['model_path']) ? $data['model_path'] : null;
            $algorithm_used = isset($data['algorithm']) ? $data['algorithm'] : $algorithm;
            $accuracy = isset($data['metrics']['accuracy']) ? $data['metrics']['accuracy'] : null;
            $metrics = isset($data['metrics']) ? json_encode($data['metrics']) : null;

            // Create model record
            $model = new \stdClass();
            $model->courseid = $this->courseid;
            $model->datasetid = $this->datasetid;
            $model->modelname = ucfirst($algorithm_used) . ' Model - ' . date('Y-m-d H:i');
            $model->modelid = $model_id;
            $model->modelpath = $model_path;
            $model->algorithmtype = $algorithm_used;
            $model->featureslist = isset($data['feature_names']) ? json_encode($data['feature_names']) : '[]';
            $model->accuracy = $accuracy;
            $model->metrics = $metrics;
            $model->active = 0; // Not active by default
            $model->trainstatus = 'complete';
            $model->timecreated = time();
            $model->timemodified = time();
            $model->usermodified = $USER->id;

            $model_db_id = $DB->insert_record('block_spp_models', $model);

            if (function_exists('mtrace')) {
                mtrace("Model training completed successfully. Moodle Model ID: $model_db_id");
            }

            // Trigger event for model trained
            $context = \context_course::instance($this->courseid);
            $event = \block_studentperformancepredictor\event\model_trained::create([
                'context' => $context,
                'objectid' => $model_db_id,
                'other' => [
                    'courseid' => $this->courseid,
                    'datasetid' => $this->datasetid,
                    'algorithm' => $algorithm_used
                ]
            ]);
            $event->trigger();

            return $model_db_id;
        } else {
            $error = "HTTP $httpcode: " . $response;
            if (function_exists('mtrace')) {
                mtrace("Backend API error: $error");
            }
            throw new \moodle_exception('trainingfailed', 'block_studentperformancepredictor', '', $error);
        }
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Prediction engine for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\analytics;

defined('MOODLE_INTERNAL') || die();

// Ensure lib.php is included at the top for all global function definitions
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');
require_once($CFG->libdir . '/gradelib.php');

/**
 * Prediction engine for student performance.
 *
 * NOTE: As of the unified plugin architecture, all predictions are made by calling
 * the Python backend /predict endpoint. No ML logic is performed in PHP.
 * This class is responsible only for orchestrating backend calls and storing prediction results.
 */
class predictor {
    /** @var int Course ID */
    protected $courseid;

    /** @var object The model record from database */
    protected $model;

    /** @var object The loaded ML model */
    protected $mlmodel;

    /** @var data_preprocessor Preprocessor instance */
    protected $preprocessor;

    /** @var suggestion_generator Suggestion generator instance */
    protected $suggestiongenerator;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     */
    public function __construct($courseid) {
        global $DB;

        $this->courseid = $courseid;

        // Query for active model - fixed for compatibility
        $params = ['courseid' => $courseid, 'active' => 1, 'trainstatus' => 'complete'];
        $this->model = $DB->get_record('block_spp_models', $params);

        if (!$this->model) {
            throw new \moodle_exception('noactivemodel', 'block_studentperformancepredictor');
        }

        $this->preprocessor = new data_preprocessor($courseid);
        $this->suggestiongenerator = new suggestion_generator($courseid);
    }

    /**
     * Generate predictions for a specific student.
     *
     * @param int $userid User ID
     * @return object Prediction result
     */
    public function predict_for_student($userid) {
        global $DB, $CFG;

        // Get comprehensive student data for prediction
        $studentdata = $this->get_comprehensive_student_data($userid);

        if (empty($studentdata)) {
            throw new \moodle_exception('nostudentdata', 'block_studentperformancepredictor');
        }

        // Create feature vector for prediction
        $features = $this->create_feature_vector($studentdata);

        // Make prediction using the backend
        $prediction = $this->make_prediction($features);

        // Determine risk level based on pass probability
        $risklevel = $this->calculate_risk_level($prediction->passprob);

        // Store prediction in database
        $predictionrecord = new \stdClass();
        $predictionrecord->modelid = $this->model->id;
        $predictionrecord->courseid = $this->courseid;
        $predictionrecord->userid = $userid;
        $predictionrecord->passprob = $prediction->passprob;
        $predictionrecord->riskvalue = $risklevel;
        $predictionrecord->predictiondata = json_encode($prediction->details);
        $predictionrecord->timecreated = time();
        $predictionrecord->timemodified = time();

        try {
            $predictionid = $DB->insert_record('block_spp_predictions', $predictionrecord);

            // Generate suggestions based on prediction
            $this->suggestiongenerator->generate_suggestions($predictionid, $userid, $predictionrecord);

            return $DB->get_record('block_spp_predictions', array('id' => $predictionid));
        } catch (\Exception $e) {
            debugging('Error storing prediction: ' . $e->getMessage(), DEBUG_DEVELOPER);
            throw new \moodle_exception('errorpredicting', 'block_studentperformancepredictor', '', $e->getMessage());
        }
    }

    /**
     * Get comprehensive student data for prediction.
     *
     * @param int $userid User ID
     * @return array Student data for prediction
     */
    protected function get_comprehensive_student_data($userid) {
        global $DB, $CFG;

        $data = array();

        // Get all the student's courses
        $courses = enrol_get_all_users_courses($userid, true);

        // Basic user data
        $user = $DB->get_record('user', array('id' => $userid), 'id, lastname, email, country, timezone, lastaccess, firstaccess');
        $data['user_id'] = $userid;
        $data['days_since_last_access'] = (time() - max(1, $user->lastaccess)) / 86400;
        $data['days_since_first_access'] = (time() - max(1, $user->firstaccess)) / 86400;

        // Initialize all potential data points to 0/default to prevent "Undefined index" notices
        $data['total_courses'] = count($courses);
        $data['activity_level'] = 0;
        $data['submission_count'] = 0;
        $data['grade_average'] = 0;
        $data['grade_count'] = 0;
        $data['total_course_modules_accessed'] = 0;
        $data['current_course_modules_accessed'] = 0;
        $data['total_forum_posts'] = 0;
        $data['current_course_forum_posts'] = 0;
        $data['total_assignment_submissions'] = 0;
        $data['current_course_assignment_submissions'] = 0;
        $data['total_quiz_attempts'] = 0;
        $data['current_course_quiz_attempts'] = 0;
        $data['current_course_grade'] = 0;
        $data['current_course_grade_max'] = 100;
        $data['current_course_grade_percentage'] = 0;
        $data['engagement_score'] = 0;
        $data['historical_performance'] = 0;


        // Calculate 'activity_level' (using logs count for last week for better relevance)
        $sql_activity = "SELECT COUNT(*) FROM {logstore_standard_log}
                         WHERE userid = :userid AND courseid = :courseid
                         AND timecreated > :oneweekago";
        $data['activity_level'] = $DB->count_records_sql($sql_activity, [
            'userid' => $userid,
            'courseid' => $this->courseid,
            'oneweekago' => time() - (7 * 24 * 3600) // Last 7 days
        ]);

        // Calculate 'submission_count'
        $sql_submissions = "SELECT COUNT(*) FROM {assign_submission} sub
                            JOIN {assign} a ON sub.assignment = a.id
                            WHERE sub.userid = :userid AND a.course = :courseid AND sub.status = :status";
        $data['submission_count'] = $DB->count_records_sql($sql_submissions, [
            'userid' => $userid,
            'courseid' => $this->courseid,
            'status' => 'submitted'
        ]);

        // Calculate 'grade_average' and 'grade_count'
        $gradesum = 0;
        $gradecount = 0;
        $sql_grades = "SELECT gg.finalgrade, gi.grademax
                       FROM {grade_items} gi
                       JOIN {grade_grades} gg ON gg.itemid = gi.id
                       WHERE gi.courseid = :courseid AND gg.userid = :userid AND gg.finalgrade IS NOT NULL
                       AND gi.itemtype != 'course'"; // Exclude course total itself
        $grades = $DB->get_records_sql($sql_grades, [
            'courseid' => $this->courseid,
            'userid' => $userid
        ]);

        foreach ($grades as $grade) {
            if ($grade->grademax > 0) {
                $gradesum += ($grade->finalgrade / $grade->grademax);
                $gradecount++;
            }
        }
        $data['grade_average'] = $gradecount > 0 ? $gradesum / $gradecount : 0;
        $data['grade_count'] = $gradecount;


        // Remaining comprehensive data points
        // (These might be used by suggestion_generator or for other comprehensive reporting,
        // but the core features for ML prediction are the 'activity_level', 'submission_count', etc.)

        // Get log counts for course modules accessed - safer query
        $sql = "SELECT COUNT(DISTINCT cmid) FROM {logstore_standard_log}
                WHERE userid = ? AND action = ? AND target = ?";
        $data['total_course_modules_accessed'] = $DB->count_records_sql($sql, [$userid, 'viewed', 'course_module']);

        // Get log counts for current course - safer query
        $sql = "SELECT COUNT(DISTINCT cmid) FROM {logstore_standard_log}
                WHERE userid = ? AND courseid = ? AND action = ? AND target = ?";
        $data['current_course_modules_accessed'] = $DB->count_records_sql($sql, [$userid, $this->courseid, 'viewed', 'course_module']);

        // Forum posts counts - fixed query
        $sql = "SELECT COUNT(*) FROM {forum_posts} fp
                JOIN {forum_discussions} fd ON fp.discussion = fd.id
                WHERE fp.userid = ?";
        $data['total_forum_posts'] = $DB->count_records_sql($sql, [$userid]);

        // Forum posts in current course - fixed query
        $sql = "SELECT COUNT(*) FROM {forum_posts} fp
                JOIN {forum_discussions} fd ON fp.discussion = fd.id
                JOIN {forum} f ON fd.forum = f.id
                WHERE fp.userid = ? AND f.course = ?";
        $data['current_course_forum_posts'] = $DB->count_records_sql($sql, [$userid, $this->courseid]);

        // Assignment submissions
        $params_assign = ['userid' => $userid, 'status' => 'submitted'];
        $data['total_assignment_submissions'] = $DB->count_records('assign_submission', $params_assign);

        // Assignment submissions in current course
        $sql_current_assign_submissions = "SELECT COUNT(*) FROM {assign_submission} sub
                                           JOIN {assign} a ON sub.assignment = a.id
                                           WHERE sub.userid = :userid AND a.course = :courseid AND sub.status = :status";
        $data['current_course_assignment_submissions'] = $DB->count_records_sql($sql_current_assign_submissions, ['userid' => $userid, 'courseid' => $this->courseid, 'status' => 'submitted']);

        // Quiz attempts
        $params_quiz = ['userid' => $userid, 'state' => 'finished'];
        $data['total_quiz_attempts'] = $DB->count_records('quiz_attempts', $params_quiz);

        // Quiz attempts in current course
        $sql_current_quiz_attempts = "SELECT COUNT(*) FROM {quiz_attempts} qa
                                      JOIN {quiz} q ON qa.quiz = q.id
                                      WHERE qa.userid = :userid AND q.course = :courseid AND qa.state = :state";
        $data['current_course_quiz_attempts'] = $DB->count_records_sql($sql_current_quiz_attempts, ['userid' => $userid, 'courseid' => $this->courseid, 'state' => 'finished']);


        // Current course grade
        try {
            $grade = grade_get_course_grade($userid, $this->courseid);
            if ($grade && $grade->grade !== null) {
                $data['current_course_grade'] = $grade->grade;
                $data['current_course_grade_max'] = $grade->grade_item->grademax;
                $data['current_course_grade_percentage'] = ($grade->grade / $grade->grade_item->grademax) * 100;
            } else {
                $data['current_course_grade'] = 0;
                $data['current_course_grade_max'] = 100;
                $data['current_course_grade_percentage'] = 0;
            }
        } catch (\Exception $e) {
            debugging('Error getting course grade: ' . $e->getMessage(), DEBUG_DEVELOPER);
            $data['current_course_grade'] = 0;
            $data['current_course_grade_max'] = 100;
            $data['current_course_grade_percentage'] = 0;
        }

        // Calculate overall engagement score
        $data['engagement_score'] = $this->calculate_engagement_score($data);

        // Calculate historical performance
        $data['historical_performance'] = $this->calculate_historical_performance($userid);

        return $data;
    }

    /**
     * Calculate overall engagement score (0-1).
     *
     * @param array $data Student data
     * @return float Engagement score
     */
    protected function calculate_engagement_score($data) {
        $score = 0;
        $factors = 0;

        // Module access factor
        if (isset($data['current_course_modules_accessed']) && $data['current_course_modules_accessed'] > 0) {
            $score += min(1, $data['current_course_modules_accessed'] / 10); // Scale up to 10 modules
            $factors++;
        }

        // Forum participation factor
        if (isset($data['current_course_forum_posts']) && $data['current_course_forum_posts'] > 0) {
            $score += min(1, $data['current_course_forum_posts'] / 5); // Scale up to 5 posts
            $factors++;
        }

        // Assignment submission factor
        if (isset($data['current_course_assignment_submissions']) && $data['current_course_assignment_submissions'] > 0) {
            $score += min(1, $data['current_course_assignment_submissions'] / 3); // Scale up to 3 submissions
            $factors++;
        }

        // Quiz attempt factor
        if (isset($data['current_course_quiz_attempts']) && $data['current_course_quiz_attempts'] > 0) {
            $score += min(1, $data['current_course_quiz_attempts'] / 3); // Scale up to 3 attempts
            $factors++;
        }

        // Last access factor (more recent = higher score)
        if (isset($data['days_since_last_access']) && $data['days_since_last_access'] < 30) { // Within last month
            $score += max(0, 1 - ($data['days_since_last_access'] / 30));
            $factors++;
        }

        // Return average score, default to 0.5 if no factors available
        return $factors > 0 ? $score / $factors : 0.5;
    }

    /**
     * Calculate historical performance score (0-1).
     *
     * @param int $userid User ID
     * @return float Historical performance score
     */
    protected function calculate_historical_performance($userid) {
        global $DB;

        // Get average course grade percentage for completed courses
        $sql = "SELECT AVG(gg.finalgrade/gi.grademax) as avggrade
                FROM {grade_grades} gg
                JOIN {grade_items} gi ON gg.itemid = gi.id
                WHERE gg.userid = ? AND gi.itemtype = ? AND gg.finalgrade IS NOT NULL";

        $result = $DB->get_record_sql($sql, [$userid, 'course']);

        if ($result && $result->avggrade !== null) {
            return (float)$result->avggrade;
        }

        return 0.5; // Default to neutral if no history
    }

    /**
     * Create feature vector from student data for prediction.
     *
     * @param array $studentdata Student data
     * @return array Feature vector
     */
    protected function create_feature_vector($studentdata) {
        // The feature names in the model - safer handling with empty check
        $featurelist = [];
        if (!empty($this->model->featureslist)) {
            try {
                $featurelist = json_decode($this->model->featureslist, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    debugging('Error decoding features list: ' . json_last_error_msg(), DEBUG_DEVELOPER);
                    $featurelist = [];
                }
            } catch (\Exception $e) {
                debugging('Error decoding features list: ' . $e->getMessage(), DEBUG_DEVELOPER);
            }
        }

        // If featureslist is not a valid array, use a default set matching ml_backend.py's sample data
        if (empty($featurelist) || !is_array($featurelist)) {
            $featurelist = [
                'activity_level',       // Corresponds to logs count / module accesses
                'submission_count',     // Corresponds to assignment submissions
                'grade_average',        // Corresponds to average grade
                'grade_count'           // Corresponds to count of graded items
            ];
            debugging('Using fallback featurelist. Ensure your Python backend model was trained with these features: ' . implode(', ', $featurelist), DEBUG_DEVELOPER);
        }

        $features = [];

        foreach ($featurelist as $feature) {
            // Check if feature exists in student data
            if (isset($studentdata[$feature])) {
                $features[] = $studentdata[$feature];
            } else {
                // Use 0 for missing features and log a warning
                debugging('Missing feature "' . $feature . '" for prediction. Using 0.', DEBUG_DEVELOPER);
                $features[] = 0;
            }
        }

        return $features;
    }

    /**
     * Make prediction using the model (backend-driven orchestration).
     *
     * This method calls the Python backend /predict endpoint and uses the returned prediction/probabilities.
     * No ML logic is performed in PHP.
     *
     * @param array $features Feature vector
     * @return object Prediction result
     */
    protected function make_prediction($features) {
        global $CFG;
        $result = new \stdClass();
        $result->details = array();

        // Call Python backend for prediction
        $apiurl = get_config('block_studentperformancepredictor', 'python_api_url');
        if (empty($apiurl)) {
            $apiurl = 'http://localhost:5000/predict';
        } else {
            // Ensure API URL ends with the predict endpoint
            if (substr($apiurl, -8) !== '/predict') {
                $apiurl = rtrim($apiurl, '/') . '/predict';
            }
        }
        $apikey = get_config('block_studentperformancepredictor', 'python_api_key');
        if (empty($apikey)) {
            $apikey = 'changeme';
        }

        // Initialize curl
        $curl = new \curl();
        $payload = [
            'model_id' => $this->model->modelid,
            'features' => $features
        ];
        $options = [
            'CURLOPT_TIMEOUT' => 60,
            'CURLOPT_RETURNTRANSFER' => true,
            'CURLOPT_HTTPHEADER' => [
                'Content-Type: application/json',
                'X-API-Key: ' . $apikey
            ]
        ];

        // Log the request for debugging
        debugging('Prediction request to ' . $apiurl . ': ' . json_encode($payload), DEBUG_DEVELOPER);

        try {
            $response = $curl->post($apiurl, json_encode($payload), $options);
            $httpcode = $curl->get_info()['http_code'] ?? 0;

            debugging('Prediction response code: ' . $httpcode, DEBUG_DEVELOPER);

            if ($httpcode === 200) {
                $data = json_decode($response, true);
                if (is_array($data) && isset($data['prediction'])) {
                    // Get the pass probability from response
                    if (isset($data['probabilities']) && is_array($data['probabilities']) && count($data['probabilities']) >= 2) {
                        // Use the probability for class 1 (passing)
                        $result->passprob = $data['probabilities'][1];
                    } else if (isset($data['probabilities']) && is_array($data['probabilities'])) {
                        // Use the highest probability if class is unclear
                        $result->passprob = max($data['probabilities']);
                    } else if ($data['prediction'] == 1) {
                        // If only binary prediction available
                        $result->passprob = 0.75; // Default high probability for positive prediction
                    } else {
                        $result->passprob = 0.25; // Default low probability for negative prediction
                    }
                    $result->details['backend'] = $data;
                } else {
                    debugging('Invalid prediction response format: ' . $response, DEBUG_DEVELOPER);
                    $result->passprob = 0.5;
                    $result->details['backend_error'] = 'Invalid response format: ' . substr($response, 0, 200);
                }
            } else {
                debugging('Backend API error: HTTP ' . $httpcode . ' - ' . $response, DEBUG_DEVELOPER);
                $result->passprob = 0.5;
                $result->details['backend_error'] = 'HTTP error ' . $httpcode . ': ' . substr($response, 0, 200);
            }
        } catch (\Exception $e) {
            debugging('Exception during prediction API call: ' . $e->getMessage(), DEBUG_DEVELOPER);
            $result->passprob = 0.5;
            $result->details['backend_error'] = 'Exception: ' . $e->getMessage();
        }

        // Ensure passprob is within valid range
        $result->passprob = max(0, min(1, $result->passprob));
        return $result;
    }

    /**
     * Calculate risk level based on pass probability.
     *
     * @param float $passprob Pass probability
     * @return int Risk level (1=low, 2=medium, 3=high)
     */
    protected function calculate_risk_level($passprob) {
        // Get risk thresholds from settings with defaults
        $lowrisk = get_config('block_studentperformancepredictor', 'lowrisk');
        if (empty($lowrisk) || !is_numeric($lowrisk)) {
            $lowrisk = 0.7; // Default
        }

        $mediumrisk = get_config('block_studentperformancepredictor', 'mediumrisk');
        if (empty($mediumrisk) || !is_numeric($mediumrisk)) {
            $mediumrisk = 0.4; // Default
        }

        if ($passprob >= $lowrisk) {
            return 1; // Low risk
        } else if ($passprob >= $mediumrisk) {
            return 2; // Medium risk
        } else {
            return 3; // High risk
        }
    }

    /**
     * Generate predictions for all students in the course.
     *
     * @return array Array of prediction records
     */
    public function predict_for_all_students() {
        global $DB;

        $context = \context_course::instance($this->courseid);
        $students = get_enrolled_users($context, 'moodle/course:isincompletionreports');

        $predictions = array();
        $errors = array();

        foreach ($students as $student) {
            try {
                $prediction = $this->predict_for_student($student->id);
                $predictions[] = $prediction;
            } catch (\Exception $e) {
                // Log error and continue with next student
                debugging('Error predicting for student ' . $student->id . ': ' . $e->getMessage(), DEBUG_DEVELOPER);
                $errors[$student->id] = $e->getMessage();
            }
        }

        // Log summary
        debugging('Predictions generated for ' . count($predictions) . ' students with ' .
                 count($errors) . ' errors', DEBUG_DEVELOPER);

        return $predictions;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Suggestion generator for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <your.email@example.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\analytics;

defined('MOODLE_INTERNAL') || die();

use moodle_exception;
use dml_exception;

// Moodle core library includes for required functions/classes/constants
global $CFG;
require_once($CFG->dirroot . '/course/lib.php'); // get_course
require_once($CFG->libdir . '/completionlib.php'); // completion_info
require_once($CFG->libdir . '/gradelib.php'); // grade_get_course_grade
require_once($CFG->libdir . '/moodlelib.php'); // get_string, debugging

if (!defined('COMPLETION_COMPLETE')) {
    define('COMPLETION_COMPLETE', 1);
}

/**
 * Generates personalized suggestions for students.
 *
 * NOTE: In the unified plugin architecture, suggestions are generated based on backend-driven
 * predictions and risk levels. This class operates on the results of backend predictions only.
 * No ML logic is performed in PHP.
 */
class suggestion_generator {
    /** @var int Course ID */
    protected $courseid;

    /** @var object Course object */
    protected $course;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     * @throws \moodle_exception If course not found
     */
    public function __construct($courseid) {
        $this->courseid = $courseid;
        $this->course = get_course($courseid);
        if (!$this->course) {
            throw new moodle_exception('invalidcourseid', 'error');
        }
    }

    /**
     * Generate suggestions based on prediction (backend-driven orchestration).
     *
     * This method uses the risk value from the backend prediction to generate suggestions.
     * No ML logic is performed in PHP.
     *
     * @param int $predictionid Prediction ID
     * @param int $userid User ID
     * @param object $prediction Prediction data (must have property riskvalue)
     * @return array Generated suggestions (IDs of inserted records)
     * @throws \dml_exception
     */
    public function generate_suggestions($predictionid, $userid, $prediction) {
        global $DB;

        $suggestions = array();

        // Get course modules for current course
        $modinfo = get_fast_modinfo($this->courseid);
        $cms = $modinfo->get_cms();

        // Get completion info for current course
        $completion = new completion_info($this->course);

        // Get activity type suggestions based on risk level
        $activitySuggestions = $this->get_activity_suggestions_by_risk($prediction->riskvalue);

        // Get activity completions for current course
        $completions = array();
        foreach ($cms as $cm) {
            if (!$cm->uservisible) {
                continue;
            }
            $completiondata = $completion->get_data($cm, false, $userid);
            $completions[$cm->id] = isset($completiondata->completionstate) ? $completiondata->completionstate : null;
        }

        // Identify weak areas based on grades
        $weakAreas = $this->identify_weak_areas($userid);

        // Generate personalized suggestions
        $allSuggestions = array();

        // 1. Add course-specific suggestions based on incomplete activities
        foreach ($cms as $cm) {
            if (!$cm->uservisible || $cm->modname == 'label') {
                continue;
            }

            // Check if activity is completed
            $isCompleted = isset($completions[$cm->id]) &&
                $completions[$cm->id] == COMPLETION_COMPLETE;

            // If not completed and this activity type is in our suggestions
            if (!$isCompleted && isset($activitySuggestions[$cm->modname])) {
                $suggestionRecord = new \stdClass();
                $suggestionRecord->predictionid = $predictionid;
                $suggestionRecord->courseid = $this->courseid;
                $suggestionRecord->userid = $userid;
                $suggestionRecord->cmid = $cm->id;
                $suggestionRecord->resourcetype = $cm->modname;
                $suggestionRecord->resourceid = $cm->instance;
                $suggestionRecord->priority = $activitySuggestions[$cm->modname]['priority'];

                // Customize reason based on weak areas
                $reason = $activitySuggestions[$cm->modname]['reason'];
                foreach ($weakAreas as $area) {
                    if (stripos($cm->name, $area) !== false) {
                        $reason .= ' ' . get_string('suggestion_targeted_area', 'block_studentperformancepredictor',
                                                      array('area' => $area));
                        $suggestionRecord->priority += 2; // Increase priority for targeted suggestions
                        break;
                    }
                }

                $suggestionRecord->reason = $reason;
                $suggestionRecord->timecreated = time();
                $suggestionRecord->viewed = 0;
                $suggestionRecord->completed = 0;

                $allSuggestions[] = $suggestionRecord;
            }
        }

        // 2. Add general study skill suggestions based on overall performance
        $generalSuggestions = $this->get_general_study_suggestions($prediction->riskvalue, $weakAreas);
        foreach ($generalSuggestions as $suggestion) {
            $suggestionRecord = new \stdClass();
            $suggestionRecord->predictionid = $predictionid;
            $suggestionRecord->courseid = $this->courseid;
            $suggestionRecord->userid = $userid;
            $suggestionRecord->cmid = 0; // No specific course module
            $suggestionRecord->resourcetype = 'general';
            $suggestionRecord->resourceid = 0;
            $suggestionRecord->priority = $suggestion['priority'];
            $suggestionRecord->reason = $suggestion['reason'];
            $suggestionRecord->timecreated = time();
            $suggestionRecord->viewed = 0;
            $suggestionRecord->completed = 0;

            $allSuggestions[] = $suggestionRecord;
        }

        // Sort suggestions by priority (highest first)
        usort($allSuggestions, function($a, $b) {
            return $b->priority - $a->priority;
        });

        // Save top 5 suggestions to database
        $count = 0;
        foreach ($allSuggestions as $suggestion) {
            try {
                $suggestions[] = $DB->insert_record('block_spp_suggestions', $suggestion);
            } catch (dml_exception $e) {
                // Log error but continue
                debugging('Failed to insert suggestion: ' . $e->getMessage(), DEBUG_DEVELOPER);
            }
            $count++;
            if ($count >= 5) break; // Limit to top 5 suggestions
        }

        return $suggestions;
    }

    /**
     * Get activity suggestions based on risk level.
     *
     * @param int $risklevel Risk level (1-3)
     * @return array Activity suggestions
     */
    protected function get_activity_suggestions_by_risk($risklevel) {
        $suggestions = array();

        // Low risk suggestions
        if ($risklevel == 1) {
            $suggestions['forum'] = array(
                'priority' => 3,
                'reason' => get_string('suggestion_forum_low', 'block_studentperformancepredictor')
            );

            $suggestions['resource'] = array(
                'priority' => 2,
                'reason' => get_string('suggestion_resource_low', 'block_studentperformancepredictor')
            );
        }

        // Medium risk suggestions
        else if ($risklevel == 2) {
            $suggestions['quiz'] = array(
                'priority' => 7,
                'reason' => get_string('suggestion_quiz_medium', 'block_studentperformancepredictor')
            );

            $suggestions['forum'] = array(
                'priority' => 5,
                'reason' => get_string('suggestion_forum_medium', 'block_studentperformancepredictor')
            );

            $suggestions['assign'] = array(
                'priority' => 6,
                'reason' => get_string('suggestion_assign_medium', 'block_studentperformancepredictor')
            );

            $suggestions['resource'] = array(
                'priority' => 4,
                'reason' => get_string('suggestion_resource_medium', 'block_studentperformancepredictor')
            );
        }

        // High risk suggestions
        else if ($risklevel == 3) {
            $suggestions['quiz'] = array(
                'priority' => 9,
                'reason' => get_string('suggestion_quiz_high', 'block_studentperformancepredictor')
            );

            $suggestions['forum'] = array(
                'priority' => 7,
                'reason' => get_string('suggestion_forum_high', 'block_studentperformancepredictor')
            );

            $suggestions['assign'] = array(
                'priority' => 10,
                'reason' => get_string('suggestion_assign_high', 'block_studentperformancepredictor')
            );

            $suggestions['resource'] = array(
                'priority' => 8,
                'reason' => get_string('suggestion_resource_high', 'block_studentperformancepredictor')
            );

            $suggestions['workshop'] = array(
                'priority' => 6,
                'reason' => get_string('suggestion_workshop_high', 'block_studentperformancepredictor')
            );
        }

        return $suggestions;
    }

    /**
     * Get general study skill suggestions based on risk level and weak areas.
     *
     * @param int $risklevel Risk level (1-3)
     * @param array $weakAreas Array of weak subject areas
     * @return array General study suggestions
     */
    protected function get_general_study_suggestions($risklevel, $weakAreas) {
        $suggestions = array();

        // Add time management suggestion for all risk levels
        $suggestions[] = array(
            'priority' => 3 + $risklevel,
            'reason' => get_string('suggestion_time_management', 'block_studentperformancepredictor')
        );

        // Add engagement suggestion for medium and high risk
        if ($risklevel >= 2) {
            $suggestions[] = array(
                'priority' => 4 + $risklevel,
                'reason' => get_string('suggestion_engagement', 'block_studentperformancepredictor')
            );
        }

        // Add study group suggestion for high risk
        if ($risklevel == 3) {
            $suggestions[] = array(
                'priority' => 8,
                'reason' => get_string('suggestion_study_group', 'block_studentperformancepredictor')
            );

            $suggestions[] = array(
                'priority' => 9,
                'reason' => get_string('suggestion_instructor_help', 'block_studentperformancepredictor')
            );
        }

        // Add weak area specific suggestions
        if (!empty($weakAreas)) {
            foreach ($weakAreas as $index => $area) {
                if ($index < 2) { // Limit to top 2 weak areas
                    $suggestions[] = array(
                        'priority' => 7 + $risklevel,
                        'reason' => get_string('suggestion_weak_area', 'block_studentperformancepredictor',
                                                array('area' => $area))
                    );
                }
            }
        }

        return $suggestions;
    }

    /**
     * Identify weak areas based on grades.
     *
     * @param int $userid User ID
     * @return array List of weak subject areas
     */
    protected function identify_weak_areas($userid) {
        global $DB;

        $weakAreas = array();

        // Get all grade items for the current course
        $sql = "SELECT gi.id, gi.itemname, gi.itemtype, gi.itemmodule, gi.iteminstance, \
                       gg.finalgrade, gi.grademax \
                FROM {grade_items} gi\n                LEFT JOIN {grade_grades} gg ON gg.itemid = gi.id AND gg.userid = :userid\n                WHERE gi.courseid = :courseid \n                AND gi.itemtype != 'course'\n                AND gg.finalgrade IS NOT NULL";

        $params = [
            'userid' => $userid,
            'courseid' => $this->courseid
        ];

        $gradeItems = $DB->get_records_sql($sql, $params);

        // Group items by module/category
        $modulePerformance = [];

        foreach ($gradeItems as $item) {
            // Skip items with no max grade
            if (empty($item->grademax) || $item->grademax == 0) {
                continue;
            }

            $percentage = ($item->finalgrade / $item->grademax) * 100;

            // Use module name or item name as category
            $category = !empty($item->itemmodule) ? $item->itemmodule : $item->itemname;

            if (!isset($modulePerformance[$category])) {
                $modulePerformance[$category] = [
                    'sum' => 0,
                    'count' => 0
                ];
            }

            $modulePerformance[$category]['sum'] += $percentage;
            $modulePerformance[$category]['count']++;
        }

        // Find weak areas (below 70%)
        foreach ($modulePerformance as $module => $data) {
            if ($data['count'] > 0) {
                $average = $data['sum'] / $data['count'];
                if ($average < 70) {
                    $weakAreas[] = $module;
                }
            }
        }

        // If no specific weak areas found, add a general area
        if (empty($weakAreas)) {
            // Get overall course grade
            $grade = grade_get_course_grade($userid, $this->courseid);
            if ($grade && isset($grade->grade) && $grade->grade !== null && isset($grade->grade_item->grademax) && $grade->grade_item->grademax > 0) {
                $percentage = ($grade->grade / $grade->grade_item->grademax) * 100;

                if ($percentage < 70) {
                    $weakAreas[] = 'Course Content';
                } else {
                    // Even if overall grade is good, suggest general improvement
                    $weakAreas[] = 'Study Skills';
                }
            } else {
                // If no grades available
                $weakAreas[] = 'Course Engagement';
            }
        }

        return $weakAreas;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_studentperformancepredictor\analytics;

defined('MOODLE_INTERNAL') || die();

/**
 * Training manager for student performance predictor.
 *
 * This class manages the model training process through the Python backend API.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class training_manager {
    /**
     * Schedules a model training task.
     *
     * @param int $courseid The course ID
     * @param int $datasetid The dataset ID
     * @param string|null $algorithm Optional algorithm to use
     * @return bool True if task was scheduled successfully
     */
    public static function schedule_training(int $courseid, int $datasetid, ?string $algorithm = null): bool {
        global $USER, $DB;

        // Verify the dataset exists and belongs to the course.
        $dataset = $DB->get_record('block_spp_datasets', ['id' => $datasetid, 'courseid' => $courseid]);
        if (!$dataset) {
            debugging('Dataset not found or does not belong to course', DEBUG_DEVELOPER);
            return false;
        }

        // Create adhoc task.
        $task = new \block_studentperformancepredictor\task\adhoc_train_model();
        $customdata = [
            'courseid' => $courseid,
            'datasetid' => $datasetid,
            'algorithm' => $algorithm,
            'userid' => $USER->id,
            'timequeued' => time()
        ];
        $task->set_custom_data($customdata);

        // Add debugging information.
        debugging('Scheduling training task for course ' . $courseid . ' with dataset ' . $datasetid, DEBUG_DEVELOPER);

        try {
            // Queue the task with high priority.
            \core\task\manager::queue_adhoc_task($task, true);
            debugging('Training task scheduled successfully', DEBUG_DEVELOPER);

            // Also create a record in block_spp_models table with trainstatus='pending'
            $model = new \stdClass();
            $model->courseid = $courseid;
            $model->datasetid = $datasetid;
            $model->modelname = ($algorithm ? ucfirst($algorithm) : 'Model') . ' - ' . date('Y-m-d H:i');
            $model->algorithmtype = $algorithm ?? 'randomforest';
            $model->active = 0;
            $model->trainstatus = 'pending';
            $model->timecreated = time();
            $model->timemodified = time();
            $model->usermodified = $USER->id;

            $modelid = $DB->insert_record('block_spp_models', $model);
            if ($modelid) {
                // Update task custom data with modelid
                $customdata['modelid'] = $modelid;
                $task->set_custom_data($customdata);
                \core\task\manager::reschedule_or_queue_adhoc_task($task, true);

                // Log initial training event
                self::log_training_event($modelid, 'scheduled', 'Training task scheduled');
            }

            return true;
        } catch (\Exception $e) {
            debugging('Error scheduling training task: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return false;
        }
    }

    /**
     * Check if there's already a training task scheduled.
     *
     * @param int $courseid The course ID
     * @return bool True if a task exists
     */
    public static function has_pending_training(int $courseid): bool {
        global $DB;

        // Check for pending adhoc_train_model tasks
        $sql = "SELECT COUNT(*) FROM {task_adhoc}
                WHERE classname = ?
                AND " . $DB->sql_like('customdata', '?') . "
                AND nextruntime > ?";

        $classname = '\\block_studentperformancepredictor\\task\\adhoc_train_model';
        $customdata = '%"courseid":' . $courseid . '%';
        $count = $DB->count_records_sql($sql, [$classname, $customdata, time()]);

        return $count > 0;
    }

    /**
     * Logs a training event.
     *
     * @param int $modelid The model ID
     * @param string $event The event type
     * @param string $message The log message
     * @param string $level The log level (error, warning, info)
     * @return bool True if logged successfully
     */
    public static function log_training_event(int $modelid, string $event, string $message, string $level = 'info'): bool {
        global $DB;
        // Only log if modelid is valid
        if (empty($modelid) || $modelid <= 0) {
            debugging("Skipping training log: invalid modelid ($modelid) for event '$event'", DEBUG_DEVELOPER);
            return false;
        }

        $log = new \stdClass();
        $log->modelid = $modelid;
        $log->event = $event;
        $log->message = $message;
        $log->level = $level;
        $log->timecreated = time();

        try {
            $DB->insert_record('block_spp_training_log', $log);
            debugging("Training log: [$level] $event - $message", DEBUG_DEVELOPER);
            return true;
        } catch (\Exception $e) {
            debugging('Error logging training event: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return false;
        }
    }

    /**
     * Update model status after training.
     *
     * @param int $modelid The model ID
     * @param string $status New status ('complete', 'failed')
     * @param array $data Additional data (metrics, error message, etc.)
     * @return bool True if updated successfully
     */
    public static function update_model_status(int $modelid, string $status, array $data = []): bool {
        global $DB;

        // Only update if modelid is valid
        if (empty($modelid) || $modelid <= 0) {
            debugging("Cannot update model status: invalid modelid ($modelid)", DEBUG_DEVELOPER);
            return false;
        }

        try {
            $model = $DB->get_record('block_spp_models', ['id' => $modelid]);
            if (!$model) {
                debugging("Model not found with ID: $modelid", DEBUG_DEVELOPER);
                return false;
            }

            // Update model fields
            $model->trainstatus = $status;
            $model->timemodified = time();

            // Add any additional data
            if (isset($data['accuracy'])) {
                $model->accuracy = $data['accuracy'];
            }

            if (isset($data['metrics'])) {
                $model->metrics = json_encode($data['metrics']);
            }

            if (isset($data['modelid'])) {
                $model->modelid = $data['modelid'];
            }

            if (isset($data['modelpath'])) {
                $model->modelpath = $data['modelpath'];
            }

            if (isset($data['error'])) {
                $model->errormessage = $data['error'];
                self::log_training_event($modelid, 'error', $data['error'], 'error');
            }

            // Update the record
            $DB->update_record('block_spp_models', $model);

            // Log the status change
            self::log_training_event($modelid, 'status_change', "Model status changed to: $status");

            return true;
        } catch (\Exception $e) {
            debugging('Error updating model status: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return false;
        }
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Event triggered when a model is trained.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\event;

defined('MOODLE_INTERNAL') || die();

/**
 * Event triggered when a model is trained.
 */
class model_trained extends \core\event\base {

    /**
     * Initialize the event.
     */
    protected function init() {
        $this->data['crud'] = 'c'; // Create
        $this->data['edulevel'] = self::LEVEL_OTHER;
        $this->data['objecttable'] = 'block_spp_models';
    }

    /**
     * Get the event name.
     *
     * @return string Event name
     */
    public static function get_name() {
        return get_string('event_model_trained', 'block_studentperformancepredictor');
    }

    /**
     * Get the event description.
     *
     * @return string Event description
     */
    public function get_description() {
        return "The user with id '{$this->userid}' trained a new prediction model with id '{$this->objectid}' for the course with id '{$this->courseid}'.";
    }

    /**
     * Get the event URL.
     *
     * @return \moodle_url Event URL
     */
    public function get_url() {
        return new \moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', [
            'courseid' => $this->courseid,
            'modelid' => $this->objectid
        ]);
    }

    /**
     * Get the legacy log data.
     *
     * @return array Legacy log data
     */
    protected function get_legacy_logdata() {
        return [
            $this->courseid, 
            'block_studentperformancepredictor', 
            'train_model',
            $this->get_url()->out_as_local_url(), 
            $this->objectid, 
            $this->contextinstanceid
        ];
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External API for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\external;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * External API class for Student Performance Predictor block.
 */
class api extends \external_api {

    /**
     * Returns description of mark_suggestion_viewed parameters.
     *
     * @return \external_function_parameters
     */
    public static function mark_suggestion_viewed_parameters() {
        return new \external_function_parameters([
            'suggestionid' => new \external_value(PARAM_INT, 'Suggestion ID')
        ]);
    }

    /**
     * Mark a suggestion as viewed.
     *
     * @param int $suggestionid Suggestion ID
     * @return array Operation result
     */
    public static function mark_suggestion_viewed($suggestionid) {
        global $DB, $USER;

        // Validate parameters.
        $params = self::validate_parameters(self::mark_suggestion_viewed_parameters(), [
            'suggestionid' => $suggestionid
        ]);

        // Get suggestion.
        $suggestion = $DB->get_record('block_spp_suggestions', ['id' => $params['suggestionid']], '*', MUST_EXIST);

        // Security checks.
        $context = \context_course::instance($suggestion->courseid);
        self::validate_context($context);

        // Only the user who received the suggestion can mark it as viewed.
        if ($suggestion->userid != $USER->id) {
            throw new \moodle_exception('nopermission', 'block_studentperformancepredictor');
        }

        // Mark as viewed.
        $success = block_studentperformancepredictor_mark_suggestion_viewed($suggestion->id);

        return [
            'status' => $success,
            'message' => $success ? get_string('suggestion_marked_viewed', 'block_studentperformancepredictor') 
                                 : get_string('suggestion_marked_viewed_error', 'block_studentperformancepredictor')
        ];
    }

    /**
     * Returns description of mark_suggestion_viewed returns.
     *
     * @return \external_single_structure
     */
    public static function mark_suggestion_viewed_returns() {
        return new \external_single_structure([
            'status' => new \external_value(PARAM_BOOL, 'Operation success status'),
            'message' => new \external_value(PARAM_TEXT, 'Operation message')
        ]);
    }

    /**
     * Returns description of mark_suggestion_completed parameters.
     *
     * @return \external_function_parameters
     */
    public static function mark_suggestion_completed_parameters() {
        return new \external_function_parameters([
            'suggestionid' => new \external_value(PARAM_INT, 'Suggestion ID')
        ]);
    }

    /**
     * Mark a suggestion as completed.
     *
     * @param int $suggestionid Suggestion ID
     * @return array Operation result
     */
    public static function mark_suggestion_completed($suggestionid) {
        global $DB, $USER;

        // Validate parameters.
        $params = self::validate_parameters(self::mark_suggestion_completed_parameters(), [
            'suggestionid' => $suggestionid
        ]);

        // Get suggestion.
        $suggestion = $DB->get_record('block_spp_suggestions', ['id' => $params['suggestionid']], '*', MUST_EXIST);

        // Security checks.
        $context = \context_course::instance($suggestion->courseid);
        self::validate_context($context);

        // Only the user who received the suggestion can mark it as completed.
        if ($suggestion->userid != $USER->id) {
            throw new \moodle_exception('nopermission', 'block_studentperformancepredictor');
        }

        // Mark as completed.
        $success = block_studentperformancepredictor_mark_suggestion_completed($suggestion->id);

        return [
            'status' => $success,
            'message' => $success ? get_string('suggestion_marked_completed', 'block_studentperformancepredictor') 
                                 : get_string('suggestion_marked_completed_error', 'block_studentperformancepredictor')
        ];
    }

    /**
     * Returns description of mark_suggestion_completed returns.
     *
     * @return \external_single_structure
     */
    public static function mark_suggestion_completed_returns() {
        return new \external_single_structure([
            'status' => new \external_value(PARAM_BOOL, 'Operation success status'),
            'message' => new \external_value(PARAM_TEXT, 'Operation message')
        ]);
    }

    /**
     * Returns description of get_student_predictions parameters.
     *
     * @return \external_function_parameters
     */
    public static function get_student_predictions_parameters() {
        return new \external_function_parameters([
            'courseid' => new \external_value(PARAM_INT, 'Course ID'),
            'userid' => new \external_value(PARAM_INT, 'User ID', VALUE_DEFAULT, 0)
        ]);
    }

    /**
     * Get predictions for a student.
     *
     * @param int $courseid Course ID
     * @param int $userid User ID (0 for current user)
     * @return array Prediction data
     */
    public static function get_student_predictions($courseid, $userid = 0) {
        global $USER, $DB;

        // Validate parameters.
        $params = self::validate_parameters(self::get_student_predictions_parameters(), [
            'courseid' => $courseid,
            'userid' => $userid
        ]);

        // Security checks.
        $context = \context_course::instance($params['courseid']);
        self::validate_context($context);

        // If no user ID specified, use current user.
        if (empty($params['userid'])) {
            $params['userid'] = $USER->id;
        }

        // Check permission if viewing other user's predictions.
        if ($params['userid'] != $USER->id && !has_capability('block/studentperformancepredictor:viewallpredictions', $context)) {
            throw new \moodle_exception('nopermission', 'block_studentperformancepredictor');
        }

        // Get prediction.
        $prediction = block_studentperformancepredictor_get_student_prediction($params['courseid'], $params['userid']);

        if (!$prediction) {
            return [
                'has_prediction' => false,
                'message' => get_string('noprediction', 'block_studentperformancepredictor')
            ];
        }

        // Get suggestions.
        $suggestions = block_studentperformancepredictor_get_suggestions($prediction->id);

        $suggestiondata = [];
        foreach ($suggestions as $suggestion) {
            $suggestiondata[] = [
                'id' => $suggestion->id,
                'reason' => $suggestion->reason,
                'resource_type' => $suggestion->resourcetype,
                'viewed' => (bool)$suggestion->viewed,
                'completed' => (bool)$suggestion->completed,
                'cmid' => $suggestion->cmid,
                'cmname' => $suggestion->cmname ?? '',
                'modulename' => $suggestion->modulename ?? ''
            ];
        }

        return [
            'has_prediction' => true,
            'prediction' => [
                'id' => $prediction->id,
                'pass_probability' => round($prediction->passprob * 100),
                'risk_level' => $prediction->riskvalue,
                'risk_text' => block_studentperformancepredictor_get_risk_text($prediction->riskvalue),
                'time_created' => $prediction->timecreated,
                'time_modified' => $prediction->timemodified
            ],
            'suggestions' => $suggestiondata
        ];
    }

    /**
     * Returns description of get_student_predictions returns.
     *
     * @return \external_single_structure
     */
    public static function get_student_predictions_returns() {
        return new \external_single_structure([
            'has_prediction' => new \external_value(PARAM_BOOL, 'Whether a prediction exists'),
            'prediction' => new \external_single_structure([
                'id' => new \external_value(PARAM_INT, 'Prediction ID'),
                'pass_probability' => new \external_value(PARAM_INT, 'Pass probability percentage'),
                'risk_level' => new \external_value(PARAM_INT, 'Risk level (1-3)'),
                'risk_text' => new \external_value(PARAM_TEXT, 'Risk level text'),
                'time_created' => new \external_value(PARAM_INT, 'Time created timestamp'),
                'time_modified' => new \external_value(PARAM_INT, 'Time modified timestamp')
            ], 'Prediction data', VALUE_OPTIONAL),
            'suggestions' => new \external_multiple_structure(
                new \external_single_structure([
                    'id' => new \external_value(PARAM_INT, 'Suggestion ID'),
                    'reason' => new \external_value(PARAM_TEXT, 'Suggestion reason'),
                    'resource_type' => new \external_value(PARAM_TEXT, 'Resource type'),
                    'viewed' => new \external_value(PARAM_BOOL, 'Whether suggestion was viewed'),
                    'completed' => new \external_value(PARAM_BOOL, 'Whether suggestion was completed'),
                    'cmid' => new \external_value(PARAM_INT, 'Course module ID', VALUE_OPTIONAL),
                    'cmname' => new \external_value(PARAM_TEXT, 'Course module name', VALUE_OPTIONAL),
                    'modulename' => new \external_value(PARAM_TEXT, 'Module name', VALUE_OPTIONAL)
                ]),
                'Suggestions',
                VALUE_OPTIONAL
            ),
            'message' => new \external_value(PARAM_TEXT, 'Message if no prediction', VALUE_OPTIONAL)
        ]);
    }

    /**
     * Returns description of trigger_model_training parameters.
     *
     * @return \external_function_parameters
     */
    public static function trigger_model_training_parameters() {
        return new \external_function_parameters([
            'courseid' => new \external_value(PARAM_INT, 'Course ID'),
            'datasetid' => new \external_value(PARAM_INT, 'Dataset ID'),
            'algorithm' => new \external_value(PARAM_TEXT, 'Algorithm to use', VALUE_DEFAULT, '')
        ]);
    }

    /**
     * Trigger model training.
     *
     * @param int $courseid Course ID
     * @param int $datasetid Dataset ID
     * @param string $algorithm Algorithm to use
     * @return array Operation result
     */
    public static function trigger_model_training($courseid, $datasetid, $algorithm = '') {
        global $USER;

        // Validate parameters.
        $params = self::validate_parameters(self::trigger_model_training_parameters(), [
            'courseid' => $courseid,
            'datasetid' => $datasetid,
            'algorithm' => $algorithm
        ]);

        // Security checks.
        $context = \context_course::instance($params['courseid']);
        self::validate_context($context);

        // Check permission.
        require_capability('block/studentperformancepredictor:managemodels', $context);

        // Queue the training task.
        $task = new \block_studentperformancepredictor\task\train_model();
        $task->set_custom_data([
            'courseid' => $params['courseid'],
            'datasetid' => $params['datasetid'],
            'algorithm' => $params['algorithm'],
            'userid' => $USER->id
        ]);

        // Queue the task to run as soon as possible.
        \core\task\manager::queue_adhoc_task($task, true);

        return [
            'status' => true,
            'message' => get_string('model_training_queued', 'block_studentperformancepredictor')
        ];
    }

    /**
     * Returns description of trigger_model_training returns.
     *
     * @return \external_single_structure
     */
    public static function trigger_model_training_returns() {
        return new \external_single_structure([
            'status' => new \external_value(PARAM_BOOL, 'Operation success status'),
            'message' => new \external_value(PARAM_TEXT, 'Operation message')
        ]);
    }

    /**
     * Returns description of refresh_predictions parameters.
     *
     * @return \external_function_parameters
     */
    public static function refresh_predictions_parameters() {
        return new \external_function_parameters([
            'courseid' => new \external_value(PARAM_INT, 'Course ID')
        ]);
    }

    /**
     * Refresh predictions for a course.
     *
     * @param int $courseid Course ID
     * @return array Operation result
     */
    public static function refresh_predictions($courseid) {
        global $USER;

        // Validate parameters.
        $params = self::validate_parameters(self::refresh_predictions_parameters(), [
            'courseid' => $courseid
        ]);

        // Security checks.
        $context = \context_course::instance($params['courseid']);
        self::validate_context($context);

        // Check permission.
        require_capability('block/studentperformancepredictor:viewallpredictions', $context);

        // Trigger refresh.
        $success = block_studentperformancepredictor_trigger_prediction_refresh($params['courseid'], $USER->id);

        return [
            'status' => $success,
            'message' => $success ? get_string('predictionsrefreshqueued', 'block_studentperformancepredictor') 
                                 : get_string('predictionsrefresherror', 'block_studentperformancepredictor')
        ];
    }

    /**
     * Returns description of refresh_predictions returns.
     *
     * @return \external_single_structure
     */
    public static function refresh_predictions_returns() {
        return new \external_single_structure([
            'status' => new \external_value(PARAM_BOOL, 'Operation success status'),
            'message' => new \external_value(PARAM_TEXT, 'Operation message')
        ]);
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Admin view renderer for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

// Add this line to include lib.php which contains the function definitions
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Admin view class for the admin dashboard.
 *
 * This class prepares data for the admin dashboard template.
 */
class admin_view implements \renderable, \templatable {
    /** @var int Course ID */
    protected $courseid;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     */
    public function __construct($courseid) {
        $this->courseid = $courseid;
    }

    /**
     * Export data for template.
     *
     * @param \renderer_base $output The renderer
     * @return \stdClass Data for template
     */
    public function export_for_template(\renderer_base $output) {
        global $CFG;

        $data = new \stdClass();
        $data->heading = get_string('modelmanagement', 'block_studentperformancepredictor');
        $data->courseid = $this->courseid;

        // Create URLs
        $data->managemodelsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', 
                                             ['courseid' => $this->courseid]);
        $data->managedatasetsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', 
                                               ['courseid' => $this->courseid]);
        $data->refreshpredictionsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/refreshpredictions.php', 
                                                   ['courseid' => $this->courseid]);

        // Check if there's an active model - use global namespace function
        $data->hasmodel = \block_studentperformancepredictor_has_active_model($this->courseid);

        if (!$data->hasmodel) {
            $data->nomodeltext = get_string('noactivemodel', 'block_studentperformancepredictor');
            return $data;
        }

        // Get risk statistics - use global namespace function
        $riskStats = \block_studentperformancepredictor_get_course_risk_stats($this->courseid);

        $data->totalstudents = $riskStats->total;
        $data->highrisk = $riskStats->highrisk;
        $data->mediumrisk = $riskStats->mediumrisk;
        $data->lowrisk = $riskStats->lowrisk;

        // Calculate percentages
        if ($data->totalstudents > 0) {
            $data->highriskpercent = round(($data->highrisk / $data->totalstudents) * 100);
            $data->mediumriskpercent = round(($data->mediumrisk / $data->totalstudents) * 100);
            $data->lowriskpercent = round(($data->lowrisk / $data->totalstudents) * 100);
        } else {
            $data->highriskpercent = 0;
            $data->mediumriskpercent = 0;
            $data->lowriskpercent = 0;
        }

        // Create chart data
        $data->haschart = true;
        $chartData = [
            'labels' => [
                get_string('highrisk_label', 'block_studentperformancepredictor'),
                get_string('mediumrisk_label', 'block_studentperformancepredictor'),
                get_string('lowrisk_label', 'block_studentperformancepredictor')
            ],
            'data' => [$data->highrisk, $data->mediumrisk, $data->lowrisk]
        ];
        $data->chartdata = json_encode($chartData);

        return $data;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderer for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

use plugin_renderer_base;

/**
 * Renderer for Student Performance Predictor block.
 */
class renderer extends plugin_renderer_base {
    /**
     * Renders student_view.
     *
     * @param student_view $studentview The student view object
     * @return string HTML
     */
    public function render_student_view(student_view $studentview) {
        $data = $studentview->export_for_template($this);
        return $this->render_from_template('block_studentperformancepredictor/student_dashboard', $data);
    }

    /**
     * Renders teacher_view.
     *
     * @param teacher_view $teacherview The teacher view object
     * @return string HTML
     */
    public function render_teacher_view(teacher_view $teacherview) {
        $data = $teacherview->export_for_template($this);
        return $this->render_from_template('block_studentperformancepredictor/teacher_dashboard', $data);
    }

    /**
     * Renders admin_view.
     *
     * @param admin_view $adminview The admin view object
     * @return string HTML
     */
    public function render_admin_view(admin_view $adminview) {
        $data = $adminview->export_for_template($this);
        return $this->render_from_template('block_studentperformancepredictor/admin_settings', $data);
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Student view renderer for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

// Add this line to include lib.php which contains the function definitions
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Student view class for the student dashboard.
 *
 * This class prepares data for the student dashboard template.
 */
class student_view implements \renderable, \templatable {
    /** @var int Course ID */
    protected $courseid;

    /** @var int User ID */
    protected $userid;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     * @param int $userid User ID
     */
    public function __construct($courseid, $userid) {
        $this->courseid = $courseid;
        $this->userid = $userid;
    }

    /**
     * Export data for template.
     *
     * @param \renderer_base $output The renderer
     * @return \stdClass Data for template
     */
    public function export_for_template(\renderer_base $output) {
        global $DB, $CFG;

        $data = new \stdClass();
        $data->heading = get_string('studentperformance', 'block_studentperformancepredictor');
        $data->courseid = $this->courseid;

        // Check if there's an active model - use global namespace function
        $data->hasmodel = \block_studentperformancepredictor_has_active_model($this->courseid);

        if (!$data->hasmodel) {
            $data->nomodeltext = get_string('noactivemodel', 'block_studentperformancepredictor');
            return $data;
        }

        // Get student prediction - use global namespace function
        $prediction = \block_studentperformancepredictor_get_student_prediction($this->courseid, $this->userid);

        if (!$prediction) {
            $data->hasprediction = false;
            $data->nopredictiontext = get_string('noprediction', 'block_studentperformancepredictor');
            return $data;
        }

        $data->hasprediction = true;

        // Prediction information
        $data->passprob = round($prediction->passprob * 100);
        $data->riskvalue = $prediction->riskvalue;
        $data->risktext = \block_studentperformancepredictor_get_risk_text($prediction->riskvalue);
        $data->riskclass = \block_studentperformancepredictor_get_risk_class($prediction->riskvalue);
        $data->lastupdate = userdate($prediction->timemodified);

        // Get suggestions - use global namespace function
        $suggestions = \block_studentperformancepredictor_get_suggestions($prediction->id);

        $data->hassuggestions = !empty($suggestions);
        $data->suggestions = [];

        foreach ($suggestions as $suggestion) {
            $suggestionData = new \stdClass();
            $suggestionData->id = $suggestion->id;
            $suggestionData->reason = $suggestion->reason;

            // Create URL to the activity
            if (!empty($suggestion->cmid)) {
                $suggestionData->hasurl = true;
                $modulename = !empty($suggestion->modulename) ? $suggestion->modulename : '';
                $cmname = !empty($suggestion->cmname) ? $suggestion->cmname : '';
                $suggestionData->url = new \moodle_url('/mod/' . $modulename . '/view.php', 
                                                    ['id' => $suggestion->cmid]);
                $suggestionData->name = $cmname;
            } else {
                $suggestionData->hasurl = false;
                $suggestionData->name = get_string('generalstudy', 'block_studentperformancepredictor');
            }

            $suggestionData->viewed = $suggestion->viewed;
            $suggestionData->completed = $suggestion->completed;

            $data->suggestions[] = $suggestionData;
        }

        // Create chart data
        $data->haschart = true;
        $chartData = [
            'passprob' => $data->passprob,
            'failprob' => 100 - $data->passprob
        ];
        $data->chartdata = json_encode($chartData);

        return $data;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Teacher view renderer for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

// Add this line to include lib.php which contains the function definitions
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Teacher view class for the teacher dashboard.
 *
 * This class prepares data for the teacher dashboard template.
 */
class teacher_view implements \renderable, \templatable {
    /** @var int Course ID */
    protected $courseid;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     */
    public function __construct($courseid) {
        $this->courseid = $courseid;
    }

    /**
     * Export data for template.
     *
     * @param \renderer_base $output The renderer
     * @return \stdClass Data for template
     */
    public function export_for_template(\renderer_base $output) {
        global $CFG;

        $data = new \stdClass();
        $data->heading = get_string('courseperformance', 'block_studentperformancepredictor');
        $data->courseid = $this->courseid;

        // Check if there's an active model - use global namespace function
        $data->hasmodel = \block_studentperformancepredictor_has_active_model($this->courseid);

        if (!$data->hasmodel) {
            $data->nomodeltext = get_string('noactivemodel', 'block_studentperformancepredictor');
            return $data;
        }

        // Get risk statistics - use global namespace function
        $riskStats = \block_studentperformancepredictor_get_course_risk_stats($this->courseid);

        $data->totalstudents = $riskStats->total;
        $data->highrisk = $riskStats->highrisk;
        $data->mediumrisk = $riskStats->mediumrisk;
        $data->lowrisk = $riskStats->lowrisk;

        // Calculate percentages
        if ($data->totalstudents > 0) {
            $data->highriskpercent = round(($data->highrisk / $data->totalstudents) * 100);
            $data->mediumriskpercent = round(($data->mediumrisk / $data->totalstudents) * 100);
            $data->lowriskpercent = round(($data->lowrisk / $data->totalstudents) * 100);
        } else {
            $data->highriskpercent = 0;
            $data->mediumriskpercent = 0;
            $data->lowriskpercent = 0;
        }

        // Create URL to detailed report
        $data->detailreporturl = new \moodle_url('/blocks/studentperformancepredictor/reports.php', 
                                              ['id' => $this->courseid]);

        // Create chart data
        $data->haschart = true;
        $chartData = [
            'labels' => [
                get_string('highrisk_label', 'block_studentperformancepredictor'),
                get_string('mediumrisk_label', 'block_studentperformancepredictor'),
                get_string('lowrisk_label', 'block_studentperformancepredictor')
            ],
            'data' => [$data->highrisk, $data->mediumrisk, $data->lowrisk]
        ];
        $data->chartdata = json_encode($chartData);

        return $data;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy API implementation for Student Performance Predictor.
 *
 * Implements metadata, context/user listing, export, and deletion for GDPR compliance.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\privacy;

defined('MOODLE_INTERNAL') || die();

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\deletion_criteria;
use core_privacy\local\request\helper;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;
use core_privacy\local\request\transform;
use context_course;
use context;
use const CONTEXT_COURSE;
use const SQL_PARAMS_NAMED;

/**
 * Privacy API implementation for the Student Performance Predictor plugin.
 *
 * All user data (predictions, suggestions) is orchestrated by PHP but generated by the Python backend.
 * This provider ensures GDPR compliance for all backend-driven data.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider {

    /**
     * Returns metadata about this plugin's privacy usage.
     *
     * All fields are orchestrated by PHP but generated by the Python backend.
     *
     * @param collection $collection The metadata collection to populate.
     * @return collection The updated metadata collection.
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table(
            'block_spp_predictions',
            [
                'modelid' => 'privacy:metadata:block_spp_predictions:modelid',
                'courseid' => 'privacy:metadata:block_spp_predictions:courseid',
                'userid' => 'privacy:metadata:block_spp_predictions:userid',
                'passprob' => 'privacy:metadata:block_spp_predictions:passprob',
                'riskvalue' => 'privacy:metadata:block_spp_predictions:riskvalue',
                'predictiondata' => 'privacy:metadata:block_spp_predictions:predictiondata',
                'timecreated' => 'privacy:metadata:block_spp_predictions:timecreated',
                'timemodified' => 'privacy:metadata:block_spp_predictions:timemodified',
            ],
            'privacy:metadata:block_spp_predictions'
        );

        $collection->add_database_table(
            'block_spp_suggestions',
            [
                'predictionid' => 'privacy:metadata:block_spp_suggestions:predictionid',
                'courseid' => 'privacy:metadata:block_spp_suggestions:courseid',
                'userid' => 'privacy:metadata:block_spp_suggestions:userid',
                'cmid' => 'privacy:metadata:block_spp_suggestions:cmid',
                'resourcetype' => 'privacy:metadata:block_spp_suggestions:resourcetype',
                'resourceid' => 'privacy:metadata:block_spp_suggestions:resourceid',
                'priority' => 'privacy:metadata:block_spp_suggestions:priority',
                'reason' => 'privacy:metadata:block_spp_suggestions:reason',
                'timecreated' => 'privacy:metadata:block_spp_suggestions:timecreated',
                'viewed' => 'privacy:metadata:block_spp_suggestions:viewed',
                'completed' => 'privacy:metadata:block_spp_suggestions:completed',
            ],
            'privacy:metadata:block_spp_suggestions'
        );

        return $collection;
    }

    /**
     * Get the list of contexts that contain user information for the specified user.
     *
     * @param int $userid The user to search.
     * @return contextlist The contextlist containing the list of contexts used in this plugin.
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();

        // Add course contexts where the user has predictions or suggestions (all backend-driven).
        $sql = "
            SELECT DISTINCT ctx.id
            FROM {context} ctx
            JOIN {course} c ON c.id = ctx.instanceid AND ctx.contextlevel = :contextlevel
            JOIN {block_spp_predictions} p ON p.courseid = c.id
            WHERE p.userid = :userid
        ";
        $params = [
            'contextlevel' => CONTEXT_COURSE,
            'userid' => $userid
        ];
        $contextlist->add_from_sql($sql, $params);

        $sql = "
            SELECT DISTINCT ctx.id
            FROM {context} ctx
            JOIN {course} c ON c.id = ctx.instanceid AND ctx.contextlevel = :contextlevel
            JOIN {block_spp_suggestions} s ON s.courseid = c.id
            WHERE s.userid = :userid
        ";
        $contextlist->add_from_sql($sql, $params);

        return $contextlist;
    }

    /**
     * Get the list of users who have data within a context.
     *
     * @param userlist $userlist The userlist containing the list of users who have data in this context/plugin combination.
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();
        if (!$context instanceof \context_course) {
            return;
        }
        $params = [
            'courseid' => $context->instanceid,
        ];
        // Add users who have predictions or suggestions in this course (all backend-driven).
        $sql = "SELECT userid FROM {block_spp_predictions} WHERE courseid = :courseid";
        $userlist->add_from_sql('userid', $sql, $params);
        $sql = "SELECT userid FROM {block_spp_suggestions} WHERE courseid = :courseid";
        $userlist->add_from_sql('userid', $sql, $params);
    }

    /**
     * Export all user data for the specified user, in the specified contexts.
     *
     * @param approved_contextlist $contextlist The approved contexts to export information for.
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;
        if (empty($contextlist->count())) {
            return;
        }
        $user = $contextlist->get_user();
        foreach ($contextlist->get_contexts() as $context) {
            if (!$context instanceof \context_course) {
                continue;
            }
            $courseid = $context->instanceid;
            // Export predictions (all backend-driven).
            $predictions = $DB->get_records('block_spp_predictions', ['courseid' => $courseid, 'userid' => $user->id]);
            foreach ($predictions as $prediction) {
                $predictiondata = [
                    'passprob' => $prediction->passprob,
                    'riskvalue' => $prediction->riskvalue,
                    'predictiondata' => $prediction->predictiondata,
                    'timecreated' => transform::datetime($prediction->timecreated),
                    'timemodified' => transform::datetime($prediction->timemodified),
                ];
                writer::with_context($context)->export_data(
                    [\get_string('privacy:predictionpath', 'block_studentperformancepredictor', $prediction->id)],
                    (object) $predictiondata
                );
                // Export associated suggestions (all backend-driven).
                $suggestions = $DB->get_records('block_spp_suggestions', ['predictionid' => $prediction->id, 'userid' => $user->id]);
                foreach ($suggestions as $suggestion) {
                    $suggestiondata = [
                        'resourcetype' => $suggestion->resourcetype,
                        'priority' => $suggestion->priority,
                        'reason' => $suggestion->reason,
                        'timecreated' => transform::datetime($suggestion->timecreated),
                        'viewed' => $suggestion->viewed,
                        'completed' => $suggestion->completed,
                    ];
                    writer::with_context($context)->export_data(
                        [
                            \get_string('privacy:predictionpath', 'block_studentperformancepredictor', $prediction->id),
                            \get_string('privacy:suggestionpath', 'block_studentperformancepredictor', $suggestion->id)
                        ],
                        (object) $suggestiondata
                    );
                }
            }
        }
    }

    /**
     * Delete all data for all users in the specified context.
     *
     * @param \context $context The specific context to delete data for.
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;
        if (!$context instanceof \context_course) {
            return;
        }
        $courseid = $context->instanceid;
        // Delete all suggestions for the course (all backend-driven).
        $DB->delete_records('block_spp_suggestions', ['courseid' => $courseid]);
        // Get all predictions for the course.
        $predictions = $DB->get_records('block_spp_predictions', ['courseid' => $courseid], '', 'id');
        if (!empty($predictions)) {
            // Delete all suggestions associated with these predictions (should already be covered by the above, but just in case).
            list($insql, $inparams) = $DB->get_in_or_equal(array_keys($predictions), SQL_PARAMS_NAMED);
            $DB->delete_records_select('block_spp_suggestions', "predictionid $insql", $inparams);
            // Now delete the predictions.
            $DB->delete_records('block_spp_predictions', ['courseid' => $courseid]);
        }
    }

    /**
     * Delete all user data for the specified user, in the specified contexts.
     *
     * @param approved_contextlist $contextlist The approved contexts and user information to delete information for.
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;
        if (empty($contextlist->count())) {
            return;
        }
        $user = $contextlist->get_user();
        foreach ($contextlist->get_contexts() as $context) {
            if (!$context instanceof \context_course) {
                continue;
            }
            $courseid = $context->instanceid;
            // Delete suggestions for the user in this course (all backend-driven).
            $DB->delete_records('block_spp_suggestions', ['courseid' => $courseid, 'userid' => $user->id]);
            // Get predictions for the user in this course.
            $predictions = $DB->get_records('block_spp_predictions', ['courseid' => $courseid, 'userid' => $user->id], '', 'id');
            if (!empty($predictions)) {
                // Delete suggestions associated with these predictions (should already be covered by the above, but just in case).
                list($insql, $inparams) = $DB->get_in_or_equal(array_keys($predictions), SQL_PARAMS_NAMED);
                $DB->delete_records_select('block_spp_suggestions', "predictionid $insql", $inparams);
                // Now delete the predictions.
                $DB->delete_records('block_spp_predictions', ['courseid' => $courseid, 'userid' => $user->id]);
            }
        }
    }

    /**
     * Delete multiple users within a single context.
     *
     * @param approved_userlist $userlist The approved context and user information to delete information for.
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        global $DB;
        $context = $userlist->get_context();
        if (!$context instanceof \context_course) {
            return;
        }
        $courseid = $context->instanceid;
        $userids = $userlist->get_userids();
        if (empty($userids)) {
            return;
        }
        // Delete suggestions for these users in this course (all backend-driven).
        list($insql, $inparams) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
        $inparams['courseid'] = $courseid;
        $DB->delete_records_select(
            'block_spp_suggestions',
            "courseid = :courseid AND userid $insql",
            $inparams
        );
        // Get predictions for these users in this course.
        $predictions = $DB->get_records_select(
            'block_spp_predictions',
            "courseid = :courseid AND userid $insql",
            $inparams,
            '',
            'id'
        );
        if (!empty($predictions)) {
            // Delete suggestions associated with these predictions (should already be covered by the above, but just in case).
            list($predinsql, $predinparams) = $DB->get_in_or_equal(array_keys($predictions), SQL_PARAMS_NAMED);
            $DB->delete_records_select('block_spp_suggestions', "predictionid $predinsql", $predinparams);
            // Now delete the predictions.
            $DB->delete_records_select(
                'block_spp_predictions',
                "courseid = :courseid AND userid $insql",
                $inparams
            );
        }
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Ad-hoc task for training models on demand.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\task;

defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Ad-hoc task to train a new model on demand.
 */
class adhoc_train_model extends \core\task\adhoc_task {
    /**
     * Execute the ad-hoc task.
     */
    public function execute() {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

        \mtrace('Starting ad-hoc model training task execution...');

        // Get the task data
        $data = $this->get_custom_data();
        if (!isset($data->courseid) || !isset($data->datasetid)) {
            \mtrace('Error: Missing required parameters for ad-hoc model training task.');
            return;
        }

        $courseid = $data->courseid;
        $datasetid = $data->datasetid;
        $algorithm = isset($data->algorithm) ? $data->algorithm : null;
        $userid = isset($data->userid) ? $data->userid : null;

        \mtrace("Training model for course {$courseid} using dataset {$datasetid}");

        try {
            // Call the backend to train the model
            $modelid = block_studentperformancepredictor_train_model_via_backend($courseid, $datasetid, $algorithm);

            if ($modelid) {
                \mtrace("Model training completed successfully. Model ID: {$modelid}");

                // Trigger model trained event
                $context = \context_course::instance($courseid);
                $event = \block_studentperformancepredictor\event\model_trained::create(array(
                    'context' => $context,
                    'objectid' => $modelid,
                    'other' => array(
                        'courseid' => $courseid,
                        'datasetid' => $datasetid
                    )
                ));
                $event->trigger();

                // Generate initial predictions for all students in the course
                \mtrace("Generating initial predictions for students in course {$courseid}");
                $result = block_studentperformancepredictor_refresh_predictions_via_backend($courseid);
                \mtrace("Generated predictions: {$result['success']} successful, {$result['errors']} errors");

                // If user ID specified, send a notification
                if ($userid) {
                    $this->send_success_notification($userid, $courseid, $modelid);
                }
            } else {
                \mtrace("Error: Model training failed.");

                // If user ID specified, send error notification
                if ($userid) {
                    $this->send_error_notification($userid, $courseid, "Failed to create a valid model");
                }
            }
        } catch (\Exception $e) {
            \mtrace("Error during model training: " . $e->getMessage());

            // If user ID specified, send error notification
            if ($userid) {
                $this->send_error_notification($userid, $courseid, $e->getMessage());
            }
        }
    }

    /**
     * Send a notification about successful model training.
     *
     * @param int $userid User to notify
     * @param int $courseid Course ID
     * @param int $modelid Newly created model ID
     */
    protected function send_success_notification($userid, $courseid, $modelid) {
        global $DB;

        $user = $DB->get_record('user', ['id' => $userid]);
        if (!$user) {
            return;
        }

        $course = $DB->get_record('course', ['id' => $courseid]);
        if (!$course) {
            return;
        }

        $model = $DB->get_record('block_spp_models', ['id' => $modelid]);
        if (!$model) {
            return;
        }

        $subject = get_string('model_training_success_subject', 'block_studentperformancepredictor');

        $messagedata = new \stdClass();
        $messagedata->modelname = format_string($model->modelname);
        $messagedata->coursename = format_string($course->fullname);

        $message = get_string('model_training_success_message', 'block_studentperformancepredictor', $messagedata);

        $eventdata = new \core\message\message();
        $eventdata->courseid = $courseid;
        $eventdata->component = 'block_studentperformancepredictor';
        $eventdata->name = 'model_training_success';
        $eventdata->userfrom = \core_user::get_noreply_user();
        $eventdata->userto = $user;
        $eventdata->subject = $subject;
        $eventdata->fullmessage = $message;
        $eventdata->fullmessageformat = FORMAT_HTML;
        $eventdata->fullmessagehtml = $message;
        $eventdata->smallmessage = $subject;
        $eventdata->notification = 1;

        message_send($eventdata);
    }

    /**
     * Send a notification about failed model training.
     *
     * @param int $userid User to notify
     * @param int $courseid Course ID
     * @param string $error Error message
     */
    protected function send_error_notification($userid, $courseid, $error) {
        global $DB;

        $user = $DB->get_record('user', ['id' => $userid]);
        if (!$user) {
            return;
        }

        $course = $DB->get_record('course', ['id' => $courseid]);
        if (!$course) {
            return;
        }

        $subject = get_string('model_training_error_subject', 'block_studentperformancepredictor');

        $messagedata = new \stdClass();
        $messagedata->coursename = format_string($course->fullname);
        $messagedata->error = $error;

        $message = get_string('model_training_error_message', 'block_studentperformancepredictor', $messagedata);

        $eventdata = new \core\message\message();
        $eventdata->courseid = $courseid;
        $eventdata->component = 'block_studentperformancepredictor';
        $eventdata->name = 'model_training_error';
        $eventdata->userfrom = \core_user::get_noreply_user();
        $eventdata->userto = $user;
        $eventdata->subject = $subject;
        $eventdata->fullmessage = $message;
        $eventdata->fullmessageformat = FORMAT_HTML;
        $eventdata->fullmessagehtml = $message;
        $eventdata->smallmessage = $subject;
        $eventdata->notification = 1;

        message_send($eventdata);
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Task for refreshing predictions.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Task to refresh predictions.
 */
class refresh_predictions extends \core\task\adhoc_task {
    /**
     * Execute the task.
     */
    public function execute() {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

        mtrace("Starting prediction refresh task");

        // Get the task data
        $data = $this->get_custom_data();
        if (!isset($data->courseid)) {
            mtrace("Missing courseid parameter for prediction refresh task");
            return;
        }

        $courseid = $data->courseid;
        mtrace("Refreshing predictions for course ID: $courseid");

        try {
            $context = \context_course::instance($courseid);
            $students = get_enrolled_users($context, 'moodle/course:isincompletionreports');

            $success = 0;
            $errors = 0;

            foreach ($students as $student) {
                mtrace("Generating prediction for student ID: {$student->id}");

                try {
                    $predictionid = block_studentperformancepredictor_generate_prediction($courseid, $student->id);

                    if ($predictionid) {
                        $success++;
                        mtrace("Prediction generated successfully for student ID: {$student->id}");
                    } else {
                        $errors++;
                        mtrace("Error generating prediction for student ID: {$student->id}");
                    }
                } catch (\Exception $e) {
                    $errors++;
                    mtrace("Exception generating prediction for student ID: {$student->id} - " . $e->getMessage());
                }
            }

            // Update the last refresh time
            set_config('lastrefresh_' . $courseid, time(), 'block_studentperformancepredictor');

            mtrace("Prediction refresh completed: $success successful, $errors errors");

            // Notify user who requested refresh if specified
            if (isset($data->userid)) {
                $this->send_completion_notification($data->userid, $courseid, count($students), $success, $errors);
            }
        } catch (\Exception $e) {
            mtrace("Error in prediction refresh task: " . $e->getMessage());
            mtrace($e->getTraceAsString());
        }
    }

    /**
     * Send a notification about the completion of the task.
     *
     * @param int $userid User to notify
     * @param int $courseid Course ID
     * @param int $total Total number of students
     * @param int $success Number of successful predictions
     * @param int $errors Number of errors
     */
    protected function send_completion_notification($userid, $courseid, $total, $success, $errors) {
        global $DB;

        $user = $DB->get_record('user', ['id' => $userid]);
        if (!$user) {
            return;
        }

        $course = $DB->get_record('course', ['id' => $courseid]);
        if (!$course) {
            return;
        }

        $subject = get_string('prediction_refresh_complete_subject', 'block_studentperformancepredictor');

        $messagedata = new \stdClass();
        $messagedata->coursename = format_string($course->fullname);
        $messagedata->total = $total;
        $messagedata->success = $success;
        $messagedata->errors = $errors;

        $message = get_string('prediction_refresh_complete_message', 'block_studentperformancepredictor', $messagedata);

        $eventdata = new \core\message\message();
        $eventdata->courseid = $courseid;
        $eventdata->component = 'block_studentperformancepredictor';
        $eventdata->name = 'prediction_refresh_complete';
        $eventdata->userfrom = \core_user::get_noreply_user();
        $eventdata->userto = $user;
        $eventdata->subject = $subject;
        $eventdata->fullmessage = $message;
        $eventdata->fullmessageformat = FORMAT_HTML;
        $eventdata->fullmessagehtml = $message;
        $eventdata->smallmessage = get_string('prediction_refresh_complete_small', 'block_studentperformancepredictor');
        $eventdata->notification = 1;

        message_send($eventdata);
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
* Scheduled task for refreshing predictions periodically.
*
* @package    block_studentperformancepredictor
* @copyright  2023 Your Name <[Email]>
* @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/

namespace block_studentperformancepredictor\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Task to periodically refresh predictions.
 */
class scheduled_predictions extends \core\task\scheduled_task {
    /**
     * Get a descriptive name for this task.
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_scheduled_predictions', 'block_studentperformancepredictor');
    }

    /**
     * Execute the task.
     */
    public function execute() {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

        mtrace("Starting scheduled prediction refresh task");

        // Find courses with active models
        $courses = $DB->get_records_sql(
            "SELECT DISTINCT c.id, c.fullname 
            FROM {course} c 
            JOIN {block_spp_models} m ON m.courseid = c.id 
            WHERE m.active = 1"
        );

        if (empty($courses)) {
            mtrace("No courses with active models found");
            return;
        }

        mtrace("Found " . count($courses) . " courses with active models");

        foreach ($courses as $course) {
            mtrace("Processing course: " . $course->fullname . " (ID: " . $course->id . ")");

            try {
                $context = \context_course::instance($course->id);
                $students = get_enrolled_users($context, 'moodle/course:isincompletionreports');

                $success = 0;
                $errors = 0;

                foreach ($students as $student) {
                    try {
                        $predictionid = block_studentperformancepredictor_generate_prediction($course->id, $student->id);

                        if ($predictionid) {
                            $success++;
                        } else {
                            $errors++;
                        }
                    } catch (\Exception $e) {
                        $errors++;
                        mtrace("Error generating prediction for student ID " . $student->id . ": " . $e->getMessage());
                    }
                }

                // Update the last refresh time for this course
                set_config('lastrefresh_' . $course->id, time(), 'block_studentperformancepredictor');

                mtrace("Completed predictions for course ID " . $course->id . ": " . $success . " successful, " . $errors . " errors");
            } catch (\Exception $e) {
                mtrace("Error processing course ID " . $course->id . ": " . $e->getMessage());
            }
        }

        mtrace("Scheduled prediction refresh completed");
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Capability definitions for the Student Performance Predictor block.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$capabilities = [
    // Allow users to add the block to their dashboard.
    'block/studentperformancepredictor:myaddinstance' => [
        'captype' => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => [
            'user' => CAP_ALLOW
        ],
        'clonepermissionsfrom' => 'moodle/my:manageblocks'
    ],

    // Allow users to add the block to a course.
    'block/studentperformancepredictor:addinstance' => [
        'riskbitmask' => RISK_SPAM | RISK_XSS,
        'captype' => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => [
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        ],
        'clonepermissionsfrom' => 'moodle/site:manageblocks'
    ],

    // Allow users to view their own predictions and dashboard.
    'block/studentperformancepredictor:view' => [
        'captype' => 'read',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => [
            'student' => CAP_ALLOW,
            'teacher' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        ]
    ],

    // Allow teachers/managers to view all predictions in a course.
    'block/studentperformancepredictor:viewallpredictions' => [
        'riskbitmask' => RISK_PERSONAL,
        'captype' => 'read',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => [
            'teacher' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        ]
    ],

    // Allow teachers/managers to manage models (activate/deactivate, retrain, etc.).
    'block/studentperformancepredictor:managemodels' => [
        'riskbitmask' => RISK_CONFIG | RISK_DATALOSS,
        'captype' => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => [
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        ]
    ],

    // Allow users to view the dashboard (admin/teacher/student views as appropriate).
    'block/studentperformancepredictor:viewdashboard' => [
        'captype' => 'read',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => [
            'student' => CAP_ALLOW,
            'teacher' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'manager' => CAP_ALLOW
        ]
    ],
];

<?xml version="1.0" encoding="UTF-8" ?>
<XMLDB PATH="blocks/studentperformancepredictor/db" VERSION="20231128" COMMENT="XMLDB file for Moodle blocks/studentperformancepredictor">
    <TABLES>
        <TABLE NAME="block_spp_models" COMMENT="Stores metadata for trained prediction models">
            <FIELDS>
                <FIELD NAME="id" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="true"/>
                <FIELD NAME="courseid" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false" COMMENT="Course ID the model is for"/>
                <FIELD NAME="datasetid" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false" COMMENT="Dataset ID used to train the model"/>
                <FIELD NAME="modelname" TYPE="char" LENGTH="255" NOTNULL="true" SEQUENCE="false" COMMENT="Name of the model"/>
                <FIELD NAME="modeldata" TYPE="text" NOTNULL="false" SEQUENCE="false" COMMENT="Serialized model data (optional, as backend may store models elsewhere)"/>
                <FIELD NAME="modelid" TYPE="char" LENGTH="255" NOTNULL="false" SEQUENCE="false" COMMENT="External model ID for the backend"/>
                <FIELD NAME="modelpath" TYPE="char" LENGTH="255" NOTNULL="false" SEQUENCE="false" COMMENT="Path to the model file (optional)"/>
                <FIELD NAME="featureslist" TYPE="text" NOTNULL="false" SEQUENCE="false" COMMENT="List of features used in the model"/>
                <FIELD NAME="algorithmtype" TYPE="char" LENGTH="50" NOTNULL="true" DEFAULT="randomforest" SEQUENCE="false" COMMENT="Type of algorithm used"/>
                <FIELD NAME="accuracy" TYPE="number" LENGTH="10" NOTNULL="false" DECIMALS="5" DEFAULT="0" SEQUENCE="false" COMMENT="Model accuracy on validation data"/>
                <FIELD NAME="metrics" TYPE="text" NOTNULL="false" SEQUENCE="false" COMMENT="Additional metrics in JSON format"/>
                <FIELD NAME="active" TYPE="int" LENGTH="1" NOTNULL="true" DEFAULT="0" SEQUENCE="false" COMMENT="Whether this model is currently active"/>
                <FIELD NAME="trainstatus" TYPE="char" LENGTH="20" NOTNULL="true" DEFAULT="pending" SEQUENCE="false" COMMENT="Status of model training (pending, training, complete, failed)"/>
                <FIELD NAME="errormessage" TYPE="text" NOTNULL="false" SEQUENCE="false" COMMENT="Error message if model training failed"/>
                <FIELD NAME="timecreated" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="timemodified" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="usermodified" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
            </FIELDS>
            <KEYS>
                <KEY NAME="primary" TYPE="primary" FIELDS="id"/>
                <KEY NAME="courseid" TYPE="foreign" FIELDS="courseid" REFTABLE="course" REFFIELDS="id"/>
                <KEY NAME="usermodified" TYPE="foreign" FIELDS="usermodified" REFTABLE="user" REFFIELDS="id"/>
            </KEYS>
            <INDEXES>
                <INDEX NAME="courseid_active" UNIQUE="false" FIELDS="courseid, active"/>
                <INDEX NAME="trainstatus" UNIQUE="false" FIELDS="trainstatus"/>
            </INDEXES>
        </TABLE>

        <TABLE NAME="block_spp_predictions" COMMENT="Stores predictions for individual students">
            <FIELDS>
                <FIELD NAME="id" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="true"/>
                <FIELD NAME="modelid" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="false" COMMENT="Model used for prediction"/>
                <FIELD NAME="courseid" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="userid" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="passprob" TYPE="number" LENGTH="10" NOTNULL="true" DECIMALS="5" DEFAULT="0" SEQUENCE="false" COMMENT="Probability of passing"/>
                <FIELD NAME="riskvalue" TYPE="int" LENGTH="1" NOTNULL="true" DEFAULT="0" SEQUENCE="false" COMMENT="Risk level (1=low, 2=medium, 3=high)"/>
                <FIELD NAME="predictiondata" TYPE="text" NOTNULL="false" SEQUENCE="false" COMMENT="Additional prediction details in JSON format"/>
                <FIELD NAME="timecreated" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="timemodified" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
            </FIELDS>
            <KEYS>
                <KEY NAME="primary" TYPE="primary" FIELDS="id"/>
                <KEY NAME="modelid" TYPE="foreign" FIELDS="modelid" REFTABLE="block_spp_models" REFFIELDS="id"/>
                <KEY NAME="courseid" TYPE="foreign" FIELDS="courseid" REFTABLE="course" REFFIELDS="id"/>
                <KEY NAME="userid" TYPE="foreign" FIELDS="userid" REFTABLE="user" REFFIELDS="id"/>
            </KEYS>
            <INDEXES>
                <INDEX NAME="courseid_userid" UNIQUE="false" FIELDS="courseid, userid"/>
                <INDEX NAME="userid" UNIQUE="false" FIELDS="userid"/>
                <INDEX NAME="riskvalue" UNIQUE="false" FIELDS="riskvalue"/>
                <INDEX NAME="timemodified" UNIQUE="false" FIELDS="timemodified"/>
            </INDEXES>
        </TABLE>

        <TABLE NAME="block_spp_suggestions" COMMENT="Stores suggested activities for students">
            <FIELDS>
                <FIELD NAME="id" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="true"/>
                <FIELD NAME="predictionid" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="false"/>
                <FIELD NAME="courseid" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="userid" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="cmid" TYPE="int" LENGTH="10" NOTNULL="false" SEQUENCE="false" COMMENT="Course module ID being suggested"/>
                <FIELD NAME="resourcetype" TYPE="char" LENGTH="50" NOTNULL="true" SEQUENCE="false" COMMENT="Type of resource being suggested"/>
                <FIELD NAME="resourceid" TYPE="int" LENGTH="10" NOTNULL="false" SEQUENCE="false" COMMENT="Resource ID being suggested"/>
                <FIELD NAME="priority" TYPE="int" LENGTH="3" NOTNULL="true" DEFAULT="5" SEQUENCE="false" COMMENT="Priority of suggestion (1-10)"/>
                <FIELD NAME="reason" TYPE="text" NOTNULL="true" SEQUENCE="false" COMMENT="Reason for the suggestion"/>
                <FIELD NAME="timecreated" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="viewed" TYPE="int" LENGTH="1" NOTNULL="true" DEFAULT="0" SEQUENCE="false" COMMENT="Whether the suggestion has been viewed"/>
                <FIELD NAME="completed" TYPE="int" LENGTH="1" NOTNULL="true" DEFAULT="0" SEQUENCE="false" COMMENT="Whether the suggestion has been completed"/>
            </FIELDS>
            <KEYS>
                <KEY NAME="primary" TYPE="primary" FIELDS="id"/>
                <KEY NAME="predictionid" TYPE="foreign" FIELDS="predictionid" REFTABLE="block_spp_predictions" REFFIELDS="id"/>
                <KEY NAME="courseid" TYPE="foreign" FIELDS="courseid" REFTABLE="course" REFFIELDS="id"/>
                <KEY NAME="userid" TYPE="foreign" FIELDS="userid" REFTABLE="user" REFFIELDS="id"/>
            </KEYS>
            <INDEXES>
                <INDEX NAME="userid_priority" UNIQUE="false" FIELDS="userid, priority"/>
                <INDEX NAME="userid_viewed" UNIQUE="false" FIELDS="userid, viewed"/>
                <INDEX NAME="userid_completed" UNIQUE="false" FIELDS="userid, completed"/>
            </INDEXES>
        </TABLE>

        <TABLE NAME="block_spp_datasets" COMMENT="Stores training datasets">
            <FIELDS>
                <FIELD NAME="id" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="true"/>
                <FIELD NAME="courseid" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="name" TYPE="char" LENGTH="255" NOTNULL="true" SEQUENCE="false"/>
                <FIELD NAME="description" TYPE="text" NOTNULL="false" SEQUENCE="false"/>
                <FIELD NAME="filepath" TYPE="char" LENGTH="255" NOTNULL="true" SEQUENCE="false" COMMENT="Path to the dataset file"/>
                <FIELD NAME="fileformat" TYPE="char" LENGTH="20" NOTNULL="true" SEQUENCE="false" COMMENT="Format of the dataset file (CSV, JSON, etc.)"/>
                <FIELD NAME="columns" TYPE="text" NOTNULL="false" SEQUENCE="false" COMMENT="Description of dataset columns in JSON format"/>
                <FIELD NAME="timecreated" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="timemodified" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
                <FIELD NAME="usermodified" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
            </FIELDS>
            <KEYS>
                <KEY NAME="primary" TYPE="primary" FIELDS="id"/>
                <KEY NAME="courseid" TYPE="foreign" FIELDS="courseid" REFTABLE="course" REFFIELDS="id"/>
                <KEY NAME="usermodified" TYPE="foreign" FIELDS="usermodified" REFTABLE="user" REFFIELDS="id"/>
            </KEYS>
            <INDEXES>
                <INDEX NAME="fileformat" UNIQUE="false" FIELDS="fileformat"/>
            </INDEXES>
        </TABLE>

        <TABLE NAME="block_spp_training_log" COMMENT="Stores logs of model training events">
            <FIELDS>
                <FIELD NAME="id" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="true"/>
                <FIELD NAME="modelid" TYPE="int" LENGTH="10" NOTNULL="true" SEQUENCE="false"/>
                <FIELD NAME="event" TYPE="char" LENGTH="50" NOTNULL="true" SEQUENCE="false"/>
                <FIELD NAME="message" TYPE="text" NOTNULL="true" SEQUENCE="false"/>
                <FIELD NAME="level" TYPE="char" LENGTH="10" NOTNULL="true" DEFAULT="info" SEQUENCE="false"/>
                <FIELD NAME="timecreated" TYPE="int" LENGTH="10" NOTNULL="true" DEFAULT="0" SEQUENCE="false"/>
            </FIELDS>
            <KEYS>
                <KEY NAME="primary" TYPE="primary" FIELDS="id"/>
                <KEY NAME="modelid" TYPE="foreign" FIELDS="modelid" REFTABLE="block_spp_models" REFFIELDS="id"/>
            </KEYS>
            <INDEXES>
                <INDEX NAME="event_idx" UNIQUE="false" FIELDS="event"/>
                <INDEX NAME="level_idx" UNIQUE="false" FIELDS="level"/>
            </INDEXES>
        </TABLE>
    </TABLES>
</XMLDB>

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External services definition for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    // Mark a suggestion as viewed by the student.
    'block_studentperformancepredictor_mark_suggestion_viewed' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'mark_suggestion_viewed',
        'description' => 'Mark a suggestion as viewed by the student.',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:view',
    ],
    // Mark a suggestion as completed by the student.
    'block_studentperformancepredictor_mark_suggestion_completed' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'mark_suggestion_completed',
        'description' => 'Mark a suggestion as completed by the student.',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:view',
    ],
    // Get predictions for a student in a course.
    'block_studentperformancepredictor_get_student_predictions' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'get_student_predictions',
        'description' => 'Get predictions for a student in a course.',
        'type' => 'read',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:view',
    ],
    // Trigger model training for a course.
    'block_studentperformancepredictor_trigger_model_training' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'trigger_model_training',
        'description' => 'Trigger model training for a course.',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:managemodels',
    ],
    // Refresh predictions for a course.
    'block_studentperformancepredictor_refresh_predictions' => [
        'classname' => 'block_studentperformancepredictor\external\api',
        'methodname' => 'refresh_predictions',
        'description' => 'Refresh predictions for a course.',
        'type' => 'write',
        'ajax' => true,
        'capabilities' => 'block/studentperformancepredictor:viewallpredictions',
    ],
];

$services = [
    'Student Performance Predictor' => [
        'functions' => [
            'block_studentperformancepredictor_mark_suggestion_viewed',
            'block_studentperformancepredictor_mark_suggestion_completed',
            'block_studentperformancepredictor_get_student_predictions',
            'block_studentperformancepredictor_trigger_model_training',
            'block_studentperformancepredictor_refresh_predictions',
        ],
        'restrictedusers' => 0,
        'enabled' => 1,
        'shortname' => 'studentperformancepredictor',
        'downloadfiles' => 0,
    ],
];

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Task definitions for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => 'block_studentperformancepredictor\task\scheduled_predictions',
        'blocking' => 0,
        'minute' => '0',
        'hour' => '*/6', // Run every 6 hours
        'day' => '*',
        'month' => '*',
        'dayofweek' => '*',
        'disabled' => 0,
    ],
];

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
* Upgrade script for Student Performance Predictor.
*
* @package    block_studentperformancepredictor
* @copyright  2023 Your Name <[Email]>
* @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/

defined('MOODLE_INTERNAL') || die();

/**
* Upgrade function for the Student Performance Predictor block.
*
* @param int $oldversion The old version of the plugin
* @return bool
*/
function xmldb_block_studentperformancepredictor_upgrade($oldversion) {
    global $DB, $CFG;

    $dbman = $DB->get_manager();

    if ($oldversion < 2023112800) {
        // Create base directory for storing datasets
        $basedir = $CFG->dataroot . DIRECTORY_SEPARATOR . 'blocks_studentperformancepredictor';
        if (!file_exists($basedir)) {
            if (!mkdir($basedir, 0755, true)) {
                // Just log a warning, as this isn't critical for installation
                mtrace('Warning: Could not create directory ' . $basedir);
            }
        }

        // Define table block_spp_models if it doesn't exist
        if (!$dbman->table_exists('block_spp_models')) {
            $table = new xmldb_table('block_spp_models');

            // Add fields
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('datasetid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('modelname', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
            $table->add_field('modeldata', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('modelid', XMLDB_TYPE_CHAR, '255', null, null, null, null);
            $table->add_field('modelpath', XMLDB_TYPE_CHAR, '255', null, null, null, null);
            $table->add_field('featureslist', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('algorithmtype', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, 'randomforest');
            $table->add_field('accuracy', XMLDB_TYPE_NUMBER, '10, 5', null, null, null, '0');
            $table->add_field('metrics', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('active', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('trainstatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending');
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            // Add keys
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('courseid', XMLDB_KEY_FOREIGN, ['courseid'], 'course', ['id']);
            $table->add_key('usermodified', XMLDB_KEY_FOREIGN, ['usermodified'], 'user', ['id']);

            // Add indexes
            $table->add_index('courseid_active', XMLDB_INDEX_NOTUNIQUE, ['courseid', 'active']);
            $table->add_index('trainstatus', XMLDB_INDEX_NOTUNIQUE, ['trainstatus']);

            // Create the table
            $dbman->create_table($table);
        }

        // Define table block_spp_predictions if it doesn't exist
        if (!$dbman->table_exists('block_spp_predictions')) {
            $table = new xmldb_table('block_spp_predictions');

            // Add fields
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('modelid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('passprob', XMLDB_TYPE_NUMBER, '10, 5', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('riskvalue', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('predictiondata', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            // Add keys
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('modelid', XMLDB_KEY_FOREIGN, ['modelid'], 'block_spp_models', ['id']);
            $table->add_key('courseid', XMLDB_KEY_FOREIGN, ['courseid'], 'course', ['id']);
            $table->add_key('userid', XMLDB_KEY_FOREIGN, ['userid'], 'user', ['id']);

            // Add indexes
            $table->add_index('courseid_userid', XMLDB_INDEX_NOTUNIQUE, ['courseid', 'userid']);
            $table->add_index('userid', XMLDB_INDEX_NOTUNIQUE, ['userid']);
            $table->add_index('riskvalue', XMLDB_INDEX_NOTUNIQUE, ['riskvalue']);
            $table->add_index('timemodified', XMLDB_INDEX_NOTUNIQUE, ['timemodified']);

            // Create the table
            $dbman->create_table($table);
        }

        // Define table block_spp_suggestions if it doesn't exist
        if (!$dbman->table_exists('block_spp_suggestions')) {
            $table = new xmldb_table('block_spp_suggestions');

            // Add fields
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('predictionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('cmid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('resourcetype', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, null);
            $table->add_field('resourceid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('priority', XMLDB_TYPE_INTEGER, '3', null, XMLDB_NOTNULL, null, '5');
            $table->add_field('reason', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL, null, null);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('viewed', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('completed', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');

            // Add keys
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('predictionid', XMLDB_KEY_FOREIGN, ['predictionid'], 'block_spp_predictions', ['id']);
            $table->add_key('courseid', XMLDB_KEY_FOREIGN, ['courseid'], 'course', ['id']);
            $table->add_key('userid', XMLDB_KEY_FOREIGN, ['userid'], 'user', ['id']);

            // Add indexes
            $table->add_index('userid_priority', XMLDB_INDEX_NOTUNIQUE, ['userid', 'priority']);
            $table->add_index('userid_viewed', XMLDB_INDEX_NOTUNIQUE, ['userid', 'viewed']);
            $table->add_index('userid_completed', XMLDB_INDEX_NOTUNIQUE, ['userid', 'completed']);

            // Create the table
            $dbman->create_table($table);
        }

        // Define table block_spp_datasets if it doesn't exist
        if (!$dbman->table_exists('block_spp_datasets')) {
            $table = new xmldb_table('block_spp_datasets');

            // Add fields
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('name', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
            $table->add_field('description', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('filepath', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
            $table->add_field('fileformat', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, null);
            $table->add_field('columns', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
            $table->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            // Add keys
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('courseid', XMLDB_KEY_FOREIGN, ['courseid'], 'course', ['id']);
            $table->add_key('usermodified', XMLDB_KEY_FOREIGN, ['usermodified'], 'user', ['id']);

            // Add indexes
            $table->add_index('fileformat', XMLDB_INDEX_NOTUNIQUE, ['fileformat']);

            // Create the table
            $dbman->create_table($table);
        }

        // Define table block_spp_training_log if it doesn't exist
        if (!$dbman->table_exists('block_spp_training_log')) {
            $table = new xmldb_table('block_spp_training_log');

            // Add fields
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('modelid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
            $table->add_field('event', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, null);
            $table->add_field('message', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL, null, null);
            $table->add_field('level', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, 'info');
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

            // Add keys
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_key('modelid', XMLDB_KEY_FOREIGN, ['modelid'], 'block_spp_models', ['id']);

            // Add indexes
            $table->add_index('event_idx', XMLDB_INDEX_NOTUNIQUE, ['event']);
            $table->add_index('level_idx', XMLDB_INDEX_NOTUNIQUE, ['level']);

            // Create the table
            $dbman->create_table($table);
        }

        // Set the initial plugin version
        upgrade_block_savepoint(true, 2023112800, 'studentperformancepredictor');
    }

    // Add errormessage field to block_spp_models for error reporting in model training
    if ($oldversion < 2023112801) {
        $table = new xmldb_table('block_spp_models');
        $field = new xmldb_field('errormessage', XMLDB_TYPE_TEXT, null, null, null, null, null, 'trainstatus');

        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        upgrade_block_savepoint(true, 2023112801, 'studentperformancepredictor');
    }

    return true;
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Student Performance Predictor';
$string['studentperformancepredictor:addinstance'] = 'Add a new Student Performance Predictor block';
$string['studentperformancepredictor:myaddinstance'] = 'Add a new Student Performance Predictor block to Dashboard';
$string['studentperformancepredictor:managemodels'] = 'Manage prediction models';
$string['studentperformancepredictor:view'] = 'View Student Performance Predictor';
$string['studentperformancepredictor:viewallpredictions'] = 'View all student predictions';
$string['studentperformancepredictor:viewdashboard'] = 'View Student Performance Predictor dashboard';

// General strings
$string['studentperformance'] = 'Your Performance Prediction';
$string['courseperformance'] = 'Course Performance Overview';
$string['modelmanagement'] = 'Model Management';
$string['risk'] = 'Risk level';
$string['passingchance'] = 'Passing chance';
$string['failingchance'] = 'Failing chance';
$string['riskdistribution'] = 'Risk distribution';
$string['riskdistributionchart'] = 'Student Risk Distribution Chart'; // Added
$string['suggestedactivities'] = 'Suggested activities';
$string['generalstudy'] = 'General study recommendation';
$string['lastupdate'] = 'Last updated: {$a}';
$string['studentcount'] = 'Student count';
$string['nocoursecontext'] = 'This block must be added to a course page';
$string['errorrendingblock'] = 'An error occurred while rendering the block';
$string['charterror'] = 'Error loading chart';
$string['nocoursesfound'] = 'No courses found where you can view predictions';
$string['jsrequired'] = 'This chart requires JavaScript to be enabled';
$string['nosuggestions'] = 'No suggestions available at this time';
$string['studentpredictionstable'] = 'Table of Student Predictions'; // Added

// Risk levels
$string['highrisk_label'] = 'High risk';
$string['mediumrisk_label'] = 'Medium risk';
$string['lowrisk_label'] = 'Low risk';
$string['unknownrisk'] = 'Unknown risk';

// Admin and models
$string['managemodels'] = 'Manage models';
$string['managedatasets'] = 'Manage datasets';
$string['refreshpredictions'] = 'Refresh predictions';
$string['refreshpredictionsdesc'] = 'Refresh all student performance predictions for this course using the active model. This may take some time.'; // Added
$string['trainnewmodel'] = 'Train new model';
$string['allmodels'] = 'All models';
$string['currentmodel'] = 'Current active model';
$string['modelname'] = 'Model name';
$string['algorithm'] = 'Algorithm';
$string['accuracy'] = 'Accuracy';
$string['status'] = 'Status';
$string['created'] = 'Created';
$string['actions'] = 'Actions';
$string['active'] = 'Active';
$string['inactive'] = 'Inactive';
$string['activate'] = 'Activate';
$string['deactivate'] = 'Deactivate';
$string['training'] = 'Training...';
$string['datasetname'] = 'Dataset name';
$string['datasetdescription'] = 'Dataset description';
$string['datasetfile'] = 'Dataset file';
$string['datasetformat'] = 'Dataset format';
$string['csvformat'] = 'CSV format';
$string['jsonformat'] = 'JSON format';
$string['uploaded'] = 'Uploaded';
$string['totalstudents'] = 'Total students';
$string['view'] = 'View';
$string['delete'] = 'Delete';
$string['refresh'] = 'Refresh';
$string['refreshing'] = 'Refreshing...';
$string['selectdataset'] = 'Select dataset';
$string['selectalgorithm'] = 'Select algorithm';
$string['selectcourse'] = 'Select a course';
$string['trainmodel'] = 'Train model';
$string['modelactivated'] = 'Model activated successfully';
$string['modeldeactivated'] = 'Model deactivated successfully';
$string['errorupdatingmodel'] = 'Error updating model status';
$string['modelnotincourse'] = 'The model does not belong to this course';
$string['uploading'] = 'Uploading...';
$string['upload'] = 'Upload';
$string['datasetsaved'] = 'Dataset saved successfully';
$string['datasetsaved_backend'] = 'Dataset saved successfully. It is now available for training models.';
$string['datasetsaveerror'] = 'Error saving dataset';
$string['uploadnewdataset'] = 'Upload new dataset';
$string['existingdatasets'] = 'Existing datasets';
$string['nocoursesavailable'] = 'No courses available where you can manage models';
$string['coursename'] = 'Course name';
$string['directorycreateerror'] = 'Could not create directory: {$a}';
$string['directorynotwritable'] = 'Directory is not writable: {$a}';
$string['nofileuploaded'] = 'No file was uploaded';
$string['fileuploaderror'] = 'Error uploading file';
$string['filetoolarge'] = 'The uploaded file is too large';
$string['filepartialuploaded'] = 'The file was only partially uploaded';
$string['invalidfileextension'] = 'Invalid file extension for the selected format';
$string['fileuploadfailed'] = 'File upload failed';
$string['datasetdeleted'] = 'Dataset deleted successfully';
$string['filedeleteerror'] = 'Error deleting dataset file';
$string['databasedeleteerror'] = 'Error deleting dataset record from database';
$string['datasetnotincourse'] = 'The dataset does not belong to this course';
$string['noactivemodel'] = 'No active model found for this course. Please train a model first.';
$string['noprediction'] = 'No prediction available. Please refresh predictions.';
$string['nodatasets'] = 'No datasets available. Please upload a dataset first.';
$string['datasetdeletecascade'] = 'Warning: Deleting a dataset will also delete all models trained from it.';
$string['datasetdeletecascadetitle'] = 'Delete dataset and associated models';
$string['columns'] = 'Columns';
$string['viewtasks'] = 'View task monitor';
$string['taskname'] = 'Task Name'; // Added
$string['nextruntime'] = 'Next Run Time'; // Added
$string['taskqueued'] = 'Queued'; // Added
$string['taskrunning'] = 'Running'; // Added
$string['notasks'] = 'No tasks found for this plugin.'; // Added
$string['property'] = 'Property';
$string['value'] = 'Value';
$string['back'] = 'Back';
$string['trainmodel_backenddesc'] = 'Train a model using this dataset and the Python backend.';
$string['training_model'] = 'Training model';
$string['training_already_scheduled'] = 'A model training task is already scheduled for this course.';
$string['model_training_queued'] = 'Model training has been queued. This process may take a few minutes.';
$string['model_training_queued_backend'] = 'Model training has been queued. The Python backend will handle the training process.';
$string['model_training_success_subject'] = 'Model training completed';
$string['model_training_success_message'] = 'The model "{$a->modelname}" for course "{$a->coursename}" has been trained successfully.';
$string['model_training_error_subject'] = 'Model training failed';
$string['model_training_error_message'] = 'There was an error training the model for course "{$a->coursename}": {$a->error}';
$string['dataset_not_found'] = 'The selected dataset was not found for this course.';
$string['task_scheduled_predictions'] = 'Scheduled prediction refresh';
$string['task_train_model'] = 'Train student performance prediction models';
$string['training_model'] = 'Training model'; // Duplicate, keeping as is.

// New strings from PHP code analysis
$string['nostudentdata'] = 'No comprehensive student data found for prediction.'; // Added
$string['errorpredicting'] = 'Error occurred during prediction.'; // Added
$string['trainingfailed'] = 'Model training failed.'; // Added
$string['invalidinput'] = 'Invalid input provided.'; // Added
$string['invaliddataset'] = 'Invalid dataset selected or dataset not found.'; // Added
$string['invalidcourseid'] = 'Invalid course ID.'; // Added
$string['error:nocourseid'] = 'Course ID could not be determined.'; // Added from JS

// Suggestion actions
$string['markasviewed'] = 'Mark as viewed';
$string['markascompleted'] = 'Mark as completed';
$string['viewed'] = 'Viewed';
$string['completed'] = 'Completed';
$string['suggestion_marked_viewed'] = 'Suggestion marked as viewed';
$string['suggestion_marked_viewed_error'] = 'Error marking suggestion as viewed';
$string['suggestion_marked_completed'] = 'Suggestion marked as completed';
$string['suggestion_marked_completed_error'] = 'Error marking suggestion as completed';

// Algorithms
$string['algorithm_logisticregression'] = 'Logistic Regression';
$string['algorithm_randomforest'] = 'Random Forest';
$string['algorithm_svm'] = 'Support Vector Machine (SVM)';
$string['algorithm_decisiontree'] = 'Decision Tree';
$string['algorithm_knn'] = 'K-Nearest Neighbors';
$string['algorithmsettings'] = 'Algorithm settings';
$string['algorithmsettings_desc'] = 'Configure default algorithm settings for model training.';
$string['defaultalgorithm'] = 'Default algorithm';
$string['defaultalgorithm_desc'] = 'The default algorithm to use when training new models';

// Reports
$string['detailedreport'] = 'Detailed report';
$string['backtocourse'] = 'Back to course';
$string['predictiondetails'] = 'Prediction details';
$string['predictionfor'] = 'Prediction for {$a}';
$string['nopredictionavailable'] = 'No prediction is available for this student';
$string['predictiongenerated'] = 'Prediction generated successfully';
$string['predictionerror'] = 'Error generating prediction';
$string['errorloadingprediction'] = 'Error loading prediction data';
$string['viewdetails'] = 'View details';
$string['somepredictionsmissing'] = 'There are {$a} students without predictions. Consider refreshing predictions.';
$string['studentswithoutpredictions_backend'] = '{$a} students currently do not have predictions. Consider refreshing all predictions.'; // Added
$string['refreshallpredictions'] = 'Refresh all predictions';
$string['refreshexplanation'] = 'Refreshing predictions will generate new predictions for all students based on their current activity and performance data.';
$string['backtomodels'] = 'Back to models';
$string['currentpredictionstats'] = 'Current prediction statistics';
$string['lastrefreshtime'] = 'Last refresh: {$a}';

// Settings
$string['backendsettings'] = 'Backend integration';
$string['backendsettings_desc'] = 'Configure the Python backend for model training and prediction.';
$string['python_api_url'] = 'Python backend API URL';
$string['python_api_url_desc'] = 'The URL of the Python backend endpoint (e.g., http://localhost:5000).';
$string['python_api_key'] = 'Python backend API key';
$string['python_api_key_desc'] = 'The API key for authenticating requests to the Python backend.';
$string['riskthresholds'] = 'Risk thresholds';
$string['riskthresholds_desc'] = 'Thresholds for determining risk levels based on pass probability';
$string['lowrisk'] = 'Low risk threshold';
$string['lowrisk_desc'] = 'Students with pass probability above this value are considered low risk (0-1)';
$string['mediumrisk'] = 'Medium risk threshold';
$string['mediumrisk_desc'] = 'Students with pass probability above this value but below the low risk threshold are considered medium risk (0-1)';

// Tasks and notifications
$string['prediction_refresh_complete_subject'] = 'Prediction refresh completed';
$string['prediction_refresh_complete_message'] = 'The prediction refresh for course {$a->coursename} has completed. Processed {$a->total} students with {$a->success} successful predictions and {$a->errors} errors.';
$string['prediction_refresh_complete_small'] = 'Prediction refresh completed';
$string['predictionsrefreshqueued'] = 'Prediction refresh has been queued';
$string['predictionsrefresherror'] = 'Error queueing prediction refresh';
$string['refreshconfirmation'] = 'Are you sure you want to refresh predictions for all students? This may take some time.';
$string['refresherror'] = 'Error refreshing predictions';
$string['confirmactivate'] = 'Are you sure you want to activate this model? This will deactivate any currently active model.';
$string['confirmdeactivate'] = 'Are you sure you want to deactivate this model? No predictions will be generated until another model is activated.';
$string['confirmdeletedataset'] = 'Are you sure you want to delete this dataset? This will also delete all models trained with it.';
$string['invalidrequest'] = 'Invalid request';
$string['error:nocourseid'] = 'Course ID could not be determined'; // Exists as string
$string['actionerror'] = 'Error performing action';
$string['uploaderror'] = 'Error uploading file';

// Events
$string['event_model_trained'] = 'Prediction model trained';

// Suggestions strings
$string['suggestion_forum_low'] = 'Engaging in this forum discussion will help deepen your understanding of the course material.';
$string['suggestion_resource_low'] = 'Reviewing this resource will reinforce your knowledge of key concepts.';
$string['suggestion_quiz_medium'] = 'Taking this quiz will help identify areas where you need to focus more attention.';
$string['suggestion_forum_medium'] = 'Participating in this forum discussion will help clarify concepts you may be struggling with.';
$string['suggestion_assign_medium'] = 'Completing this assignment will strengthen your skills and understanding.';
$string['suggestion_resource_medium'] = 'Studying this resource is important for improving your understanding of the course material.';
$string['suggestion_quiz_high'] = 'This quiz is critical for your success. Taking it will help identify key areas for improvement.';
$string['suggestion_forum_high'] = 'Actively participating in this forum is essential for your success in this course.';
$string['suggestion_assign_high'] = 'Completing this assignment is urgent and will significantly impact your course performance.';
$string['suggestion_resource_high'] = 'This resource contains critical information you need to review immediately.';
$string['suggestion_workshop_high'] = 'This peer assessment activity will provide valuable feedback to improve your understanding.';
$string['suggestion_time_management'] = 'Consider creating a study schedule to better manage your coursework.';
$string['suggestion_engagement'] = 'Try to engage more regularly with the course materials and activities.';
$string['suggestion_study_group'] = 'Consider forming or joining a study group with classmates to discuss course topics.';
$string['suggestion_instructor_help'] = 'It would be beneficial to schedule a meeting with your instructor to discuss your progress.';
$string['suggestion_targeted_area'] = 'This is particularly important for improving your understanding of {$a->area}.';
$string['suggestion_weak_area'] = 'Focus more attention on {$a->area} as your performance in this area needs improvement.';

// Privacy strings
$string['privacy:metadata:block_spp_predictions'] = 'Information about student performance predictions';
$string['privacy:metadata:block_spp_predictions:modelid'] = 'The ID of the model used for prediction';
$string['privacy:metadata:block_spp_predictions:courseid'] = 'The ID of the course the prediction is for';
$string['privacy:metadata:block_spp_predictions:userid'] = 'The ID of the user the prediction is for';
$string['privacy:metadata:block_spp_predictions:passprob'] = 'The predicted probability of passing';
$string['privacy:metadata:block_spp_predictions:riskvalue'] = 'The calculated risk level';
$string['privacy:metadata:block_spp_predictions:predictiondata'] = 'Additional prediction details';
$string['privacy:metadata:block_spp_predictions:timecreated'] = 'Time the prediction was created';
$string['privacy:metadata:block_spp_predictions:timemodified'] = 'Time the prediction was last modified';

$string['privacy:metadata:block_spp_suggestions'] = 'Information about suggestions for improving student performance';
$string['privacy:metadata:block_spp_suggestions:predictionid'] = 'The ID of the prediction this suggestion is based on';
$string['privacy:metadata:block_spp_suggestions:courseid'] = 'The ID of the course this suggestion is for';
$string['privacy:metadata:block_spp_suggestions:userid'] = 'The ID of the user this suggestion is for';
$string['privacy:metadata:block_spp_suggestions:cmid'] = 'The course module ID being suggested';
$string['privacy:metadata:block_spp_suggestions:resourcetype'] = 'The type of resource being suggested';
$string['privacy:metadata:block_spp_suggestions:resourceid'] = 'The ID of the resource being suggested';
$string['privacy:metadata:block_spp_suggestions:priority'] = 'The priority of the suggestion';
$string['privacy:metadata:block_spp_suggestions:reason'] = 'The reason for the suggestion';
$string['privacy:metadata:block_spp_suggestions:timecreated'] = 'Time the suggestion was created';
$string['privacy:metadata:block_spp_suggestions:viewed'] = 'Whether the suggestion has been viewed';
$string['privacy:metadata:block_spp_suggestions:completed'] = 'Whether the suggestion has been completed';

$string['privacy:predictionpath'] = 'Prediction {$a}';
$string['privacy:suggestionpath'] = 'Suggestion {$a}';

// Add to lang/en/block_studentperformancepredictor.php
$string['backendmonitoring'] = 'Backend monitoring';
$string['backendmonitoring_desc'] = 'Tools to monitor the Python ML backend';
$string['testbackend'] = 'Test backend connection';
$string['testbackendbutton'] = 'Test connection';
$string['testingconnection'] = 'Testing connection to ML backend';
$string['testingbackendurl'] = 'Testing URL: {$a}';
$string['backendconnectionsuccess'] = 'Success! Connection to ML backend established.';
$string['backendconnectionfailed'] = 'Connection failed with HTTP code: {$a}';
$string['backendconnectionerror'] = 'Connection error: {$a}';
$string['backenddetails'] = 'Backend details';
$string['errormessage'] = 'Error message';
$string['troubleshootingguide'] = 'Troubleshooting guide';
$string['troubleshoot1'] = 'Verify the Python backend is running (uvicorn ml_backend:app)';
$string['troubleshoot2'] = 'Ensure the API URL in settings is correct (e.g., http://localhost:5000)';
$string['troubleshoot3'] = 'Check that the API key matches the one in the backend .env file';
$string['troubleshoot4'] = 'For Windows/XAMPP users: Make sure port 5000 is not blocked by firewall';
$string['troubleshoot5'] = 'Try running the backend with administrator privileges';
$string['startbackendcommand'] = 'Command to start backend';
$string['backsettings'] = 'Back to settings';
$string['debugsettings'] = 'Debug settings';
$string['debugsettings_desc'] = 'Configure debugging options';
$string['enabledebug'] = 'Enable debug mode';
$string['enabledebug_desc'] = 'Show detailed error messages and log additional information';
$string['jserror'] = 'JavaScript error';
$string['trainingschedulefailed'] = 'Failed to schedule training task';
$string['tablesnotinstalled'] = 'The Student Performance Predictor database tables are not installed. Please try reinstalling the plugin or contact your administrator. <a href="{$a}">Go to plugin installer</a>';

{{!
    This file is part of Moodle - http://moodle.org/

    Moodle is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Moodle is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
}}
{{!
    @template block_studentperformancepredictor/admin_settings

    Admin settings template

    Context variables required for this template:
    * heading - Block heading
    * courseid - Course ID
    * hasmodel - Whether there is an active model
    * nomodeltext - Text to display when there is no model
    * managemodelsurl - URL to manage models page
    * managedatasetsurl - URL to manage datasets page
    * refreshpredictionsurl - URL to refresh predictions page
    * totalstudents - Total number of students
    * highrisk - Number of high risk students
    * mediumrisk - Number of medium risk students
    * lowrisk - Number of low risk students
    * highriskpercent - Percentage of high risk students
    * mediumriskpercent - Percentage of medium risk students
    * lowriskpercent - Percentage of low risk students
    * haschart - Whether to show chart
    * chartdata - Chart data in JSON format
}}

<section class="block_studentperformancepredictor mb-4" data-course-id="{{courseid}}">
    <header>
        <h4 class="spp-heading">{{heading}}</h4>
    </header>

    <div class="spp-admin-actions mb-3">
        <div class="btn-group" role="group">
            <a href="{{managemodelsurl}}" class="btn btn-primary">
                {{#str}}managemodels, block_studentperformancepredictor{{/str}}
            </a>
            <a href="{{managedatasetsurl}}" class="btn btn-secondary">
                {{#str}}managedatasets, block_studentperformancepredictor{{/str}}
            </a>
            <a href="{{refreshpredictionsurl}}" class="btn btn-secondary">
                {{#str}}refreshpredictions, block_studentperformancepredictor{{/str}}
            </a>
        </div>
    </div>

    {{^hasmodel}}
        <div class="alert alert-warning" role="alert">
            {{{nomodeltext}}}
        </div>
    {{/hasmodel}}

    {{#hasmodel}}
        <section class="spp-course-overview">
            <div class="row">
                <div class="col-md-6">
                    <div class="spp-stats">
                        <div class="spp-stat-total">
                            <span class="spp-label">{{#str}}totalstudents, block_studentperformancepredictor{{/str}}</span>
                            <span class="spp-value">{{totalstudents}}</span>
                        </div>
                        <div class="spp-risk-distribution">
                            <div class="spp-risk-high">
                                <span class="spp-label">{{#str}}highrisk_label, block_studentperformancepredictor{{/str}}</span>
                                <span class="spp-value">{{highrisk}} ({{highriskpercent}}%)</span>
                            </div>
                            <div class="spp-risk-medium">
                                <span class="spp-label">{{#str}}mediumrisk_label, block_studentperformancepredictor{{/str}}</span>
                                <span class="spp-value">{{mediumrisk}} ({{mediumriskpercent}}%)</span>
                            </div>
                            <div class="spp-risk-low">
                                <span class="spp-label">{{#str}}lowrisk_label, block_studentperformancepredictor{{/str}}</span>
                                <span class="spp-value">{{lowrisk}} ({{lowriskpercent}}%)</span>
                            </div>
                        </div>
                    </div>
                </div>
                {{#haschart}}
                <div class="col-md-6">
                    <div class="spp-chart-container" aria-label="{{#str}}riskdistribution, block_studentperformancepredictor{{/str}}">
                        <canvas id="spp-admin-chart" data-chartdata="{{chartdata}}"></canvas>
                        <noscript>
                            <div class="alert alert-info mt-2">{{#str}}jsrequired, block_studentperformancepredictor{{/str}}</div>
                        </noscript>
                    </div>
                </div>
                {{/haschart}}
            </div>
        </section>
    {{/hasmodel}}
</section>

{{!
    This file is part of Moodle - http://moodle.org/

    Moodle is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Moodle is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
}}
{{!
    @template block_studentperformancepredictor/prediction_details

    Prediction details template

    Classes required for JS:
    * none

    Data attributes required for JS:
    * none

    Context variables required for this template:
    * prediction - Prediction data
      * passprob - Pass probability percentage
      * riskvalue - Risk level (1-3)
      * risktext - Risk level text
      * riskclass - Risk level CSS class
      * lastupdate - Last update timestamp
    * suggestions - Array of suggestions
      * id - Suggestion ID
      * reason - Suggestion reason
      * hasurl - Whether suggestion has URL
      * url - Suggestion URL
      * name - Suggestion name
      * viewed - Whether suggestion was viewed
      * completed - Whether suggestion was completed

    Example context (json):
    {
        "prediction": {
            "passprob": 75,
            "riskvalue": 1,
            "risktext": "Low risk",
            "riskclass": "spp-risk-low",
            "lastupdate": "Monday, 1 January 2023, 12:00 AM"
        },
        "suggestions": [
            {
                "id": 1,
                "reason": "This quiz will help you improve your understanding.",
                "hasurl": true,
                "url": "https://example.com",
                "name": "Practice Quiz",
                "viewed": false,
                "completed": false
            }
        ]
    }
}}

<section class="spp-prediction-details">
    <div class="spp-prediction-summary">
        <div class="spp-probability">
            <span class="spp-label">{{#str}}passingchance, block_studentperformancepredictor{{/str}}</span>
            <span class="spp-value">{{prediction.passprob}}%</span>
        </div>
        <div class="spp-risk {{prediction.riskclass}}">
            <span class="spp-label">{{#str}}risk, block_studentperformancepredictor{{/str}}</span>
            <span class="spp-value">{{prediction.risktext}}</span>
        </div>
        <div class="spp-update-time">
            <small>{{#str}}lastupdate, block_studentperformancepredictor, {{prediction.lastupdate}}{{/str}}</small>
        </div>
    </div>

    {{#suggestions}}
    <div class="spp-suggestions mt-3">
        <h6>{{#str}}suggestedactivities, block_studentperformancepredictor{{/str}}</h6>
        <ul class="list-group" aria-label="{{#str}}suggestedactivities, block_studentperformancepredictor{{/str}}">
            {{#suggestions}}
            <li class="list-group-item">
                {{#hasurl}}
                    <a href="{{url}}" target="_blank" rel="noopener noreferrer">{{name}}</a>:
                {{/hasurl}}
                {{^hasurl}}
                    <span>{{name}}</span>:
                {{/hasurl}}
                {{reason}}
                {{#viewed}}
                    <span class="badge bg-secondary">{{#str}}viewed, block_studentperformancepredictor{{/str}}</span>
                {{/viewed}}
                {{#completed}}
                    <span class="badge bg-success">{{#str}}completed, block_studentperformancepredictor{{/str}}</span>
                {{/completed}}
            </li>
            {{/suggestions}}
        </ul>
    </div>
    {{/suggestions}}
    {{^suggestions}}
    <div class="alert alert-info mt-3">{{#str}}nosuggestions, block_studentperformancepredictor{{/str}}</div>
    {{/suggestions}}
</section>

{{!
    This file is part of Moodle - http://moodle.org/

    Moodle is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Moodle is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
}}
{{!
    @template block_studentperformancepredictor/student_dashboard

    Student dashboard template

    Context variables required for this template:
    * heading - Block heading
    * courseid - Course ID for AJAX calls
    * hasmodel - Whether there is an active model
    * nomodeltext - Text to display when there is no model
    * hasprediction - Whether there is a prediction
    * nopredictiontext - Text to display when there is no prediction
    * passprob - Pass probability percentage
    * riskvalue - Risk level (1-3)
    * risktext - Risk level text
    * riskclass - Risk level CSS class
    * lastupdate - Last update timestamp
    * hassuggestions - Whether there are suggestions
    * suggestions - Array of suggestions
    * haschart - Whether to show chart
    * chartdata - Chart data in JSON format
}}

<section class="block_studentperformancepredictor" data-course-id="{{courseid}}">
    <h4 class="spp-heading">{{heading}}</h4>

    {{^hasmodel}}
        <div class="alert alert-warning" role="alert">
            {{{nomodeltext}}}
        </div>
    {{/hasmodel}}

    {{#hasmodel}}
        {{^hasprediction}}
            <div class="alert alert-info" role="status">
                {{{nopredictiontext}}}
            </div>
        {{/hasprediction}}

        {{#hasprediction}}
            <section class="spp-prediction">
                <div class="row">
                    <div class="col-md-6">
                        <div class="spp-prediction-stats">
                            <div class="spp-probability">
                                <span class="spp-label">{{#str}}passingchance, block_studentperformancepredictor{{/str}}</span>
                                <span class="spp-value">{{passprob}}%</span>
                            </div>
                            <div class="spp-risk {{riskclass}}">
                                <span class="spp-label">{{#str}}risk, block_studentperformancepredictor{{/str}}</span>
                                <span class="spp-value">{{risktext}}</span>
                            </div>
                            <div class="spp-update-time">
                                <small>{{#str}}lastupdate, block_studentperformancepredictor, {{lastupdate}}{{/str}}</small>
                            </div>
                        </div>
                    </div>
                    {{#haschart}}
                    <div class="col-md-6">
                        <div class="spp-chart-container" aria-label="{{#str}}passingchance, block_studentperformancepredictor{{/str}}">
                            <canvas id="spp-prediction-chart" data-chartdata="{{chartdata}}"></canvas>
                            <noscript>
                                <div class="alert alert-info mt-2">{{#str}}jsrequired, block_studentperformancepredictor{{/str}}</div>
                            </noscript>
                        </div>
                    </div>
                    {{/haschart}}
                </div>
            </section>

            <section>
            {{#hassuggestions}}
                <div class="spp-suggestions">
                    <h5>{{#str}}suggestedactivities, block_studentperformancepredictor{{/str}}</h5>
                    <div class="list-group spp-suggestions-list" aria-label="{{#str}}suggestedactivities, block_studentperformancepredictor{{/str}}">
                        {{#suggestions}}
                            <div class="list-group-item spp-suggestion" data-id="{{id}}">
                                <div class="spp-suggestion-content">
                                    {{#hasurl}}
                                        <h6><a href="{{url}}" target="_blank" rel="noopener noreferrer">{{name}}</a></h6>
                                    {{/hasurl}}
                                    {{^hasurl}}
                                        <h6>{{name}}</h6>
                                    {{/hasurl}}
                                    <p>{{reason}}</p>
                                    <div class="spp-suggestion-actions">
                                        {{^viewed}}
                                            <button class="btn btn-sm btn-outline-secondary spp-mark-viewed" data-id="{{id}}">
                                                {{#str}}markasviewed, block_studentperformancepredictor{{/str}}
                                            </button>
                                        {{/viewed}}
                                        {{#viewed}}
                                            <span class="badge bg-secondary">{{#str}}viewed, block_studentperformancepredictor{{/str}}</span>
                                        {{/viewed}}
                                        {{^completed}}
                                            <button class="btn btn-sm btn-outline-primary spp-mark-completed" data-id="{{id}}">
                                                {{#str}}markascompleted, block_studentperformancepredictor{{/str}}
                                            </button>
                                        {{/completed}}
                                        {{#completed}}
                                            <span class="badge bg-success">{{#str}}completed, block_studentperformancepredictor{{/str}}</span>
                                        {{/completed}}
                                    </div>
                                </div>
                            </div>
                        {{/suggestions}}
                    </div>
                </div>
            {{/hassuggestions}}
            {{^hassuggestions}}
                <div class="alert alert-info mt-3">{{#str}}nosuggestions, block_studentperformancepredictor{{/str}}</div>
            {{/hassuggestions}}
            </section>
        {{/hasprediction}}
    {{/hasmodel}}
</section>

{{!
    This file is part of Moodle - http://moodle.org/

    Moodle is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Moodle is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
}}
{{!
    @template block_studentperformancepredictor/teacher_dashboard

    Teacher dashboard template

    Context variables required for this template:
    * heading - Block heading
    * courseid - Course ID
    * hasmodel - Whether there is an active model
    * nomodeltext - Text to display when there is no model
    * totalstudents - Total number of students
    * highrisk - Number of high risk students
    * mediumrisk - Number of medium risk students
    * lowrisk - Number of low risk students
    * highriskpercent - Percentage of high risk students
    * mediumriskpercent - Percentage of medium risk students
    * lowriskpercent - Percentage of low risk students
    * detailreporturl - URL to detailed report
    * haschart - Whether to show chart
    * chartdata - Chart data in JSON format
}}

<section class="block_studentperformancepredictor" data-course-id="{{courseid}}">
    <h4 class="spp-heading">{{heading}}</h4>

    {{^hasmodel}}
        <div class="alert alert-warning" role="alert">
            {{{nomodeltext}}}
        </div>
    {{/hasmodel}}

    {{#hasmodel}}
        <div class="spp-course-overview">
            <div class="row">
                <div class="col-md-6">
                    <div class="spp-stats">
                        <div class="spp-stat-total">
                            <span class="spp-label">{{#str}}totalstudents, block_studentperformancepredictor{{/str}}</span>
                            <span class="spp-value">{{totalstudents}}</span>
                        </div>

                        <div class="spp-risk-distribution">
                            <div class="spp-risk-high">
                                <span class="spp-label">{{#str}}highrisk_label, block_studentperformancepredictor{{/str}}</span>
                                <span class="spp-value">{{highrisk}} ({{highriskpercent}}%)</span>
                            </div>

                            <div class="spp-risk-medium">
                                <span class="spp-label">{{#str}}mediumrisk_label, block_studentperformancepredictor{{/str}}</span>
                                <span class="spp-value">{{mediumrisk}} ({{mediumriskpercent}}%)</span>
                            </div>

                            <div class="spp-risk-low">
                                <span class="spp-label">{{#str}}lowrisk_label, block_studentperformancepredictor{{/str}}</span>
                                <span class="spp-value">{{lowrisk}} ({{lowriskpercent}}%)</span>
                            </div>
                        </div>
                    </div>
                </div>

                {{#haschart}}
                <div class="col-md-6">
                    <div class="spp-chart-container" aria-label="{{#str}}riskdistribution, block_studentperformancepredictor{{/str}}">
                        <canvas id="spp-teacher-chart" data-chartdata="{{chartdata}}"></canvas>
                        <noscript>
                            <div class="alert alert-info mt-2">{{#str}}jsrequired, block_studentperformancepredictor{{/str}}</div>
                        </noscript>
                    </div>
                </div>
                {{/haschart}}
            </div>

            <div class="spp-teacher-actions mt-3">
                <a href="{{detailreporturl}}" class="btn btn-primary" target="_blank" rel="noopener noreferrer">
                    {{#str}}detailedreport, block_studentperformancepredictor{{/str}}
                </a>
                <button type="button" class="btn btn-secondary spp-refresh-predictions" data-course-id="{{courseid}}">
                    {{#str}}refreshpredictions, block_studentperformancepredictor{{/str}}
                </button>
            </div>
        </div>
    {{/hasmodel}}
</section>

# Student Performance Predictor for Moodle

## Overview

The Student Performance Predictor is a Moodle block plugin that uses machine learning to predict student performance in courses. It helps instructors identify at-risk students and provides personalized recommendations for students to improve their performance.

## Directory Structure Explanation

- **admin/** - Administrative interface files
  - `activatemodel.php` - Handles model activation/deactivation
  - `ajax_delete_dataset.php` - AJAX handler for dataset deletion
  - `ajax_refresh_predictions.php` - AJAX handler for refreshing predictions
  - `ajax_toggle_model.php` - AJAX handler for toggling model status
  - `managedatasets.php` - Interface for managing training datasets
  - `managemodels.php` - Interface for managing prediction models
  - `refreshpredictions.php` - Handles prediction refreshing
  - `train_model.php` - Initiates model training
  - `upload_dataset.php` - Handles dataset uploads
  - `viewdataset.php` - Shows dataset details
  - `viewtasks.php` - Shows task monitoring interface

- **amd/src/** - JavaScript modules
  - `admin_interface.js` - Admin interface functionality
  - `chart_renderer.js` - Chart visualization functionality
  - `prediction_viewer.js` - Prediction viewing and interaction

- **classes/** - PHP classes
  - **analytics/** - ML integration classes
    - `data_preprocessor.php` - Prepares data for ML
    - `model_trainer.php` - Trains prediction models
    - `predictor.php` - Makes predictions using models
    - `suggestion_generator.php` - Generates improvement suggestions
    - `training_manager.php` - Manages training workflow
  - **event/** - Event handlers
    - `model_trained.php` - Event triggered when model training completes
  - **external/** - External API
    - `api.php` - External API endpoints
  - **output/** - Output renderers
    - `renderer.php` - Main renderer
    - `student_view.php` - Student dashboard renderer
    - `teacher_view.php` - Teacher dashboard renderer
  - **privacy/** - GDPR compliance
    - `provider.php` - Privacy API implementation
  - **task/** - Background tasks
    - `adhoc_train_model.php` - Ad-hoc training task
    - `refresh_predictions.php` - Refreshes predictions
    - `scheduled_predictions.php` - Scheduled prediction updates

- **datasets/** - Directory for storing training datasets

- **db/** - Database and access definitions
  - `access.php` - Capability definitions
  - `install.xml` - Database schema
  - `services.php` - Web service definitions
  - `tasks.php` - Task definitions
  - `upgrade.php` - Plugin upgrade handling

- **lang/en/** - Language strings
  - `block_studentperformancepredictor.php` - English language strings

- **models/** - Directory for storing trained models

- **pix/** - Plugin images
  - `icon.png` - Plugin icon

- **templates/** - Mustache templates
  - `admin_settings.mustache` - Admin settings template
  - `prediction_details.mustache` - Prediction details template
  - `student_dashboard.mustache` - Student dashboard template
  - `teacher_dashboard.mustache` - Teacher dashboard template

- `block_studentperformancepredictor.php` - Main block class
- `lib.php` - Library functions
- `ml_backend.py` - Python ML backend
- `README.md` - Documentation
- `reports.php` - Detailed reports page
- `settings.php` - Plugin settings
- `styles.css` - CSS styles
- `version.php` - Version information

## Requirements

- Moodle 4.1 or higher
- PHP 7.4 or higher
- Python 3.7 or higher (for the ML backend)
- Required Python packages:
  - fastapi
  - uvicorn
  - scikit-learn
  - pandas
  - joblib
  - python-dotenv

## Installation

### Step 1: Install the Moodle Plugin

1. Download the plugin zip file
2. Log in to your Moodle site as an administrator
3. Go to Site administration > Plugins > Install plugins
4. Upload the plugin zip file
5. Follow the on-screen instructions to complete the installation

### Step 2: Set up the Python Backend

1. Navigate to the plugin directory:

cd /path/to/moodle/blocks/studentperformancepredictor

2. Install required Python packages:

pip install fastapi uvicorn scikit-learn pandas joblib python-dotenv

3. Create a `.env` file (based on .env.example) to set your API key:

API_KEY=your_secure_key_here

4. Start the Python backend:

uvicorn ml_backend:app --host 0.0.0.0 --port 5000

For Windows/XAMPP users:
- Make sure port 5000 is not blocked by Windows Firewall
- You may need to run the command prompt as administrator

### Step 3: Configure the Plugin

1. In Moodle, go to Site administration > Plugins > Blocks > Student Performance Predictor
2. Configure the backend URL (default: http://localhost:5000)
3. Enter the API key you set in the `.env` file
4. Adjust risk thresholds and other settings as needed

## How to Use the Plugin

### For Administrators

1. **Add the Block**: Add the Student Performance Predictor block to a course page
2. **Manage Datasets**:
   - Go to "Manage datasets" in the block
   - Upload a training dataset (CSV or JSON format)
   - The dataset should contain student activity features and a final outcome column
3. **Train Models**:
   - Go to "Manage models" in the block
   - Select a dataset and algorithm
   - Click "Train Model" to start the training process
4. **Activate Models**:
   - Once training is complete, activate the model to enable predictions
   - Only one model can be active per course

### For Teachers

1. **View Dashboard**:
   - The block shows an overview of student risk distribution
   - See how many students are at high, medium, and low risk
2. **Access Detailed Reports**:
   - Click "Detailed report" to see individual student predictions
   - Sort and filter students by risk level
3. **Refresh Predictions**:
   - Click "Refresh predictions" to update predictions with current data
4. **Intervene with At-Risk Students**:
   - Identify students who need help based on risk levels
   - Use the system's suggestions to guide interventions

### For Students

1. **View Personal Prediction**:
   - See their own performance prediction and risk level
   - View the probability of passing the course
2. **Access Personalized Suggestions**:
   - Review recommendations for improvement
   - Suggestions are tailored to their specific situation and risk level
3. **Track Progress**:
   - Mark suggestions as viewed or completed
   - Monitor changes in prediction as they complete activities

## How the Plugin Works

### Data Flow and Architecture

1. **Data Collection**:
   - The plugin collects student activity data from Moodle (course access, assignment submissions, quiz attempts, etc.)
   - Administrators upload historical datasets for training

2. **Model Training**:
   - The training dataset is sent to the Python backend
   - ML models are trained using scikit-learn algorithms
   - Model files and metadata are stored for future use

3. **Prediction Generation**:
   - When predictions are requested, current student data is sent to the backend
   - The active model makes predictions about student outcomes
   - Results are stored in the Moodle database

4. **Suggestion Generation**:
   - Based on predictions, the system generates tailored suggestions
   - Suggestions prioritize activities that could help improve performance
   - Different suggestions are provided based on risk level

5. **Visualization and Reporting**:
   - Predictions and statistics are visualized in dashboards
   - Charts show risk distribution and prediction confidence
   - Reports allow detailed analysis of student performance

### Backend-Frontend Integration

The plugin uses a hybrid architecture:
- PHP code in Moodle handles the user interface, data management, and workflow
- Python backend provides the machine learning capabilities
- Communication happens via REST API calls between Moodle and the Python service

## Troubleshooting

### Common Issues

1. **Backend Connection Errors**:
   - Verify the Python backend is running
   - Check the API URL in plugin settings
   - Ensure the API key matches in both Moodle settings and .env file
   - Check if firewall is blocking port 5000

2. **Model Training Failures**:
   - Check the dataset format (must include target/outcome column)
   - Ensure Python dependencies are installed correctly
   - Check ML backend logs for detailed error messages

3. **Missing Predictions**:
   - Verify an active model exists for the course
   - Try refreshing predictions manually
   - Check if students have sufficient activity data for prediction

4. **Performance Issues**:
   - Large datasets may require more processing time
   - Consider scheduling prediction updates during off-peak hours

## License

This plugin is licensed under the GNU General Public License v3.0.

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Detailed prediction reports for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters
$id = required_param('id', PARAM_INT);  // Course ID
$page = optional_param('page', 0, PARAM_INT);
$perpage = optional_param('perpage', 20, PARAM_INT);

// Set up page
$course = get_course($id);
$context = context_course::instance($id);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:viewallpredictions', $context);

// Set up page layout
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/reports.php', array('id' => $id)));
$PAGE->set_context($context);
$PAGE->set_title(get_string('detailedreport', 'block_studentperformancepredictor'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_pagelayout('report');

// Add necessary JavaScript
$PAGE->requires->js_call_amd('block_studentperformancepredictor/chart_renderer', 'initTeacherChart');
$PAGE->requires->js_call_amd('block_studentperformancepredictor/prediction_viewer', 'init');

// Output starts here
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('detailedreport', 'block_studentperformancepredictor'));

// Check if there's an active model
if (!block_studentperformancepredictor_has_active_model($id)) {
    echo $OUTPUT->notification(get_string('noactivemodel', 'block_studentperformancepredictor'), 'warning');
    echo html_writer::link(
        new moodle_url('/course/view.php', array('id' => $id)),
        get_string('backtocourse', 'block_studentperformancepredictor'),
        array('class' => 'btn btn-secondary')
    );
    echo $OUTPUT->footer();
    exit;
}

// Get risk statistics
$riskStats = block_studentperformancepredictor_get_course_risk_stats($id);

// Display summary
// All stats below are based on backend-driven predictions (see lib.php orchestration)
echo $OUTPUT->box_start('generalbox spp-summary-box');
echo html_writer::tag('h4', get_string('currentpredictionstats', 'block_studentperformancepredictor'));

echo html_writer::start_div('row');
echo html_writer::start_div('col-md-6');

echo html_writer::start_div('spp-stats');
echo html_writer::div(
    html_writer::span(get_string('totalstudents', 'block_studentperformancepredictor'), 'spp-label') . 
    html_writer::span($riskStats->total, 'spp-value'),
    'spp-stat-total'
);

echo html_writer::start_div('spp-risk-distribution');
echo html_writer::div(
    html_writer::span(get_string('highrisk_label', 'block_studentperformancepredictor'), 'spp-label spp-risk-high') . 
    html_writer::span($riskStats->highrisk . ' (' . round(($riskStats->highrisk / max(1, $riskStats->total)) * 100) . '%)', 'spp-value'),
    'spp-risk-high'
);
echo html_writer::div(
    html_writer::span(get_string('mediumrisk_label', 'block_studentperformancepredictor'), 'spp-label spp-risk-medium') . 
    html_writer::span($riskStats->mediumrisk . ' (' . round(($riskStats->mediumrisk / max(1, $riskStats->total)) * 100) . '%)', 'spp-value'),
    'spp-risk-medium'
);
echo html_writer::div(
    html_writer::span(get_string('lowrisk_label', 'block_studentperformancepredictor'), 'spp-label spp-risk-low') . 
    html_writer::span($riskStats->lowrisk . ' (' . round(($riskStats->lowrisk / max(1, $riskStats->total)) * 100) . '%)', 'spp-value'),
    'spp-risk-low'
);
echo html_writer::end_div(); // End risk distribution
echo html_writer::end_div(); // End stats

echo html_writer::end_div(); // End col-md-6

// Chart
// The chart data is based on backend-calculated risk stats
echo html_writer::start_div('col-md-6');
$chartdata = json_encode([
    'labels' => [
        get_string('highrisk_label', 'block_studentperformancepredictor'),
        get_string('mediumrisk_label', 'block_studentperformancepredictor'),
        get_string('lowrisk_label', 'block_studentperformancepredictor')
    ],
    'data' => [$riskStats->highrisk, $riskStats->mediumrisk, $riskStats->lowrisk]
]);
echo html_writer::div(
    '<canvas id="spp-teacher-chart" data-chartdata="' . $chartdata . '" aria-label="' . get_string('riskdistributionchart', 'block_studentperformancepredictor') . '"></canvas>' .
    '<noscript><div class="alert alert-info mt-2">' . get_string('jsrequired', 'block_studentperformancepredictor') . '</div></noscript>',
    'spp-chart-container'
);
echo html_writer::end_div(); // End col-md-6

echo html_writer::end_div(); // End row

// Refresh button (triggers backend prediction refresh for all students)
echo html_writer::start_div('mt-3');
echo html_writer::tag('button', get_string('refreshpredictions', 'block_studentperformancepredictor'), 
                      array('class' => 'btn btn-secondary spp-refresh-predictions', 
                           'data-course-id' => $id,
                           'type' => 'button',
                           'title' => get_string('refreshpredictionsdesc', 'block_studentperformancepredictor')));
echo html_writer::end_div();

echo $OUTPUT->box_end();

// Get all students with predictions
$students = get_enrolled_users($context, 'moodle/course:isincompletionreports', 0, 'u.*', null, $page*$perpage, $perpage);
$studentscount = count_enrolled_users($context, 'moodle/course:isincompletionreports');

// Start student table
$table = new html_table();
$table->head = array(
    get_string('fullname'),
    get_string('passingchance', 'block_studentperformancepredictor'),
    get_string('risk', 'block_studentperformancepredictor'),
    get_string('lastupdate', 'block_studentperformancepredictor'),
    get_string('actions')
);
$table->attributes['class'] = 'generaltable table-striped spp-student-table';
$table->attributes['aria-label'] = get_string('studentpredictionstable', 'block_studentperformancepredictor');
$table->data = array();

// Populate the table with student data
$missingpredictions = 0;
foreach ($students as $student) {
    $prediction = block_studentperformancepredictor_get_student_prediction($id, $student->id);
    $row = array();
    $row[] = fullname($student);
    if ($prediction) {
        $row[] = isset($prediction->passprob) ? round($prediction->passprob * 100) . '%' : '-';
        $riskclass = block_studentperformancepredictor_get_risk_class($prediction->riskvalue);
        $risktext = block_studentperformancepredictor_get_risk_text($prediction->riskvalue);
        $row[] = html_writer::tag('span', $risktext, array('class' => $riskclass));
        $row[] = isset($prediction->timemodified) ? userdate($prediction->timemodified) : '-';
    } else {
        $row[] = get_string('noprediction', 'block_studentperformancepredictor');
        $row[] = '-';
        $row[] = '-';
        $missingpredictions++;
    }
    // Actions
    $actions = html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/generate_prediction.php', 
            array('courseid' => $id, 'userid' => $student->id, 'redirect' => 0)),
        get_string('viewdetails', 'core'),
        array('class' => 'btn btn-sm btn-info')
    );
    $row[] = $actions;
    $table->data[] = $row;
}

// If any students are missing predictions, show a warning and suggest refresh
if ($missingpredictions > 0) {
    echo $OUTPUT->notification(get_string('somepredictionsmissing', 'block_studentperformancepredictor', $missingpredictions), 'warning');
}

echo html_writer::table($table);

// Pagination
echo $OUTPUT->paging_bar($studentscount, $page, $perpage, $PAGE->url);

// Add a "Back to course" button
echo html_writer::div(
    html_writer::link(
        new moodle_url('/course/view.php', array('id' => $id)),
        get_string('backtocourse', 'block_studentperformancepredictor'),
        array('class' => 'btn btn-secondary')
    ),
    'mt-3'
);

// Output footer
echo $OUTPUT->footer();

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Settings for the Student Performance Predictor block.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

if ($ADMIN->fulltree) {
    // Backend integration settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/backendsettings',
        get_string('backendsettings', 'block_studentperformancepredictor'),
        get_string('backendsettings_desc', 'block_studentperformancepredictor')));

    // Use http://localhost:5000 as default for XAMPP environments
    $settings->add(new admin_setting_configtext('block_studentperformancepredictor/python_api_url',
        get_string('python_api_url', 'block_studentperformancepredictor'),
        get_string('python_api_url_desc', 'block_studentperformancepredictor'),
        'http://localhost:5000'));

    $settings->add(new admin_setting_configpasswordunmask('block_studentperformancepredictor/python_api_key',
        get_string('python_api_key', 'block_studentperformancepredictor'),
        get_string('python_api_key_desc', 'block_studentperformancepredictor'),
        'changeme'));

    // Risk threshold settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/riskthresholds',
        get_string('riskthresholds', 'block_studentperformancepredictor'),
        get_string('riskthresholds_desc', 'block_studentperformancepredictor')));

    $settings->add(new admin_setting_configtext('block_studentperformancepredictor/lowrisk',
        get_string('lowrisk', 'block_studentperformancepredictor'),
        get_string('lowrisk_desc', 'block_studentperformancepredictor'),
        0.7, PARAM_FLOAT));

    $settings->add(new admin_setting_configtext('block_studentperformancepredictor/mediumrisk',
        get_string('mediumrisk', 'block_studentperformancepredictor'),
        get_string('mediumrisk_desc', 'block_studentperformancepredictor'),
        0.4, PARAM_FLOAT));

    // Algorithm settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/algorithmsettings',
        get_string('algorithmsettings', 'block_studentperformancepredictor'),
        get_string('algorithmsettings_desc', 'block_studentperformancepredictor')));

    $algorithms = [
        'randomforest' => get_string('algorithm_randomforest', 'block_studentperformancepredictor'),
        'logisticregression' => get_string('algorithm_logisticregression', 'block_studentperformancepredictor'),
        'svm' => get_string('algorithm_svm', 'block_studentperformancepredictor'),
        'decisiontree' => get_string('algorithm_decisiontree', 'block_studentperformancepredictor'),
        'knn' => get_string('algorithm_knn', 'block_studentperformancepredictor')
    ];

    $settings->add(new admin_setting_configselect('block_studentperformancepredictor/defaultalgorithm',
        get_string('defaultalgorithm', 'block_studentperformancepredictor'),
        get_string('defaultalgorithm_desc', 'block_studentperformancepredictor'),
        'randomforest', $algorithms));

    // Python backend monitoring settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/backendmonitoring',
        get_string('backendmonitoring', 'block_studentperformancepredictor', '', true),
        get_string('backendmonitoring_desc', 'block_studentperformancepredictor', '', true)));

    // Add a button to test the backend connection
    $testbackendurl = new moodle_url('/blocks/studentperformancepredictor/admin/testbackend.php');
    $settings->add(new admin_setting_description(
        'block_studentperformancepredictor/testbackend',
        get_string('testbackend', 'block_studentperformancepredictor', '', true),
        html_writer::link($testbackendurl, get_string('testbackendbutton', 'block_studentperformancepredictor'), 
            ['class' => 'btn btn-secondary', 'target' => '_blank'])
    ));

    // Debug mode settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/debugsettings',
        get_string('debugsettings', 'block_studentperformancepredictor', '', true),
        get_string('debugsettings_desc', 'block_studentperformancepredictor', '', true)));

    $settings->add(new admin_setting_configcheckbox('block_studentperformancepredictor/enabledebug',
        get_string('enabledebug', 'block_studentperformancepredictor', '', true),
        get_string('enabledebug_desc', 'block_studentperformancepredictor', '', true),
        0));
}

/* Main block styles */
.block_studentperformancepredictor {
    padding: 15px;
}

.block_studentperformancepredictor .spp-heading {
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
    font-size: 1.2rem;
    font-weight: 600;
}

/* Accessibility: Focus styles for all interactive elements */
.block_studentperformancepredictor a:focus, 
.block_studentperformancepredictor button:focus, 
.block_studentperformancepredictor .btn:focus, 
.block_studentperformancepredictor [tabindex]:focus {
    outline: 2px solid #005cbf;
    outline-offset: 2px;
    box-shadow: 0 0 0 2px #b8daff;
}
.block_studentperformancepredictor a:focus-visible, 
.block_studentperformancepredictor button:focus-visible, 
.block_studentperformancepredictor .btn:focus-visible {
    outline: 2px solid #005cbf;
    outline-offset: 2px;
}

/* Prediction stats styles */
.block_studentperformancepredictor .spp-prediction-stats {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 15px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.block_studentperformancepredictor .spp-probability {
    margin-bottom: 10px;
}

.block_studentperformancepredictor .spp-probability .spp-label,
.block_studentperformancepredictor .spp-risk .spp-label {
    display: block;
    font-weight: 500;
    margin-bottom: 5px;
}

.block_studentperformancepredictor .spp-probability .spp-value {
    font-size: 1.5rem;
    font-weight: 600;
}

/* Risk level styles with improved contrast */
.block_studentperformancepredictor .spp-risk {
    margin-bottom: 10px;
}

.block_studentperformancepredictor .spp-risk .spp-value {
    font-weight: 600;
}

.block_studentperformancepredictor .spp-risk-high {
    color: #b3001b;
    background: #f8d7da;
    border-radius: 4px;
    padding: 2px 6px;
}
.block_studentperformancepredictor .spp-risk-medium {
    color: #b36b00;
    background: #fff3cd;
    border-radius: 4px;
    padding: 2px 6px;
}
.block_studentperformancepredictor .spp-risk-low {
    color: #1e7e34;
    background: #d4edda;
    border-radius: 4px;
    padding: 2px 6px;
}
.block_studentperformancepredictor .spp-risk-unknown {
    color: #6c757d;
    background: #e2e3e5;
    border-radius: 4px;
    padding: 2px 6px;
}

/* Update time styles */
.block_studentperformancepredictor .spp-update-time {
    font-size: 0.85rem;
    color: #6c757d;
    margin-top: 5px;
}

/* Chart container styles */
.block_studentperformancepredictor .spp-chart-container {
    height: 250px;
    margin: 15px 0;
}

/* Suggestions styles */
.block_studentperformancepredictor .spp-suggestions {
    margin-top: 20px;
}

.block_studentperformancepredictor .spp-suggestions h5 {
    margin-bottom: 15px;
    font-size: 1.1rem;
    font-weight: 500;
}

.block_studentperformancepredictor .spp-suggestions-list .list-group-item {
    transition: background-color 0.2s;
    border-left: 3px solid transparent;
}

.block_studentperformancepredictor .spp-suggestions-list .list-group-item:hover {
    background-color: #f8f9fa;
}

.block_studentperformancepredictor .spp-suggestion-content h6 {
    margin-bottom: 8px;
    font-weight: 500;
}

.block_studentperformancepredictor .spp-suggestion-content p {
    color: #495057;
    margin-bottom: 10px;
}

.block_studentperformancepredictor .spp-suggestion-actions {
    margin-top: 10px;
}

.block_studentperformancepredictor .spp-suggestion-actions .btn {
    margin-right: 5px;
    margin-bottom: 5px;
}

.block_studentperformancepredictor .spp-suggestion-actions .badge {
    margin-right: 5px;
}

/* Admin interface styles */
.block_studentperformancepredictor .spp-admin-actions {
    margin-bottom: 20px;
}

.block_studentperformancepredictor .spp-course-overview {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 15px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.block_studentperformancepredictor .spp-stat-total {
    margin-bottom: 15px;
    border-bottom: 1px solid #e9ecef;
    padding-bottom: 10px;
}

.block_studentperformancepredictor .spp-stat-total .spp-label {
    font-weight: 500;
}

.block_studentperformancepredictor .spp-stat-total .spp-value {
    font-size: 1.5rem;
    font-weight: 600;
    margin-left: 10px;
}

.block_studentperformancepredictor .spp-risk-distribution .spp-label {
    display: inline-block;
    width: 100px;
    font-weight: 500;
}

.block_studentperformancepredictor .spp-risk-distribution > div {
    margin-bottom: 8px;
}

/* Loading indicator */
.block_studentperformancepredictor .spp-loading {
    text-align: center;
    padding: 20px;
    color: #6c757d;
}

.block_studentperformancepredictor .spp-loading i {
    margin-right: 10px;
}

/* Form styles */
.block_studentperformancepredictor .spp-form-container {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.block_studentperformancepredictor .spp-form-container .form-group {
    margin-bottom: 15px;
}

/* Table styles */
.block_studentperformancepredictor .spp-table {
    width: 100%;
    margin-bottom: 20px;
}

.block_studentperformancepredictor .spp-table th {
    background-color: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
    padding: 12px;
    font-weight: 500;
}

.block_studentperformancepredictor .spp-table td {
    padding: 12px;
    border-bottom: 1px solid #dee2e6;
}

.block_studentperformancepredictor .spp-table tr:hover {
    background-color: #f8f9fa;
}

/* Responsive styles */
@media (max-width: 768px) {
    .block_studentperformancepredictor .spp-chart-container {
        height: 200px;
    }
    .block_studentperformancepredictor .col-md-6 {
        margin-bottom: 15px;
    }
    .block_studentperformancepredictor .spp-admin-actions .btn-group {
        display: flex;
        flex-direction: column;
        width: 100%;
    }
    .block_studentperformancepredictor .spp-admin-actions .btn {
        margin-bottom: 5px;
        border-radius: 4px !important;
    }
    .block_studentperformancepredictor .spp-risk-distribution .spp-label {
        width: auto;
        margin-right: 10px;
    }
    .block_studentperformancepredictor .spp-heading {
        font-size: 1rem;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version details for the Student Performance Predictor block.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2025063003;        // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2022112800;        // Requires Moodle 4.1 or later.
$plugin->component = 'block_studentperformancepredictor'; // Full name of the plugin.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0.0';

Fix the code above and make sure that the code will works properly and well. FYI i use moodle version 5.0 and for the server i use XAMPP. So make the code works well on that. I cannot add this plugin in the course page, can you just make so this plugin being shown in dashboard so when the student open the web then they can see their performance and suggestion to improve their performance. The student only can see their own performance but the teacher and admin can see the performance for all of the student. Can you make the flow of training the model are first the admin will upload the dataset then the user choose what algorithm that they want. After that, the model will be train with the dataset and the result model will be appared in the model list and the user can choose what model that they want to choose to use for make the prediction based on the student performance. Make it into a proper plugin and make sure that the plugin ready to be used and helpful for the student. Take out all unused code and give me the all used code and give me full fixed code of it 