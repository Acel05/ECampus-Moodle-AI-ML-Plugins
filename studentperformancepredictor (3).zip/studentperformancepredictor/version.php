<?php
// blocks/studentperformancepredictor/version.php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2025063006;        // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2022112800;        // Requires Moodle 4.1 or later.
$plugin->component = 'block_studentperformancepredictor'; // Full name of the plugin.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.1.0';           // Updated for global model support