<?php
// blocks/studentperformancepredictor/classes/output/renderer.php

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

use plugin_renderer_base;

/**
 * Renderer for Student Performance Predictor block.
 */
class renderer extends plugin_renderer_base {

    /**
     * A helper function to ensure all necessary JS is loaded.
     */
    private function require_js_for_dashboard() {
        // This ensures jQuery is available.
        $this->page->requires->jquery();

        // This explicitly loads Moodle's core Bootstrap library, which includes the 'collapse' functionality.
        // It is the key to fixing the problem.
        $this->page->requires->js_call_amd('core/bootstrap', 'init');

        // This loads your block's specific JavaScript for handling predictions and suggestions.
        $this->page->requires->js_call_amd('block_studentperformancepredictor/prediction_viewer', 'init');
    }

    /**
     * Renders student_view.
     *
     * @param student_view $studentview The student view object
     * @return string HTML
     */
    public function render_student_view(student_view $studentview) {
        $data = $studentview->export_for_template($this);
        $this->require_js_for_dashboard();
        return $this->render_from_template('block_studentperformancepredictor/student_dashboard', $data);
    }

    /**
     * Renders teacher_view.
     *
     * @param teacher_view $teacherview The teacher view object
     * @return string HTML
     */
    public function render_teacher_view(teacher_view $teacherview) {
        $data = $teacherview->export_for_template($this);
        $this->require_js_for_dashboard();
        return $this->render_from_template('block_studentperformancepredictor/teacher_dashboard', $data);
    }

    /**
     * Renders admin_view.
     *
     * @param admin_view $adminview The admin view object
     * @return string HTML
     */
    public function render_admin_view(admin_view $adminview) {
        $data = $adminview->export_for_template($this);
        $this->require_js_for_dashboard();
        return $this->render_from_template('block_studentperformancepredictor/admin_dashboard', $data);
    }
}