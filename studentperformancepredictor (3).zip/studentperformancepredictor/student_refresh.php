<?php
// blocks/studentperformancepredictor/student_refresh.php

require_once('../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get and validate parameters
$courseid = required_param('courseid', PARAM_INT);
$userid = required_param('userid', PARAM_INT);

// Define the redirect URL for both success and failure
$redirecturl = new moodle_url('/course/view.php', ['id' => $courseid]);

try {
    // Security checks
    require_login();
    require_sesskey();

    // Ensure the user is updating their own prediction
    if ($USER->id != $userid) {
        throw new moodle_exception('nopermission', 'error');
    }

    $context = context_course::instance($courseid);
    require_capability('block/studentperformancepredictor:view', $context);

    // Generate a new prediction for the current user
    $prediction = block_studentperformancepredictor_generate_new_prediction($courseid, $USER->id);

    if ($prediction) {
        // Redirect with a success message
        redirect($redirecturl, get_string('predictiongenerated', 'block_studentperformancepredictor'), 2, \core\output\notification::NOTIFY_SUCCESS);
    } else {
        // The function returned false, indicating an error. The specific error is caught by the generate_new_prediction function.
        throw new moodle_exception('predictionerror', 'block_studentperformancepredictor');
    }

} catch (Exception $e) {
    // Catch any error, show a notification, and redirect
    redirect($redirecturl, $e->getMessage(), 5, \core\output\notification::NOTIFY_ERROR);
}