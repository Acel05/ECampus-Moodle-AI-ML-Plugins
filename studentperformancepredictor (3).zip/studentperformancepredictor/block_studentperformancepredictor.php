<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Student Performance Predictor block.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// Ensure lib.php is included at the top for all function definitions
require_once(__DIR__ . '/lib.php');

/**
 * Student Performance Predictor block class.
 */
class block_studentperformancepredictor extends block_base {
    /**
     * Block content property.
     * @var stdClass|null
     */
    public $content = null;

    /**
     * Initialize the block.
     */
    public function init() {
        $this->title = get_string('pluginname', 'block_studentperformancepredictor');
    }

    /**
     * Indicates that this block has its own configuration settings.
     *
     * @return bool
     */
    public function has_config() {
        return true;
    }

    /**
     * Indicates whether each instance of the block can be configured.
     *
     * @return bool
     */
    public function instance_allow_config() {
        return true;
    }

    /**
     * Returns the content of the block.
     *
     * @return stdClass
     */
    public function get_content() {
        global $USER, $PAGE, $OUTPUT, $DB, $CFG, $COURSE;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->text = '';
        $this->content->footer = '';

        // Must be logged in to view the block
        if (!isloggedin() || isguestuser()) {
            return $this->content;
        }

        // Add CSS for styling
        $PAGE->requires->css('/blocks/studentperformancepredictor/styles.css');

        // Check if tables exist
        if (!block_studentperformancepredictor_tables_exist()) {
            $this->content->text = $OUTPUT->notification(
                get_string('tablesnotinstalled', 'block_studentperformancepredictor',
                    $CFG->wwwroot . '/admin/tool/installaddon/index.php'),
                'error'
            );
            return $this->content;
        }

        // Find an appropriate course for predictions
        // First check if we're in a course context
        $courseid = $COURSE->id;
        if (!$courseid || $courseid == SITEID) {
            // We're not in a course, try to find an appropriate one
            $courseid = $this->get_appropriate_course();
            if (!$courseid) {
                $this->content->text = $OUTPUT->notification(
                    get_string('nocoursesfound', 'block_studentperformancepredictor'),
                    'info'
                );
                return $this->content;
            }
        }

        // Set up appropriate context
        try {
            $context = context_course::instance($courseid);
        } catch (Exception $e) {
            debugging('Error getting course context: ' . $e->getMessage(), DEBUG_DEVELOPER);
            $this->content->text = $OUTPUT->notification(
                get_string('errorrendingblock', 'block_studentperformancepredictor'),
                'error'
            );
            return $this->content;
        }

        // Check if user has capability to view the block
        if (!has_capability('block/studentperformancepredictor:view', $context)) {
            return $this->content;
        }

        try {
            // Different views for different user roles
            if (has_capability('block/studentperformancepredictor:managemodels', $context)) {
                // Admin view
                $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
                $adminview = new \block_studentperformancepredictor\output\admin_view($courseid);
                $this->content->text = $renderer->render($adminview);
                $PAGE->requires->js_call_amd('block_studentperformancepredictor/admin_interface', 'init', [$courseid]);
                $PAGE->requires->js_call_amd('block_studentperformancepredictor/chart_renderer', 'initAdminChart');
            } else if (has_capability('block/studentperformancepredictor:viewallpredictions', $context)) {
                // Teacher view
                $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
                $teacherview = new \block_studentperformancepredictor\output\teacher_view($courseid);
                $this->content->text = $renderer->render($teacherview);
                $PAGE->requires->js_call_amd('block_studentperformancepredictor/chart_renderer', 'initTeacherChart');
                $PAGE->requires->js_call_amd('block_studentperformancepredictor/prediction_viewer', 'init');
            } else {
                // Student view
                $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
                $studentview = new \block_studentperformancepredictor\output\student_view($courseid, $USER->id);
                $this->content->text = $renderer->render($studentview);
                $PAGE->requires->js_call_amd('block_studentperformancepredictor/chart_renderer', 'init');
                $PAGE->requires->js_call_amd('block_studentperformancepredictor/prediction_viewer', 'init');
            }
        } catch (Exception $e) {
            // Graceful error handling - don't break the page if there's an error
            debugging('Error rendering Student Performance Predictor block: ' . $e->getMessage(), DEBUG_DEVELOPER);
            $this->content->text = $OUTPUT->notification(
                get_string('errorrendingblock', 'block_studentperformancepredictor'),
                'error'
            );
        }

        return $this->content;
    }

    /**
     * Find an appropriate course to show predictions for.
     *
     * @return int|bool Course ID or false if no appropriate course found
     */
    protected function get_appropriate_course() {
        global $USER, $COURSE, $DB;

        // If we are in a specific course, use that
        if (!empty($COURSE->id) && $COURSE->id != SITEID) {
            return $COURSE->id;
        }

        // Get the user's enrolled courses with active models
        try {
            $sql = "SELECT c.id, c.fullname
                    FROM {course} c
                    JOIN {block_spp_models} m ON c.id = m.courseid
                    JOIN {enrol} e ON e.courseid = c.id
                    JOIN {user_enrolments} ue ON ue.enrolid = e.id
                    WHERE ue.userid = ? AND m.active = ?";
            $params = [$USER->id, 1];

            $courses = $DB->get_records_sql($sql, $params, 0, 1);

            if (!empty($courses)) {
                $course = reset($courses);
                return $course->id;
            }

            // Fallback: get any enrolled course
            $courses = enrol_get_my_courses('id, fullname', 'fullname ASC', 1);
            if (!empty($courses)) {
                $course = reset($courses);
                return $course->id;
            }
        } catch (Exception $e) {
            debugging('Error finding appropriate course: ' . $e->getMessage(), DEBUG_DEVELOPER);
        }

        return false;
    }

    /**
     * Defines where the block can be added.
     *
     * @return array
     */
    public function applicable_formats() {
        return [
            'all' => false,
            'site' => false,
            'site-index' => true,
            'course-view' => true,
            'my' => true,
            'mod' => false,
            'mod-quiz' => false
        ];
    }

    /**
     * Allow multiple instances of the block.
     *
     * @return bool
     */
    public function instance_allow_multiple() {
        return false;
    }

    /**
     * Called when the block is being created for the first time.
     */
    public function specialization() {
        if (isset($this->config->title)) {
            $this->title = $this->config->title;
        } else {
            $this->title = get_string('pluginname', 'block_studentperformancepredictor');
        }
    }
}