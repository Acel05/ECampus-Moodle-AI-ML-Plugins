<?php
// blocks/studentperformancepredictor/admin/train_model.php

require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/moodlelib.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

use block_studentperformancepredictor\analytics\training_manager;

// Get and validate parameters
$courseid = required_param('courseid', PARAM_INT);
$datasetid = required_param('datasetid', PARAM_INT);
$algorithm = optional_param('algorithm', null, PARAM_ALPHANUMEXT);

// Define the redirect URL
$redirecturl = new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]);

// Security checks first
require_login();
require_sesskey();

// Set up context for permission checks
if ($courseid > 0) {
    $coursecontext = context_course::instance($courseid);
    require_capability('block/studentperformancepredictor:managemodels', $coursecontext);
} else {
    // This case is for global models, but we keep the permission check for robustness.
    require_capability('moodle/site:config', context_system::instance());
}

try {
    // Verify dataset exists (it can be from any course)
    if (!$DB->record_exists('block_spp_datasets', ['id' => $datasetid])) {
        throw new \moodle_exception('dataset_not_found', 'block_studentperformancepredictor');
    }

    // Check for pending training to avoid duplicate tasks
    if (training_manager::has_pending_training($courseid)) {
        throw new \moodle_exception('training_already_scheduled', 'block_studentperformancepredictor');
    }

    // Schedule the training task
    $success = training_manager::schedule_training($courseid, $datasetid, $algorithm);

    if (!$success) {
        throw new \moodle_exception('trainingschedulefailed', 'block_studentperformancepredictor');
    }

    // Success notification can be helpful, but it's optional. The main goal is the redirect.
    \core\notification::success(get_string('model_training_queued_backend', 'block_studentperformancepredictor'));

} catch (\Exception $e) {
    // If there's an error, add it as a notification and then redirect.
    \core\notification::error($e->getMessage());
}

// Redirect back to the manage models page in all cases (success or failure).
redirect($redirecturl);