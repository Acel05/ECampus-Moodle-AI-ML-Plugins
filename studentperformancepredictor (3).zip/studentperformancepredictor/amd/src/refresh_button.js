// blocks/studentperformancepredictor/amd/src/refresh_button.js

define(['jquery', 'core/ajax', 'core/notification', 'core/modal_factory', 'core/modal_events', 'core/str'],
function($, Ajax, Notification, ModalFactory, ModalEvents, Str) {
    var init = function() {
        $(document).on('click', '.spp-refresh-predictions', function(e) {
            e.preventDefault();
            var button = $(this);
            var courseId = button.data('course-id');

            if (!courseId) {
                Notification.addNotification({ message: 'Course ID not found.', type: 'error' });
                return;
            }

            var originalButtonText = button.text();
            button.prop('disabled', true).text('Processing...');

            Str.get_strings([
                {key: 'refreshconfirmation', component: 'block_studentperformancepredictor'},
                {key: 'refresh', component: 'block_studentperformancepredictor'},
                {key: 'cancel', component: 'core'}
            ]).done(function(strings) {
                ModalFactory.create({
                    type: ModalFactory.types.SAVE_CANCEL,
                    title: strings[0],
                    body: strings[0]
                }).done(function(modal) {
                    modal.setSaveButtonText(strings[1]);
                    modal.getRoot().on(ModalEvents.save, function() {
                        Ajax.call([{
                            methodname: 'block_studentperformancepredictor_refresh_predictions',
                            args: { courseid: courseId },
                            done: function(response) {
                                if (response.status) {
                                    Notification.addNotification({ message: response.message, type: 'success' });
                                    // Reload the page after a short delay to see updates
                                    setTimeout(function() {
                                        window.location.reload();
                                    }, 1500);
                                } else {
                                    Notification.addNotification({ message: response.message, type: 'error' });
                                    button.prop('disabled', false).text(originalButtonText);
                                }
                            },
                            fail: function(ex) {
                                Notification.exception(ex);
                                button.prop('disabled', false).text(originalButtonText);
                            }
                        }]);
                    });
                    modal.getRoot().on(ModalEvents.cancel, function() {
                        button.prop('disabled', false).text(originalButtonText);
                    });
                    modal.show();
                });
            }).fail(function(ex) {
                Notification.exception(ex);
                button.prop('disabled', false).text(originalButtonText);
            });
        });
    };

    return {
        init: init
    };
});