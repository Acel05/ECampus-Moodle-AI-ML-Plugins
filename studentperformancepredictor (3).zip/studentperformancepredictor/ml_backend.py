"""
FastAPI backend for Moodle Student Performance Predictor

This backend provides ML model training and prediction services for the 
Moodle Student Performance Predictor plugin.

Usage:
    $ pip install fastapi uvicorn scikit-learn joblib pandas python-dotenv
    $ uvicorn ml_backend:app --host 0.0.0.0 --port 5000
"""
from fastapi import FastAPI, Request, HTTPException, Header, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import logging
import os
import sys
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
import joblib
from dotenv import load_dotenv
from uuid import uuid4
from fastapi.middleware.cors import CORSMiddleware
import traceback
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("ml_backend.log")
    ]
)
logger = logging.getLogger("ml_backend")

# Create FastAPI app
app = FastAPI(
    title="Student Performance Predictor API",
    description="ML backend for Moodle Student Performance Predictor plugin",
    version="1.0.0"
)

# Add exception handler for unhandled errors
@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled error: {str(exc)}")
    logger.error(traceback.format_exc())
    return JSONResponse(
        status_code=500,
        content={"detail": f"Internal server error: {str(exc)}"}
    )

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load environment variables
load_dotenv()
API_KEY = os.getenv("API_KEY", "changeme")

# Set up directories
SCRIPT_DIR = os.path.abspath(os.path.dirname(__file__))
MODEL_DIR = os.path.join(SCRIPT_DIR, "models")
DATASET_DIR = os.path.join(SCRIPT_DIR, "datasets")

# Ensure required folders exist
for directory in [MODEL_DIR, DATASET_DIR]:
    os.makedirs(directory, exist_ok=True)

# Define request models
class TrainRequest(BaseModel):
    courseid: int
    # Changed from datasetid to dataset_filepath to directly use the path provided by Moodle
    dataset_filepath: str
    algorithm: Optional[str] = None
    userid: int

class PredictRequest(BaseModel):
    model_id: str
    features: List[Any]

# Define API endpoints
@app.post("/train")
async def train_model(req: TrainRequest, x_api_key: str = Header(...)):
    """
    Train a new machine learning model

    This endpoint trains a model using the specified dataset and algorithm.

    Args:
        req: Training request with course ID, dataset filepath, algorithm, and user ID
        x_api_key: API key for authentication

    Returns:
        JSON response with model details and metrics
    """
    # Validate API key
    if x_api_key != API_KEY:
        raise HTTPException(status_code=403, detail="Forbidden: Invalid API key")

    logger.info(f"Received training request: courseid={req.courseid}, dataset_filepath={req.dataset_filepath}, algorithm={req.algorithm}")

    try:
        # Use the provided dataset_filepath directly
        dataset_path = req.dataset_filepath
        if not os.path.exists(dataset_path):
            # If the provided path doesn't exist, fall back to sample data
            sample_path = os.path.join(DATASET_DIR, "sample_training_data.csv")
            if os.path.exists(sample_path):
                dataset_path = sample_path
                logger.warning(f"Provided dataset_filepath not found at {req.dataset_filepath}, using sample dataset: {sample_path}")
            else:
                # Create a simple sample dataset if none exists and no valid path provided
                sample_data = pd.DataFrame({
                    'activity_level': np.random.randint(0, 100, 100),
                    'submission_count': np.random.randint(0, 20, 100),
                    'grade_average': np.random.random(100),
                    'grade_count': np.random.randint(0, 10, 100),
                    'passed': np.random.randint(0, 2, 100)
                })
                sample_path = os.path.join(DATASET_DIR, "sample_training_data.csv")
                sample_data.to_csv(sample_path, index=False)
                dataset_path = sample_path
                logger.warning(f"Created sample dataset: {sample_path} as no other dataset path was valid.")

        # Load and preprocess dataset
        logger.info(f"Loading dataset from {dataset_path}")
        try:
            df = pd.read_csv(dataset_path)
        except Exception as e:
            logger.error(f"Error reading dataset: {str(e)}")
            raise HTTPException(
                status_code=400, 
                detail=f"Error reading dataset: {str(e)}. Please check file format."
            )

        # Ensure dataset is not empty
        if df.empty:
            raise HTTPException(status_code=400, detail="Dataset is empty")

        # Assume last column is the target
        X = df.iloc[:, :-1]
        y = df.iloc[:, -1]

        # Split data for training and testing
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Select algorithm
        algo = (req.algorithm or 'randomforest').lower()
        logger.info(f"Using algorithm: {algo}")

        if algo == 'randomforest':
            clf = RandomForestClassifier(n_estimators=100, random_state=42)
        elif algo == 'logisticregression':
            clf = LogisticRegression(max_iter=1000, random_state=42)
        elif algo == 'svm':
            clf = SVC(probability=True, random_state=42)
        elif algo == 'decisiontree':
            clf = DecisionTreeClassifier(random_state=42)
        elif algo == 'knn':
            clf = KNeighborsClassifier(n_neighbors=5)
        else:
            raise HTTPException(status_code=400, detail=f"Unknown algorithm: {algo}")

        # Train the model
        logger.info("Training model...")
        clf.fit(X_train, y_train)

        # Evaluate model
        y_pred = clf.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)

        # Calculate additional metrics if possible
        metrics = {
            "accuracy": float(accuracy)
        }

        try:
            metrics["precision"] = float(precision_score(y_test, y_pred))
            metrics["recall"] = float(recall_score(y_test, y_pred))
            metrics["f1"] = float(f1_score(y_test, y_pred))
        except Exception as e:
            logger.warning(f"Could not calculate all metrics: {str(e)}")

        # Generate unique model ID and save model
        model_id = str(uuid4())
        model_filename = f"model_{model_id}.joblib"
        model_path = os.path.join(MODEL_DIR, model_filename)

        logger.info(f"Saving model to {model_path}")
        try:
            joblib.dump(clf, model_path)
        except Exception as e:
            logger.error(f"Error saving model: {str(e)}")
            raise HTTPException(
                status_code=500, 
                detail=f"Error saving model: {str(e)}"
            )

        # Save feature names for future reference
        feature_names = X.columns.tolist()
        metadata = {
            "feature_names": feature_names,
            "metrics": metrics,
            "algorithm": algo,
            "courseid": req.courseid,
            "created_by": req.userid
        }

        metadata_path = os.path.join(MODEL_DIR, f"model_{model_id}_metadata.json")
        try:
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f)
        except Exception as e:
            logger.error(f"Error saving metadata: {str(e)}")
            # Continue even if metadata save fails

        logger.info(f"Model trained successfully. Accuracy: {accuracy:.3f}")

        # Return model information
        return {
            "status": "success",
            "message": f"Model trained successfully. Accuracy: {accuracy:.3f}",
            "model_id": model_id,
            "model_path": model_filename,  # Return just filename, not full path for security
            "metrics": metrics,
            "algorithm": algo,
            "feature_names": feature_names
        }

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"Training failed: {str(e)}")
        logger.error(traceback.format_exc())
        # More detailed error response
        error_detail = {
            "error": str(e),
            "courseid": req.courseid,
            "algorithm": req.algorithm
        }
        raise HTTPException(status_code=500, detail=error_detail)

@app.post("/predict")
async def predict(req: PredictRequest, x_api_key: str = Header(...)):
    """
    Make predictions using a trained model

    This endpoint uses a previously trained model to make predictions.

    Args:
        req: Prediction request with model ID and feature values
        x_api_key: API key for authentication

    Returns:
        JSON response with prediction results
    """
    # Validate API key
    if x_api_key != API_KEY:
        raise HTTPException(status_code=403, detail="Forbidden: Invalid API key")

    logger.info(f"Received prediction request for model {req.model_id}")

    try:
        # Load model
        model_path = os.path.join(MODEL_DIR, f"model_{req.model_id}.joblib")
        if not os.path.exists(model_path):
            raise HTTPException(status_code=404, detail="Model not found")

        logger.info(f"Loading model from {model_path}")
        try:
            clf = joblib.load(model_path)
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            raise HTTPException(
                status_code=500, 
                detail=f"Error loading model: {str(e)}"
            )

        # Try to load metadata for feature names
        feature_names = None
        try:
            metadata_path = os.path.join(MODEL_DIR, f"model_{req.model_id}_metadata.json")
            if os.path.exists(metadata_path):
                with open(metadata_path, 'r') as f:
                    metadata = json.load(f)
                    feature_names = metadata.get('feature_names')
        except Exception as e:
            logger.warning(f"Could not load model metadata: {str(e)}")

        # Reshape features for prediction (single sample)
        X_input = [req.features]

        # Make prediction
        logger.info(f"Making prediction with features: {req.features}")
        try:
            prediction = int(clf.predict(X_input)[0])
        except Exception as e:
            logger.error(f"Prediction error: {str(e)}")
            raise HTTPException(
                status_code=500, 
                detail=f"Prediction error: {str(e)}"
            )

        # Get prediction probabilities if available
        probabilities = None
        if hasattr(clf, "predict_proba"):
            try:
                probabilities = clf.predict_proba(X_input)[0].tolist()
            except Exception as e:
                logger.warning(f"Could not get probabilities: {str(e)}")

        # Return prediction results
        result = {
            "status": "success",
            "prediction": prediction,
            "probabilities": probabilities
        }

        # Include feature names if available
        if feature_names and len(feature_names) == len(req.features):
            feature_dict = dict(zip(feature_names, req.features))
            result["features"] = feature_dict

        logger.info(f"Prediction result: {prediction}, probabilities: {probabilities}")
        return result

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"Prediction failed: {str(e)}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")

@app.get("/")
def root():
    """
    Root endpoint to check if the service is running
    """
    return {
        "status": "ok",
        "message": "Student Performance Predictor ML backend is running.",
        "version": "1.0.0"
    }

@app.get("/health")
def health_check():
    """
    Health check endpoint
    """
    return {
        "status": "healthy",
        "message": "Backend service is operational"
    }

# Run the application if executed directly
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 5000))
    host = os.environ.get("HOST", "0.0.0.0")

    print(f"Starting ML backend server at http://{host}:{port}")
    print(f"Press Ctrl+C to quit")

    uvicorn.run(app, host=host, port=port)