<?php
// blocks/studentperformancepredictor/version.php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2025063011;        // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2022112800;        // Requires Moodle 4.1 or later.
$plugin->component = 'block_studentperformancepredictor'; // Full name of the plugin.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.1.1';           // Updated for settings fix
$plugin->has_config = true;             // IMPORTANT: This tells Moodle this plugin has settings