<?php
// blocks/studentperformancepredictor/reports.php

require_once('../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters
$courseid = optional_param('courseid', 0, PARAM_INT);

// Set up page context
$PAGE->set_context(context_system::instance());
require_login();

$courses_to_display = [];

if (is_siteadmin()) {
    // Admins can see all courses
    $allcourses = get_courses();
    foreach ($allcourses as $course) {
        if ($course->id != SITEID) {
            $courses_to_display[$course->id] = $course;
        }
    }
} else {
    // Teachers only see courses they are enrolled in
    $mycourses = enrol_get_my_courses(null, 'fullname ASC');
    foreach ($mycourses as $course) {
        if ($course->id == SITEID) {
            continue;
        }
        $coursecontext = context_course::instance($course->id);
        if (has_capability('block/studentperformancepredictor:viewallpredictions', $coursecontext)) {
            $courses_to_display[$course->id] = $course;
        }
    }
}


if (empty($courses_to_display)) {
    throw new moodle_exception('nocoursesfound', 'block_studentperformancepredictor');
}

// Determine which course to display
if ($courseid == 0 || !isset($courses_to_display[$courseid])) {
    // If no course is selected or the selected course is invalid, default to the first one
    $firstcourse = reset($courses_to_display);
    $courseid = $firstcourse->id;
}

$course = get_course($courseid);
$context = context_course::instance($courseid);

// Set up page layout
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/reports.php', array('courseid' => $courseid)));
$PAGE->set_title(get_string('detailedreport', 'block_studentperformancepredictor'));
$PAGE->set_heading(get_string('detailedreport', 'block_studentperformancepredictor'));
$PAGE->set_pagelayout('standard');

// Output starts here
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('detailedreport', 'block_studentperformancepredictor'));

// Show teacher view with course selector
$renderer = $PAGE->get_renderer('block_studentperformancepredictor');
$teacherview = new \block_studentperformancepredictor\output\teacher_view($courseid, $courses_to_display);
echo $renderer->render_teacher_view($teacherview);

// Output footer
echo $OUTPUT->footer();