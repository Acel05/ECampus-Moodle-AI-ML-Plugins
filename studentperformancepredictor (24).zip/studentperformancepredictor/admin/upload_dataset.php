<?php
// blocks/studentperformancepredictor/admin/upload_dataset.php

require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');
require_once($CFG->libdir . '/moodlelib.php');
require_once($CFG->libdir . '/accesslib.php');
require_once($CFG->libdir . '/filelib.php');

// Get parameters
$courseid = required_param('courseid', PARAM_INT);
$datasetname = required_param('dataset_name', PARAM_TEXT);
$datasetformat = required_param('dataset_format', PARAM_ALPHA);
$datasetdesc = optional_param('dataset_description', '', PARAM_TEXT);

// Set up redirect URL
$redirecturl = new moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', ['courseid' => $courseid]);

// Validate session key
require_sesskey();

// Set up context
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Verify file upload
if (!isset($_FILES['dataset_file']) || empty($_FILES['dataset_file']['name'])) {
    \core\notification::error(get_string('nofileuploaded', 'block_studentperformancepredictor'));
    redirect($redirecturl);
}

$file = $_FILES['dataset_file'];

// Check for upload errors
if ($file['error'] !== UPLOAD_ERR_OK) {
    $errormessage = get_string('fileuploaderror', 'block_studentperformancepredictor');
    switch ($file['error']) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            $errormessage = get_string('filetoolarge', 'block_studentperformancepredictor');
            break;
        case UPLOAD_ERR_PARTIAL:
            $errormessage = get_string('filepartialuploaded', 'block_studentperformancepredictor');
            break;
        case UPLOAD_ERR_NO_FILE:
            $errormessage = get_string('nofileuploaded', 'block_studentperformancepredictor');
            break;
    }
    \core\notification::error($errormessage);
    redirect($redirecturl);
}

// Check file extension
$filename = $file['name'];
$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

if (($datasetformat === 'csv' && $extension !== 'csv') || ($datasetformat === 'json' && $extension !== 'json')) {
    \core\notification::error(get_string('invalidfileextension', 'block_studentperformancepredictor'));
    redirect($redirecturl);
}

// Create dataset directory
try {
    $datasetdir = block_studentperformancepredictor_ensure_dataset_directory($courseid);
} catch (Exception $e) {
    \core\notification::error($e->getMessage());
    redirect($redirecturl);
}

// Store the file with a unique name
$newfilename = $courseid . '_' . time() . '_' . clean_filename($filename);
$filepath = $datasetdir . '/' . $newfilename;

if (!move_uploaded_file($file['tmp_name'], $filepath)) {
    \core\notification::error(get_string('fileuploadfailed', 'block_studentperformancepredictor'));
    redirect($redirecturl);
}

// Extract column headers
$columns = array();
if ($datasetformat === 'csv') {
    $handle = fopen($filepath, 'r');
    if ($handle !== false) {
        $headers = fgetcsv($handle);
        if ($headers) {
            foreach ($headers as $header) {
                $columns[] = $header;
            }
        }
        fclose($handle);
    }
} else if ($datasetformat === 'json') {
    $content = file_get_contents($filepath);
    $jsonData = json_decode($content, true);
    if (is_array($jsonData) && !empty($jsonData)) {
        $firstRow = reset($jsonData);
        if (is_array($firstRow)) {
            $columns = array_keys($firstRow);
        }
    }
}

// Save dataset record to database
$dataset = new stdClass();
$dataset->courseid = $courseid;
$dataset->name = $datasetname;
$dataset->description = $datasetdesc;
$dataset->filepath = $filepath;
$dataset->fileformat = $datasetformat;
$dataset->columns = json_encode($columns);
$dataset->timecreated = time();
$dataset->timemodified = time();
$dataset->usermodified = $USER->id;

try {
    $datasetid = $DB->insert_record('block_spp_datasets', $dataset);
    \core\notification::success(get_string('datasetsaved_backend', 'block_studentperformancepredictor'));
} catch (Exception $e) {
    \core\notification::error(get_string('datasetsaveerror', 'block_studentperformancepredictor') . ': ' . $e->getMessage());
}

// Redirect back to the manage datasets page
redirect($redirecturl);