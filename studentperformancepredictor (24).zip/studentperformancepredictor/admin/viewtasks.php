<?php
// blocks/studentperformancepredictor/admin/viewtasks.php

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/tablelib.php'); // For html_table
require_once($CFG->dirroot . '/lib/accesslib.php'); // For require_login, require_capability
require_once($CFG->dirroot . '/lib/moodlelib.php'); // For userdate, s
require_once($CFG->libdir . '/weblib.php'); // For html_writer, s, get_string

require_login();
$courseid = optional_param('courseid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$modelid = optional_param('modelid', 0, PARAM_INT);
$confirm = optional_param('confirm', 0, PARAM_BOOL);

// Default to system context if no course specified
if ($courseid) {
    $context = context_course::instance($courseid);
    $course = get_course($courseid);
    $PAGE->set_course($course);
    $pageheading = format_string($course->fullname);
} else {
    $context = context_system::instance();
    $pageheading = get_string('viewtasks', 'block_studentperformancepredictor');
}

require_capability('block/studentperformancepredictor:managemodels', $context);

// Set up page
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/viewtasks.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('viewtasks', 'block_studentperformancepredictor'));
$PAGE->set_heading($pageheading);
$PAGE->set_pagelayout('admin');

// Process model deletion action
if ($action === 'delete' && $modelid) {
    require_sesskey();

    // Check if the model exists
    $model = $DB->get_record('block_spp_models', ['id' => $modelid], '*', MUST_EXIST);

    // Verify the model belongs to this course if courseid is specified
    if ($courseid > 0 && $model->courseid != $courseid) {
        throw new moodle_exception('invalidaccess', 'error');
    }

    // Handle confirmation
    if ($confirm) {
        // Delete related records
        $DB->delete_records('block_spp_predictions', ['modelid' => $modelid]);

        // Get any suggestions related to predictions from this model
        $sql = "DELETE FROM {block_spp_suggestions} 
                WHERE predictionid IN (
                    SELECT id FROM {block_spp_predictions} WHERE modelid = :modelid
                )";
        $DB->execute($sql, ['modelid' => $modelid]);

        // Delete training logs
        $DB->delete_records('block_spp_training_log', ['modelid' => $modelid]);

        // If there's a model file, delete it
        if (!empty($model->modelpath) && file_exists($model->modelpath)) {
            unlink($model->modelpath);
        }

        // Delete the model record
        $DB->delete_records('block_spp_models', ['id' => $modelid]);

        // Show success message
        \core\notification::success(get_string('modeldeleted', 'block_studentperformancepredictor'));

        // Redirect back to the task monitor
        redirect($PAGE->url);
    } else {
        // Show confirmation dialog
        echo $OUTPUT->header();
        echo $OUTPUT->heading(get_string('deletemodel', 'block_studentperformancepredictor'));

        echo $OUTPUT->confirm(
            get_string('confirmmodeldelete', 'block_studentperformancepredictor', $model->modelname),
            new moodle_url($PAGE->url, [
                'action' => 'delete', 
                'modelid' => $modelid, 
                'confirm' => 1,
                'sesskey' => sesskey()
            ]),
            $PAGE->url
        );

        echo $OUTPUT->footer();
        exit;
    }
}

// Process purge failed models action
if ($action === 'purgefailed' && $courseid) {
    require_sesskey();

    if ($confirm) {
        // Find failed models
        $params = ['courseid' => $courseid, 'status' => 'failed'];
        $failedmodels = $DB->get_records('block_spp_models', ['courseid' => $courseid, 'trainstatus' => 'failed']);

        $count = 0;
        foreach ($failedmodels as $model) {
            // Delete related records
            $DB->delete_records('block_spp_predictions', ['modelid' => $model->id]);

            // Delete training logs
            $DB->delete_records('block_spp_training_log', ['modelid' => $model->id]);

            // If there's a model file, delete it
            if (!empty($model->modelpath) && file_exists($model->modelpath)) {
                unlink($model->modelpath);
            }

            // Delete the model record
            $DB->delete_records('block_spp_models', ['id' => $model->id]);
            $count++;
        }

        // Show success message
        if ($count > 0) {
            \core\notification::success(get_string('failedmodelsdeleted', 'block_studentperformancepredictor'));
        } else {
            \core\notification::info(get_string('nofailedmodels', 'block_studentperformancepredictor'));
        }

        // Redirect back to the task monitor
        redirect($PAGE->url);
    } else {
        // Show confirmation dialog
        echo $OUTPUT->header();
        echo $OUTPUT->heading(get_string('purgefailedmodels', 'block_studentperformancepredictor'));

        echo $OUTPUT->confirm(
            get_string('confirmpurgefailed', 'block_studentperformancepredictor'),
            new moodle_url($PAGE->url, [
                'action' => 'purgefailed', 
                'courseid' => $courseid, 
                'confirm' => 1,
                'sesskey' => sesskey()
            ]),
            $PAGE->url
        );

        echo $OUTPUT->footer();
        exit;
    }
}

// Get all train_model tasks (adhoc and scheduled)
global $DB;

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('viewtasks', 'block_studentperformancepredictor'));

// First, let's display models currently in training
echo $OUTPUT->heading(get_string('modelscurrentlyintraining', 'block_studentperformancepredictor'), 3);

// Get training models
$sql = "SELECT m.*, d.name as datasetname 
        FROM {block_spp_models} m
        LEFT JOIN {block_spp_datasets} d ON m.datasetid = d.id
        WHERE m.trainstatus IN ('pending', 'training')";

if ($courseid > 0) {
    $sql .= " AND m.courseid = :courseid";
    $params = ['courseid' => $courseid];
} else {
    $params = [];
}

$sql .= " ORDER BY m.timecreated DESC";
$trainingmodels = $DB->get_records_sql($sql, $params);

if (empty($trainingmodels)) {
    echo $OUTPUT->notification(get_string('notrainingmodels', 'block_studentperformancepredictor'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        '#',
        get_string('modelname', 'block_studentperformancepredictor'),
        get_string('datasetname', 'block_studentperformancepredictor'),
        get_string('algorithm', 'block_studentperformancepredictor'),
        get_string('status', 'block_studentperformancepredictor'),
        get_string('timecreated', 'block_studentperformancepredictor'),
        get_string('timemodified', 'block_studentperformancepredictor'),
        get_string('actions', 'block_studentperformancepredictor')
    ];
    $table->data = [];

    // Algorithm options for display
    $algorithms = [
        'randomforest' => get_string('algorithm_randomforest', 'block_studentperformancepredictor'),
        'extratrees' => get_string('algorithm_extratrees', 'block_studentperformancepredictor'),
        'adaboost' => get_string('algorithm_adaboost', 'block_studentperformancepredictor'),
        'xgboost' => get_string('algorithm_xgboost', 'block_studentperformancepredictor'),
        'catboost' => get_string('algorithm_catboost', 'block_studentperformancepredictor'),
        'lightgbm' => get_string('algorithm_lightgbm', 'block_studentperformancepredictor')
    ];

    foreach ($trainingmodels as $model) {
        $row = [];
        $row[] = $model->id;
        $row[] = format_string($model->modelname);
        $row[] = format_string($model->datasetname);
        $row[] = isset($algorithmoptions[$model->algorithmtype]) ? 
               $algorithmoptions[$model->algorithmtype] : $model->algorithmtype;

        // Status with appropriate label
        if ($model->trainstatus === 'pending') {
            $statustext = get_string('pendingstatus', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-info';
        } else {
            $statustext = get_string('trainingstatus', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-warning';
        }
        $row[] = html_writer::tag('span', $statustext, ['class' => $statusclass]);

        $row[] = userdate($model->timecreated);
        $row[] = userdate($model->timemodified);

        // Add delete action
        $deleteurl = new moodle_url($PAGE->url, [
            'action' => 'delete',
            'modelid' => $model->id,
            'sesskey' => sesskey()
        ]);

        $actions = html_writer::link(
            $deleteurl, 
            html_writer::tag('i', '', ['class' => 'fa fa-trash']), 
            ['class' => 'btn btn-sm btn-danger', 'title' => get_string('delete')]
        );

        $row[] = $actions;

        $table->data[] = $row;
    }

    echo html_writer::table($table);
}

// Display all models (including completed and failed ones)
echo $OUTPUT->heading(get_string('allmodels', 'block_studentperformancepredictor'), 3);

$sql = "SELECT m.*, d.name as datasetname 
        FROM {block_spp_models} m
        LEFT JOIN {block_spp_datasets} d ON m.datasetid = d.id
        WHERE 1=1";

if ($courseid > 0) {
    $sql .= " AND m.courseid = :courseid";
    $params = ['courseid' => $courseid];
} else {
    $params = [];
}

$sql .= " ORDER BY m.timecreated DESC";
$allmodels = $DB->get_records_sql($sql, $params);

if (empty($allmodels)) {
    echo $OUTPUT->notification(get_string('nomodels', 'block_studentperformancepredictor'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        '#',
        get_string('modelname', 'block_studentperformancepredictor'),
        get_string('datasetname', 'block_studentperformancepredictor'),
        get_string('algorithm', 'block_studentperformancepredictor'),
        get_string('status', 'block_studentperformancepredictor'),
        get_string('accuracy', 'block_studentperformancepredictor'),
        get_string('active', 'block_studentperformancepredictor'),
        get_string('timecreated', 'block_studentperformancepredictor'),
        get_string('actions', 'block_studentperformancepredictor')
    ];
    $table->data = [];

    foreach ($allmodels as $model) {
        $row = [];
        $row[] = $model->id;
        $row[] = format_string($model->modelname);
        $row[] = format_string($model->datasetname);
        $row[] = isset($algorithmoptions[$model->algorithmtype]) ? 
               $algorithmoptions[$model->algorithmtype] : $model->algorithmtype;

        // Status with appropriate label
        if ($model->trainstatus === 'pending') {
            $statustext = get_string('pendingstatus', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-info';
        } else if ($model->trainstatus === 'training') {
            $statustext = get_string('trainingstatus', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-warning';
        } else if ($model->trainstatus === 'complete') {
            $statustext = get_string('complete', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-success';
        } else {
            $statustext = get_string('failed', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-danger';
        }
        $row[] = html_writer::tag('span', $statustext, ['class' => $statusclass]);

        // Accuracy
        $row[] = isset($model->accuracy) ? round($model->accuracy * 100, 2) . '%' : '-';

        // Active status
        $row[] = $model->active ? 
            html_writer::tag('span', get_string('yes'), ['class' => 'badge badge-success']) : 
            html_writer::tag('span', get_string('no'), ['class' => 'badge badge-secondary']);

        $row[] = userdate($model->timecreated);

        // Add delete action
        $deleteurl = new moodle_url($PAGE->url, [
            'action' => 'delete',
            'modelid' => $model->id,
            'sesskey' => sesskey()
        ]);

        $actions = html_writer::link(
            $deleteurl, 
            html_writer::tag('i', '', ['class' => 'fa fa-trash']), 
            ['class' => 'btn btn-sm btn-danger', 'title' => get_string('delete')]
        );

        $row[] = $actions;

        $table->data[] = $row;
    }

    echo html_writer::table($table);
}

// Now show the training logs
echo $OUTPUT->heading(get_string('traininglogs', 'block_studentperformancepredictor'), 3);

// Get training logs from block_spp_training_log
$sql = "SELECT l.* 
        FROM {block_spp_training_log} l
        JOIN {block_spp_models} m ON l.modelid = m.id
        WHERE 1=1";

if ($courseid > 0) {
    $sql .= " AND m.courseid = :courseid";
    $params = ['courseid' => $courseid];
} else {
    $params = [];
}

$sql .= " ORDER BY l.timecreated DESC";
$logs = $DB->get_records_sql($sql, $params, 0, 50); // Limit to 50 most recent logs

if (empty($logs)) {
    echo $OUTPUT->notification(get_string('notraininglogs', 'block_studentperformancepredictor'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        get_string('modelid', 'block_studentperformancepredictor'),
        get_string('event', 'block_studentperformancepredictor'),
        get_string('logmessage', 'block_studentperformancepredictor'),
        get_string('level', 'block_studentperformancepredictor'),
        get_string('timecreated', 'block_studentperformancepredictor')
    ];
    $table->data = [];

    foreach ($logs as $log) {
        $row = [];
        $row[] = $log->modelid;
        $row[] = $log->event;
        $row[] = $log->message;

        // Level with appropriate styling
        if ($log->level === 'error') {
            $levelclass = 'text-danger';
        } else if ($log->level === 'warning') {
            $levelclass = 'text-warning';
        } else {
            $levelclass = 'text-info';
        }
        $row[] = html_writer::tag('span', $log->level, ['class' => $levelclass]);

        $row[] = userdate($log->timecreated);

        $table->data[] = $row;
    }

    echo html_writer::table($table);
}

// Get all adhoc tasks for this plugin/course
echo $OUTPUT->heading(get_string('scheduledtasks', 'block_studentperformancepredictor'), 3);

// Filter by course if specified
$tasksql = "component = :component";
$taskparams = ['component' => 'block_studentperformancepredictor'];

if ($courseid) {
    $tasksql .= " AND " . $DB->sql_like('customdata', ':courseid');
    $taskparams['courseid'] = '%"courseid":' . $courseid . '%';
}

// Get all adhoc tasks for this plugin/course
$tasks = $DB->get_records_select('task_adhoc', $tasksql, $taskparams, 'id DESC');

if (empty($tasks)) {
    echo $OUTPUT->notification(get_string('notasks', 'block_studentperformancepredictor'), 'info');
} else {
    $table = new html_table();
    $table->head = [
        get_string('taskid', 'block_studentperformancepredictor'),
        get_string('taskname', 'block_studentperformancepredictor'),
        get_string('status', 'block_studentperformancepredictor'),
        get_string('courseid', 'block_studentperformancepredictor'),
        get_string('nextruntime', 'block_studentperformancepredictor'),
        get_string('lastruntime', 'block_studentperformancepredictor'),
        get_string('output', 'block_studentperformancepredictor')
    ];
    $table->data = [];

    foreach ($tasks as $task) {
        $customdata = json_decode($task->customdata);

        // Task information
        $taskname = explode('\\', $task->classname);
        $taskname = end($taskname);

        // Task status
        if ($task->nextruntime && $task->nextruntime > time()) {
            $statustext = get_string('taskqueued', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-info';
        } else if ($task->timestarted && !$task->timecompleted) {
            $statustext = get_string('taskrunning', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-warning';
        } else {
            $statustext = get_string('complete', 'block_studentperformancepredictor');
            $statusclass = 'badge badge-success';
        }

        // Course info
        $thiscourse = isset($customdata->courseid) ? $customdata->courseid : '-';

        // Time values
        $nextrun = $task->nextruntime ? userdate($task->nextruntime) : '-';
        $lastrun = $task->lastruntime ? userdate($task->lastruntime) : '-';

        $output = $task->faildelay ? get_string('failed', 'block_studentperformancepredictor') : ($task->output ?? '-');

        $table->data[] = [
            $task->id,
            $taskname,
            html_writer::span($statustext, $statusclass),
            $thiscourse,
            $nextrun,
            $lastrun,
            $output
        ];
    }

    echo html_writer::table($table);
}

// Add button to purge all failed models
if ($courseid) {
    echo html_writer::start_div('mt-3');

    // Back to models button
    echo html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]),
        get_string('backtomodels', 'block_studentperformancepredictor'),
        ['class' => 'btn btn-secondary mr-2']
    );

    // Purge failed models button
    echo html_writer::link(
        new moodle_url($PAGE->url, [
            'action' => 'purgefailed',
            'courseid' => $courseid,
            'sesskey' => sesskey()
        ]),
        get_string('purgefailedmodels', 'block_studentperformancepredictor'),
        ['class' => 'btn btn-warning']
    );

    echo html_writer::end_div();
} else {
    // For global view, just show return button
    echo html_writer::div(
        html_writer::link(
            new moodle_url('/admin/settings.php', ['section' => 'blocksettingstudentperformancepredictor']),
            get_string('backsettings', 'block_studentperformancepredictor'),
            ['class' => 'btn btn-secondary']
        ),
        'mt-3'
    );
}

echo $OUTPUT->footer();