<?php
// blocks/studentperformancepredictor/admin/refreshpredictions.php

require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters.
$courseid = required_param('courseid', PARAM_INT);

// Set up page.
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions.
require_login($course);
require_capability('block/studentperformancepredictor:viewallpredictions', $context);

// Set up page layout.
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/refreshpredictions.php', array('courseid' => $courseid)));
$PAGE->set_context($context);
$PAGE->set_title(get_string('refreshpredictions', 'block_studentperformancepredictor'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_pagelayout('standard');

// Check if there's an active model.
$hasactivemodel = block_studentperformancepredictor_has_active_model($courseid);

// Output starts here.
echo $OUTPUT->header();

// Print heading.
echo $OUTPUT->heading(get_string('refreshpredictions', 'block_studentperformancepredictor'));

if (!$hasactivemodel) {
    echo $OUTPUT->notification(get_string('noactivemodel', 'block_studentperformancepredictor'), 'warning');
    echo html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', array('courseid' => $courseid)),
        get_string('managemodels', 'block_studentperformancepredictor'),
        array('class' => 'btn btn-primary')
    );
} else {
    // Get statistics on current predictions.
    $stats = block_studentperformancepredictor_get_course_risk_stats($courseid);

    echo html_writer::start_div('spp-prediction-stats mb-4');
    echo html_writer::start_div('card');
    echo html_writer::start_div('card-body');
    echo html_writer::tag('h5', get_string('currentpredictionstats', 'block_studentperformancepredictor'), array('class' => 'card-title'));
    echo html_writer::start_tag('ul', array('class' => 'list-group list-group-flush'));
    echo html_writer::tag('li', get_string('totalstudents', 'block_studentperformancepredictor') . ': ' . $stats->total, array('class' => 'list-group-item'));
    echo html_writer::tag('li', get_string('highrisk_label', 'block_studentperformancepredictor') . ': ' . $stats->highrisk .
        ' (' . round(($stats->highrisk / max(1, $stats->total)) * 100) . '%)', array('class' => 'list-group-item spp-risk-high'));
    echo html_writer::tag('li', get_string('mediumrisk_label', 'block_studentperformancepredictor') . ': ' . $stats->mediumrisk .
        ' (' . round(($stats->mediumrisk / max(1, $stats->total)) * 100) . '%)', array('class' => 'list-group-item spp-risk-medium'));
    echo html_writer::tag('li', get_string('lowrisk_label', 'block_studentperformancepredictor') . ': ' . $stats->lowrisk .
        ' (' . round(($stats->lowrisk / max(1, $stats->total)) * 100) . '%)', array('class' => 'list-group-item spp-risk-low'));
    echo html_writer::end_tag('ul');
    echo html_writer::end_div(); // card-body
    echo html_writer::end_div(); // card
    echo html_writer::end_div(); // spp-prediction-stats

    // Refresh button and explanation.
    echo html_writer::start_div('spp-refresh-container mb-4');
    echo html_writer::tag('p', get_string('refreshexplanation', 'block_studentperformancepredictor'));
    echo html_writer::start_div('spp-refresh-action');
    echo html_writer::div(
        html_writer::tag('button', get_string('refreshallpredictions', 'block_studentperformancepredictor'),
                        array('class' => 'btn btn-primary spp-refresh-predictions',
                              'id' => 'refresh-predictions-btn', // Added ID for easier selection
                              'data-course-id' => $courseid)),
        'spp-refresh-action'
    );
    echo html_writer::end_div();
    echo html_writer::end_div();

    // Show the last refresh time if available
    $lastrefreshtime = get_config('block_studentperformancepredictor', 'lastrefresh_' . $courseid);
    if (!empty($lastrefreshtime)) {
        echo html_writer::start_div('spp-last-refresh mb-4');
        echo html_writer::tag('p', get_string('lastrefreshtime', 'block_studentperformancepredictor', userdate($lastrefreshtime)),
            array('class' => 'text-muted'));
        echo html_writer::end_div();
    }
}

// Navigation buttons
echo '<div class="btn-group mt-3" role="group">';
echo html_writer::link(
    new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]),
    get_string('managemodels', 'block_studentperformancepredictor'),
    ['class' => 'btn btn-secondary']
);
echo html_writer::link(
    new moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', ['courseid' => $courseid]),
    get_string('managedatasets', 'block_studentperformancepredictor'),
    ['class' => 'btn btn-secondary']
);
echo html_writer::link(
    new moodle_url('/my'),
    get_string('backtodashboard', 'block_studentperformancepredictor'),
    ['class' => 'btn btn-secondary']
);
echo '</div>';

// Output footer.
echo $OUTPUT->footer();

// Inline JavaScript to handle the button click
?>
echo '<script>
    document.addEventListener("DOMContentLoaded", function() {
        var refreshButton = document.getElementById("refresh-predictions-btn");
        if (refreshButton) {
            refreshButton.addEventListener("click", function(e) {
                e.preventDefault();

                if (confirm("' . get_string('refreshconfirmation', 'block_studentperformancepredictor') . '")) {
                    var courseId = this.getAttribute("data-course-id");
                    var originalText = this.textContent;
                    this.disabled = true;
                    this.textContent = "' . get_string('refreshing', 'block_studentperformancepredictor') . '...";

                    // Using Moodle\'s built-in fetch for AJAX
                    require(["core/ajax"], function(ajax) {
                        var promises = ajax.call([{
                            methodname: "block_studentperformancepredictor_refresh_predictions",
                            args: { courseid: courseId },
                            done: function(response) {
                                if (response.status) {
                                    alert("' . get_string('predictionsrefreshqueued', 'block_studentperformancepredictor') . '");
                                    // Add cache-busting to the reload
                                    var currentUrl = window.location.href;
                                    var separator = currentUrl.indexOf("?") > -1 ? "&" : "?";
                                    var newUrl = currentUrl.split("#")[0] + separator + "_=" + new Date().getTime();
                                    if (window.location.hash) {
                                        newUrl += window.location.hash;
                                    }
                                    window.location.href = newUrl;
                                } else {
                                    alert("' . get_string('predictionsrefresherror', 'block_studentperformancepredictor') . ': " + response.message);
                                    refreshButton.disabled = false;
                                    refreshButton.textContent = originalText;
                                }
                            },
                            fail: function(ex) {
                                alert("' . get_string('refresherror', 'block_studentperformancepredictor') . ': " + ex);
                                refreshButton.disabled = false;
                                refreshButton.textContent = originalText;
                            }
                        }]);
                    });
                }
            });
        }
    });
</script>';