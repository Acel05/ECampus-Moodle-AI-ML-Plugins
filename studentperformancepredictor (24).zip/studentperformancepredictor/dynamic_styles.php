<?php
// blocks/studentperformancepredictor/dynamic_styles.php

// This file generates dynamic CSS with cache prevention

// Set the content type
header('Content-Type: text/css');

// Prevent caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');

// Include the base CSS
readfile(__DIR__ . '/styles.css');

// Add a dynamic element (timestamp comment) to ensure it's always different
echo "\n/* Dynamic styles generated at " . time() . " */\n";