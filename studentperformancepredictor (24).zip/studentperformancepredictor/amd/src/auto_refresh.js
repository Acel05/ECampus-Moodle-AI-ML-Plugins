// blocks/studentperformancepredictor/amd/src/auto_refresh.js

define(['jquery'], function($) {
    /**
     * Initialize the auto-refresh feature for prediction data
     * @param {int} interval Refresh interval in seconds
     */
    var init = function(interval) {
        // Default to 30 seconds if not specified
        interval = interval || 30;

        // Check if we're on a page with prediction data
        if ($('.block_studentperformancepredictor').length) {
            // Set up periodic refresh
            setInterval(function() {
                // If there's a prediction displayed, refresh the page
                if ($('.spp-prediction').length) {
                    // Add a timestamp parameter to avoid caching
                    var currentUrl = window.location.href;
                    var separator = currentUrl.indexOf('?') > -1 ? '&' : '?';
                    var newUrl = currentUrl.split('#')[0] + separator + '_=' + new Date().getTime();
                    if (window.location.hash) {
                        newUrl += window.location.hash;
                    }
                    window.location.href = newUrl;
                }
            }, interval * 1000);
        }
    };

    return {
        init: init
    };
});