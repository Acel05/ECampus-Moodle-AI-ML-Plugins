// blocks/studentperformancepredictor/amd/src/admin_interface.js

define(['jquery', 'core/ajax', 'core/str', 'core/notification', 'core/modal_factory', 'core/modal_events'],
function($, Ajax, Str, Notification, ModalFactory, ModalEvents) {

    /**
     * Initialize admin interface.
     * * @param {int} courseId Course ID
     */
    var init = function(courseId) {
        try {
            // Handle model training form submission state
            $('#spp-train-model-form').on('submit', function() {
                var form = $(this);
                var submitButton = form.find('input[type="submit"]');

                // Disable the button and show a "training" message to prevent multiple submissions.
                // The form will then submit normally, and the browser will be redirected by the PHP script.
                var originalText = submitButton.val();
                submitButton.prop('disabled', true);
                Str.get_string('training', 'block_studentperformancepredictor').done(function(trainingStr) {
                    submitButton.val(trainingStr + '...');
                });
            });

            // Handle dataset deletion
            $('.spp-delete-dataset').on('click', function(e) {
                e.preventDefault();

                var button = $(this);
                var datasetId = button.data('dataset-id');
                var datasetCourseId = button.data('course-id');

                button.prop('disabled', true);

                // Confirm deletion.
                Str.get_strings([
                    {key: 'confirmdeletedataset', component: 'block_studentperformancepredictor'},
                    {key: 'delete', component: 'core'},
                    {key: 'cancel', component: 'core'}
                ]).done(function(strings) {
                    ModalFactory.create({
                        type: ModalFactory.types.SAVE_CANCEL,
                        title: strings[0],
                        body: strings[0]
                    }).done(function(modal) {
                        modal.setSaveButtonText(strings[1]);

                        // When the user confirms deletion
                        modal.getRoot().on(ModalEvents.save, function() {
                            $.ajax({
                                url: M.cfg.wwwroot + '/blocks/studentperformancepredictor/admin/ajax_delete_dataset.php',
                                type: 'POST',
                                data: {
                                    datasetid: datasetId,
                                    courseid: datasetCourseId,
                                    sesskey: M.cfg.sesskey
                                },
                                dataType: 'json',
                                success: function(response) {
                                    if (response.success) {
                                        window.location.reload();
                                    } else {
                                        button.prop('disabled', false);
                                        Notification.addNotification({
                                            message: response.message,
                                            type: 'error'
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    button.prop('disabled', false);
                                    var errorMessage = error;
                                    try {
                                        var resp = JSON.parse(xhr.responseText);
                                        if (resp && resp.message) {
                                            errorMessage = resp.message;
                                        }
                                    } catch (e) {}
                                    Str.get_string('actionerror', 'block_studentperformancepredictor').done(function(s) {
                                        Notification.addNotification({
                                            message: s + ': ' + errorMessage,
                                            type: 'error'
                                        });
                                    });
                                }
                            });
                        });

                        modal.getRoot().on(ModalEvents.cancel, function() {
                            button.prop('disabled', false);
                        });

                        modal.show();
                    }).catch(function(error) {
                        console.error('Error creating modal:', error);
                        button.prop('disabled', false);
                    });
                }).catch(function(error) {
                    console.error('Error loading strings:', error);
                    button.prop('disabled', false);
                });
            });

        } catch (e) {
            console.error('Error initializing admin interface:', e);
            Str.get_string('jserror', 'moodle').done(function(s) {
                Notification.exception(new Error(s + ': ' + e.message));
            });
        }
    };

    return {
        init: init
    };
});