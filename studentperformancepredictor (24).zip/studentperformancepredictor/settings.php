<?php
// blocks/studentperformancepredictor/settings.php

defined('MOODLE_INTERNAL') || die;

if ($ADMIN->fulltree) {
    // Backend integration settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/backendsettings',
        get_string('backendsettings', 'block_studentperformancepredictor'),
        get_string('backendsettings_desc', 'block_studentperformancepredictor')));

    // For Railway deployment, the default URL should match the Railway app URL
    $settings->add(new admin_setting_configtext('block_studentperformancepredictor/python_api_url',
        get_string('python_api_url', 'block_studentperformancepredictor'),
        get_string('python_api_url_desc', 'block_studentperformancepredictor'),
        'https://your-railway-app-name.up.railway.app'));

    $settings->add(new admin_setting_configpasswordunmask('block_studentperformancepredictor/python_api_key',
        get_string('python_api_key', 'block_studentperformancepredictor'),
        get_string('python_api_key_desc', 'block_studentperformancepredictor'),
        'changeme'));

    // Refresh interval for automatic predictions
    $settings->add(new admin_setting_configtext('block_studentperformancepredictor/refreshinterval',
        get_string('refreshinterval', 'block_studentperformancepredictor'),
        get_string('refreshinterval_desc', 'block_studentperformancepredictor'),
        24, PARAM_INT));

    // Risk threshold settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/riskthresholds',
        get_string('riskthresholds', 'block_studentperformancepredictor'),
        get_string('riskthresholds_desc', 'block_studentperformancepredictor')));

    $settings->add(new admin_setting_configtext('block_studentperformancepredictor/lowrisk',
        get_string('lowrisk', 'block_studentperformancepredictor'),
        get_string('lowrisk_desc', 'block_studentperformancepredictor'),
        0.7, PARAM_FLOAT));

    $settings->add(new admin_setting_configtext('block_studentperformancepredictor/mediumrisk',
        get_string('mediumrisk', 'block_studentperformancepredictor'),
        get_string('mediumrisk_desc', 'block_studentperformancepredictor'),
        0.4, PARAM_FLOAT));

    // Algorithm settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/algorithmsettings',
        get_string('algorithmsettings', 'block_studentperformancepredictor'),
        get_string('algorithmsettings_desc', 'block_studentperformancepredictor')));

    $algorithms = [
        'randomforest' => get_string('algorithm_randomforest', 'block_studentperformancepredictor'),
        'extratrees' => get_string('algorithm_extratrees', 'block_studentperformancepredictor'),
        'adaboost' => get_string('algorithm_adaboost', 'block_studentperformancepredictor'),
        'xgboost' => get_string('algorithm_xgboost', 'block_studentperformancepredictor'),
        'catboost' => get_string('algorithm_catboost', 'block_studentperformancepredictor'),
        'lightgbm' => get_string('algorithm_lightgbm', 'block_studentperformancepredictor')
    ];

    $settings->add(new admin_setting_configselect('block_studentperformancepredictor/defaultalgorithm',
        get_string('defaultalgorithm', 'block_studentperformancepredictor'),
        get_string('defaultalgorithm_desc', 'block_studentperformancepredictor'),
        'randomforest', $algorithms));

    // Python backend monitoring settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/backendmonitoring',
        get_string('backendmonitoring', 'block_studentperformancepredictor', '', true),
        get_string('backendmonitoring_desc', 'block_studentperformancepredictor', '', true)));

    // Add link to test backend page
    $testbackendurl = new moodle_url('/blocks/studentperformancepredictor/admin/testbackend.php');
    $settings->add(new admin_setting_description(
        'block_studentperformancepredictor/testbackend',
        get_string('testbackend', 'block_studentperformancepredictor'),
        html_writer::link($testbackendurl, get_string('testbackendbutton', 'block_studentperformancepredictor'),
            ['class' => 'btn btn-secondary', 'target' => '_blank'])
    ));

    // Debug mode settings
    $settings->add(new admin_setting_heading('block_studentperformancepredictor/debugsettings',
        get_string('debugsettings', 'block_studentperformancepredictor', '', true),
        get_string('debugsettings_desc', 'block_studentperformancepredictor', '', true)));

    $settings->add(new admin_setting_configcheckbox('block_studentperformancepredictor/enabledebug',
        get_string('enabledebug', 'block_studentperformancepredictor', '', true),
        get_string('enabledebug_desc', 'block_studentperformancepredictor', '', true),
        0));
}