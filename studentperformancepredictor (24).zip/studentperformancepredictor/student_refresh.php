<?php
// blocks/studentperformancepredictor/student_refresh.php

require_once('../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Default to course 0 if not specified
$courseid = optional_param('courseid', 0, PARAM_INT);

// Check if courseid is valid
if (!$courseid) {
    // Try to get course from hidden form field
    $courseid = optional_param('course', 0, PARAM_INT);
}

// If we still don't have a course, get the courses the user is enrolled in
if (!$courseid) {
    $courses = enrol_get_my_courses();
    if (!empty($courses)) {
        // Use the first enrolled course
        $course = reset($courses);
        $courseid = $course->id;
    } else {
        // No enrolled courses
        redirect(new moodle_url('/my/'), get_string('error:nocourseid', 'block_studentperformancepredictor'), 
                 null, \core\output\notification::NOTIFY_ERROR);
        exit;
    }
}

try {
    // Now we have a valid courseid
    $course = get_course($courseid);
    $context = context_course::instance($courseid);

    // Security checks
    require_login($course);
    require_sesskey();

    // Only allow students to generate their own predictions
    require_capability('block/studentperformancepredictor:view', $context);

    // Check if there's an active model
    if (!block_studentperformancepredictor_has_active_model($courseid)) {
        throw new moodle_exception('noactivemodel', 'block_studentperformancepredictor');
    }

    // Generate prediction for the current user only
    $prediction = block_studentperformancepredictor_generate_new_prediction($courseid, $USER->id);

    if ($prediction) {
        // Add cache-busting parameter to the redirect URL
        $redirecturl = new moodle_url('/course/view.php', [
            'id' => $courseid,
            '_' => time() // Cache-busting timestamp
        ]);

        redirect($redirecturl, get_string('predictiongenerated', 'block_studentperformancepredictor'), 
                2, \core\output\notification::NOTIFY_SUCCESS);
    } else {
        throw new moodle_exception('predictionerror', 'block_studentperformancepredictor');
    }

} catch (Exception $e) {
    $redirecturl = new moodle_url($courseid ? '/course/view.php' : '/my/', 
                                $courseid ? ['id' => $courseid, '_' => time()] : ['_' => time()]);
    redirect($redirecturl, $e->getMessage(), 5, \core\output\notification::NOTIFY_ERROR);
}