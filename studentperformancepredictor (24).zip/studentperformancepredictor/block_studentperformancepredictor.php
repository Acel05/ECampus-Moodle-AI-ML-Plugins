<?php
// blocks/studentperformancepredictor/block_studentperformancepredictor.php

defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

class block_studentperformancepredictor extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_studentperformancepredictor');
    }

    /**
     * This block has global configuration
     * @return bool
     */
    public function has_config() {
        return true;
    }

    public function instance_allow_multiple() {
        return false;
    }

    public function applicable_formats() {
        return array(
            'site' => false,
            'my' => true,
            'course' => true,
        );
    }

    protected function render_course_selector($courses, $currentcourse = 0) {
        global $OUTPUT;

        $options = array();
        foreach ($courses as $course) {
            $options[$course->id] = format_string($course->fullname);
        }

        $url = new moodle_url($this->page->url);
        $select = new \single_select($url, 'spp_course', $options, $currentcourse, null);
        $select->set_label(get_string('courseselectorlabel', 'block_studentperformancepredictor'),
            ['class' => 'accesshide']);
        $select->class = 'spp-course-selector';
        $select->formid = 'spp-course-selector-form';

        return $OUTPUT->render($select);
    }

    public function get_content() {
        global $USER, $COURSE, $OUTPUT, $PAGE, $DB, $CFG;

        // Add no-cache headers to prevent browser caching
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Cache-Control: post-check=0, pre-check=0', false);
            header('Pragma: no-cache');
        }

        $this->content = new stdClass();
        $this->content->text = '';
        $this->content->footer = '';

        $courseid = 0;
        $viewable_courses = [];
        $showcourseselector = false;
        $courseselectorhtml = '';

        $selected_course_param = optional_param('spp_course', 0, PARAM_INT);

        // Determine context and available courses.
        if ($PAGE->pagetype === 'my-index' || $PAGE->context->contextlevel === CONTEXT_USER) {
            // We are on the dashboard.
            $mycourses = enrol_get_my_courses(null, 'fullname ASC');

            foreach ($mycourses as $course) {
                if ($course->id == SITEID) continue;
                $context_check = context_course::instance($course->id);

                if (has_capability('block/studentperformancepredictor:view', $context_check)) {
                    $viewable_courses[$course->id] = $course;
                }
            }

            if (count($viewable_courses) > 0) {
                $showcourseselector = true;
                if ($selected_course_param && isset($viewable_courses[$selected_course_param])) {
                    $courseid = $selected_course_param;
                } else {
                    $firstcourse = reset($viewable_courses);
                    $courseid = $firstcourse->id;
                }
                $courseselectorhtml = $this->render_course_selector($viewable_courses, $courseid);
            }

        } else if ($PAGE->context->contextlevel === CONTEXT_COURSE) {
            // We are on a specific course page.
            $courseid = $PAGE->course->id;
        }

        if (empty($courseid) || $courseid == SITEID) {
            $this->content->text = $OUTPUT->notification(get_string('nocoursesfound', 'block_studentperformancepredictor'), 'info');
            return $this->content;
        }

        $coursecontext = context_course::instance($courseid);

        try {
            $canviewown = has_capability('block/studentperformancepredictor:view', $coursecontext);
            $canviewall = has_capability('block/studentperformancepredictor:viewallpredictions', $coursecontext);
            $canmanage = has_capability('block/studentperformancepredictor:managemodels', $coursecontext);

            if ($canmanage || $canviewall) { // Admin or Teacher view
                $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
                $teacherview = new \block_studentperformancepredictor\output\teacher_view($courseid, $showcourseselector, $courseselectorhtml);
                $this->content->text = $renderer->render_teacher_view($teacherview);
            } else if ($canviewown) { // Student view
                $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
                $studentview = new \block_studentperformancepredictor\output\student_view($courseid, $USER->id, $showcourseselector, $courseselectorhtml);
                $this->content->text = $renderer->render_student_view($studentview);
            } else {
                $this->content->text = ''; // Don't show anything if no permissions.
            }
        } catch (Exception $e) {
            debugging('Error rendering Student Performance Predictor block: ' . $e->getMessage(), DEBUG_DEVELOPER);
            $this->content->text = $OUTPUT->notification(get_string('errorrendingblock', 'block_studentperformancepredictor'), 'error');
        }

        return $this->content;
    }

    public function specialization() {
        if (isset($this->config->title)) {
            $this->title = $this->config->title;
        }
    }
}