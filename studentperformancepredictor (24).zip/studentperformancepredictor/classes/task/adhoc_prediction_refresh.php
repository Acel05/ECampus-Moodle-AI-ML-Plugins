<?php
// blocks/studentperformancepredictor/classes/task/adhoc_prediction_refresh.php

namespace block_studentperformancepredictor\task;

defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Adhoc task for refreshing predictions based on user requests
 */
class adhoc_prediction_refresh extends \core\task\adhoc_task {
    /**
     * Execute the task
     */
    public function execute() {
        global $DB;

        // Get task data
        $data = $this->get_custom_data();

        // Get required parameters
        $courseid = $data->courseid ?? 0;
        $userid = $data->userid ?? 0; // For individual student prediction
        $requestor = $data->requestor ?? 0; // User who requested the prediction
        $context = null;

        if (!$courseid) {
            mtrace("Error: Missing courseid parameter for prediction task");
            return;
        }

        try {
            $context = \context_course::instance($courseid);
            mtrace("Processing prediction request for course $courseid");

            // Check if we're generating for a specific user or all students
            if (!empty($userid)) {
                mtrace("Generating prediction for specific student ID: $userid");

                // Generate prediction for just this student
                $prediction = block_studentperformancepredictor_generate_prediction($courseid, $userid);

                if ($prediction) {
                    mtrace("Successfully generated prediction for student $userid");

                    // Send notification to the requesting user if they're different from the student
                    if ($requestor && $requestor != $userid) {
                        $this->send_prediction_notification($requestor, $userid, $courseid, true);
                    }
                } else {
                    mtrace("Failed to generate prediction for student $userid");
                    if ($requestor) {
                        $this->send_prediction_notification($requestor, $userid, $courseid, false);
                    }
                }
            } else {
                // Generate predictions for all students in the course
                mtrace("Generating predictions for all students in course $courseid");

                // Get all enrolled students
                $students = get_enrolled_users($context, 'moodle/course:isincompletionreports');
                mtrace("Found " . count($students) . " enrolled students");

                $success = 0;
                $failed = 0;

                foreach ($students as $student) {
                    try {
                        mtrace("Processing student ID: " . $student->id);
                        $prediction = block_studentperformancepredictor_generate_prediction($courseid, $student->id);
                        if ($prediction) {
                            $success++;
                        } else {
                            $failed++;
                        }
                    } catch (\Exception $e) {
                        mtrace("Error generating prediction for student " . $student->id . ": " . $e->getMessage());
                        $failed++;
                    }
                }

                mtrace("Completed: $success successful, $failed failed");

                // Update the last refresh time
                set_config('lastrefresh_' . $courseid, time(), 'block_studentperformancepredictor');

                // Send notification to the requestor
                if ($requestor) {
                    $this->send_batch_completion_notification($requestor, $courseid, $success, $failed);
                }
            }
        } catch (\Exception $e) {
            mtrace("Error in prediction task: " . $e->getMessage());
            if ($requestor) {
                $this->send_error_notification($requestor, $courseid, $e->getMessage());
            }
        }
    }

    /**
     * Send notification about a single prediction
     */
    protected function send_prediction_notification($requestorid, $studentid, $courseid, $success) {
        global $DB;

        $requestor = $DB->get_record('user', ['id' => $requestorid]);
        $student = $DB->get_record('user', ['id' => $studentid]);
        $course = $DB->get_record('course', ['id' => $courseid]);

        if (!$requestor || !$student || !$course) {
            return;
        }

        $subject = get_string('prediction_notification_subject', 'block_studentperformancepredictor');

        $messagedata = new \stdClass();
        $messagedata->studentname = fullname($student);
        $messagedata->coursename = format_string($course->fullname);

        if ($success) {
            $message = get_string('prediction_success_message', 'block_studentperformancepredictor', $messagedata);
        } else {
            $message = get_string('prediction_failed_message', 'block_studentperformancepredictor', $messagedata);
        }

        $eventdata = new \core\message\message();
        $eventdata->courseid = $courseid;
        $eventdata->component = 'block_studentperformancepredictor';
        $eventdata->name = 'prediction_notification';
        $eventdata->userfrom = \core_user::get_noreply_user();
        $eventdata->userto = $requestor;
        $eventdata->subject = $subject;
        $eventdata->fullmessage = $message;
        $eventdata->fullmessageformat = FORMAT_HTML;
        $eventdata->fullmessagehtml = $message;
        $eventdata->smallmessage = $subject;
        $eventdata->notification = 1;

        message_send($eventdata);
    }

    /**
     * Send notification about batch completion
     */
    protected function send_batch_completion_notification($requestorid, $courseid, $success, $failed) {
        global $DB;

        $requestor = $DB->get_record('user', ['id' => $requestorid]);
        $course = $DB->get_record('course', ['id' => $courseid]);

        if (!$requestor || !$course) {
            return;
        }

        $subject = get_string('prediction_batch_subject', 'block_studentperformancepredictor');

        $messagedata = new \stdClass();
        $messagedata->coursename = format_string($course->fullname);
        $messagedata->success = $success;
        $messagedata->failed = $failed;
        $messagedata->total = $success + $failed;

        $message = get_string('prediction_batch_message', 'block_studentperformancepredictor', $messagedata);

        $eventdata = new \core\message\message();
        $eventdata->courseid = $courseid;
        $eventdata->component = 'block_studentperformancepredictor';
        $eventdata->name = 'prediction_batch_notification';
        $eventdata->userfrom = \core_user::get_noreply_user();
        $eventdata->userto = $requestor;
        $eventdata->subject = $subject;
        $eventdata->fullmessage = $message;
        $eventdata->fullmessageformat = FORMAT_HTML;
        $eventdata->fullmessagehtml = $message;
        $eventdata->smallmessage = $subject;
        $eventdata->notification = 1;

        message_send($eventdata);
    }

    /**
     * Send error notification
     */
    protected function send_error_notification($requestorid, $courseid, $error) {
        global $DB;

        $requestor = $DB->get_record('user', ['id' => $requestorid]);
        $course = $DB->get_record('course', ['id' => $courseid]);

        if (!$requestor || !$course) {
            return;
        }

        $subject = get_string('prediction_error_subject', 'block_studentperformancepredictor');

        $messagedata = new \stdClass();
        $messagedata->coursename = format_string($course->fullname);
        $messagedata->error = $error;

        $message = get_string('prediction_error_message', 'block_studentperformancepredictor', $messagedata);

        $eventdata = new \core\message\message();
        $eventdata->courseid = $courseid;
        $eventdata->component = 'block_studentperformancepredictor';
        $eventdata->name = 'prediction_error_notification';
        $eventdata->userfrom = \core_user::get_noreply_user();
        $eventdata->userto = $requestor;
        $eventdata->subject = $subject;
        $eventdata->fullmessage = $message;
        $eventdata->fullmessageformat = FORMAT_HTML;
        $eventdata->fullmessagehtml = $message;
        $eventdata->smallmessage = $subject;
        $eventdata->notification = 1;

        message_send($eventdata);
    }
}