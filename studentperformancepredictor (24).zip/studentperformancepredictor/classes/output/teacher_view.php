<?php
// blocks/studentperformancepredictor/classes/output/teacher_view.php

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

class teacher_view implements \renderable, \templatable {
    protected $courseid;
    protected $showcourseselector;
    protected $courseselectorhtml;

    public function __construct($courseid, $showcourseselector = false, $courseselectorhtml = '') {
        $this->courseid = $courseid;
        $this->showcourseselector = $showcourseselector;
        $this->courseselectorhtml = $courseselectorhtml;
    }

    public function export_for_template(\renderer_base $output) {
        global $DB;

        $data = new \stdClass();
        $data->courseid = $this->courseid;
        $data->showcourseselector = $this->showcourseselector;
        $data->courseselectorhtml = $this->courseselectorhtml;

        // Add a cache-busting parameter
        $data->cachebuster = time();

        $course = get_course($this->courseid);
        $data->coursename = format_string($course->fullname);

        $data->heading = $this->showcourseselector
            ? get_string('pluginname', 'block_studentperformancepredictor')
            : get_string('courseperformance', 'block_studentperformancepredictor');

        $data->hasmodel = \block_studentperformancepredictor_has_active_model($this->courseid);

        $data->managemodelsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $this->courseid]);
        $data->managedatasetsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', ['courseid' => $this->courseid]);
        $data->refreshpredictionsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/refreshpredictions.php', ['courseid' => $this->courseid]);

        if (!$data->hasmodel) {
            $data->nomodeltext = get_string('noactivemodel', 'block_studentperformancepredictor');
            return $data;
        }

        $riskStats = \block_studentperformancepredictor_get_course_risk_stats($this->courseid);

        $data->totalstudents = $riskStats->total;
        $data->highrisk = $riskStats->highrisk;
        $data->mediumrisk = $riskStats->mediumrisk;
        $data->lowrisk = $riskStats->lowrisk;

        if ($data->totalstudents > 0) {
            $data->highriskpercent = round(($data->highrisk / $data->totalstudents) * 100);
            $data->mediumriskpercent = round(($data->mediumrisk / $data->totalstudents) * 100);
            $data->lowriskpercent = round(($data->lowrisk / $data->totalstudents) * 100);
        } else {
            $data->highriskpercent = 0;
            $data->mediumriskpercent = 0;
            $data->lowriskpercent = 0;
        }

        $data->students_highrisk = $this->get_students_by_risk_level(3);
        $data->students_mediumrisk = $this->get_students_by_risk_level(2);
        $data->students_lowrisk = $this->get_students_by_risk_level(1);

        $data->has_highrisk_students = !empty($data->students_highrisk);
        $data->has_mediumrisk_students = !empty($data->students_mediumrisk);
        $data->has_lowrisk_students = !empty($data->students_lowrisk);

        return $data;
    }

    protected function get_students_by_risk_level($risk_level) {
        global $DB, $PAGE;

        $sql = "SELECT p.id AS predictionid, p.passprob, p.predictiondata, u.*
                FROM {block_spp_predictions} p
                JOIN {user} u ON p.userid = u.id
                JOIN {block_spp_models} m ON p.modelid = m.id
                JOIN (
                    SELECT userid, MAX(timemodified) AS maxtime
                    FROM {block_spp_predictions}
                    WHERE courseid = :courseid
                    GROUP BY userid
                ) AS latest_p ON p.userid = latest_p.userid AND p.timemodified = latest_p.maxtime
                WHERE p.courseid = :courseid2
                  AND p.riskvalue = :risklevel
                  AND m.active = 1
                ORDER BY u.lastname, u.firstname";

        $params = ['courseid' => $this->courseid, 'courseid2' => $this->courseid, 'risklevel' => $risk_level];
        $records = $DB-> get_records_sql($sql, $params);
        $students = [];

        foreach ($records as $record) {
            $user_picture = new \user_picture($record);
            $user_picture->size = 35;

            $student = new \stdClass();
            $student->id = $record->id;
            $student->fullname = fullname($record);
            $student->picture = $user_picture->get_url($PAGE)->out(false);
            $student->passprob = round($record->passprob * 100);
            $student->profileurl = new \moodle_url('/user/view.php', ['id' => $record->id, 'course' => $this->courseid]);
            $student->generate_url = new \moodle_url('/blocks/studentperformancepredictor/generate_prediction.php',
                                                   ['courseid' => $this->courseid, 'userid' => $record->id, 'sesskey' => sesskey()]);

            $prediction_data = json_decode($record->predictiondata, true);
            $student->risk_factors = $this->extract_risk_factors($prediction_data, $risk_level);

            $suggestions = \block_studentperformancepredictor_get_suggestions($record->predictionid);
            $student->suggestions = [];
            if (!empty($suggestions)) {
                foreach (array_slice($suggestions, 0, 2) as $suggestion) { // Limit to 2 for a "short version"
                    $suggestion_text = $suggestion->cmname;
                    if (isset($suggestion->reason) && !empty($suggestion->reason)) {
                        $suggestion_text .= ': ' . substr($suggestion->reason, 0, 50) . (strlen($suggestion->reason) > 50 ? '...' : '');
                    }
                    $student->suggestions[] = (object)['text' => $suggestion_text];
                }
            }

            $students[] = $student;
        }
        return $students;
    }

    protected function extract_risk_factors($prediction_data, $risk_level) {
        $factors = [];
        // This is the corrected access path.
        if (empty($prediction_data) || !isset($prediction_data['features'])) {
            return [get_string('nofactorsavailable', 'block_studentperformancepredictor')];
        }
        $features = $prediction_data['features'];

        if (isset($features['activity_level']) && $features['activity_level'] < 5 && $risk_level >= 2) {
            $factors[] = get_string('factor_low_activity', 'block_studentperformancepredictor');
        }
        if (isset($features['submission_count']) && $features['submission_count'] < 2 && $risk_level >= 2) {
            $factors[] = get_string('factor_low_submissions', 'block_studentperformancepredictor');
        }
        if (isset($features['current_grade_percentage']) && $features['current_grade_percentage'] < 50 && $risk_level == 3) {
            $factors[] = get_string('factor_low_grades', 'block_studentperformancepredictor');
        }
        if (isset($features['days_since_last_access']) && $features['days_since_last_access'] > 7 && $risk_level == 3) {
            $factors[] = get_string('factor_not_logged_in', 'block_studentperformancepredictor', (int)$features['days_since_last_access']);
        }

        if (empty($factors)) {
            if ($risk_level == 3) {
                $factors[] = get_string('factor_general_high_risk', 'block_studentperformancepredictor');
            } else if ($risk_level == 2) {
                $factors[] = get_string('factor_general_medium_risk', 'block_studentperformancepredictor');
            } else {
                 $factors[] = get_string('factor_general_low_risk', 'block_studentperformancepredictor');
            }
        }
        return $factors;
    }
}