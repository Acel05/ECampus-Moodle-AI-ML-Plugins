<?php
// blocks/studentperformancepredictor/classes/output/student_view.php

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

// Add this line to include lib.php which contains the function definitions
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Student view class for the student dashboard.
 *
 * This class prepares data for the student dashboard template.
 */
class student_view implements \renderable, \templatable {
    /** @var int Course ID */
    protected $courseid;

    /** @var int User ID */
    protected $userid;

    /** @var bool Whether to show course selector */
    protected $showcourseselector;

    /** @var string Course selector HTML */
    protected $courseselector;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     * @param int $userid User ID
     * @param bool $showcourseselector Whether to show course selector
     * @param string $courseselector Course selector HTML
     */
    public function __construct($courseid, $userid, $showcourseselector = false, $courseselector = '') {
        $this->courseid = $courseid;
        $this->userid = $userid;
        $this->showcourseselector = $showcourseselector;
        $this->courseselector = $courseselector;
    }

    /**
     * Export data for template.
     *
     * @param \renderer_base $output The renderer
     * @return \stdClass Data for template
     */
    public function export_for_template(\renderer_base $output) {
        global $DB, $CFG, $PAGE;

        $data = new \stdClass();
        $data->heading = get_string('studentperformance', 'block_studentperformancepredictor');
        $data->courseid = $this->courseid;
        $data->userid = $this->userid;
        $data->showcourseselector = $this->showcourseselector;
        $data->courseselector = $this->courseselector;

        // Get course info
        $course = get_course($this->courseid);
        $data->coursename = format_string($course->fullname);

        // Check if there's an active model
        $data->hasmodel = \block_studentperformancepredictor_has_active_model($this->courseid);

        if (!$data->hasmodel) {
            $data->nomodeltext = get_string('noactivemodel', 'block_studentperformancepredictor');
            return $data;
        }

        // Important: Add timestamp to prevent browser caching
        $data->cachebuster = time();

        // Get student prediction - ALWAYS get the latest one by using ORDER BY timemodified DESC
        $sql = "SELECT p.* 
                FROM {block_spp_predictions} p
                JOIN {block_spp_models} m ON p.modelid = m.id
                WHERE p.courseid = :courseid
                AND p.userid = :userid
                AND m.active = 1
                ORDER BY p.timemodified DESC
                LIMIT 1";

        $prediction = $DB->get_record_sql($sql, [
            'courseid' => $this->courseid,
            'userid' => $this->userid
        ]);

        // Set up prediction generation button
        $data->can_generate_prediction = true;
        $data->generate_prediction_url = new \moodle_url('/blocks/studentperformancepredictor/student_refresh.php');
        $data->sesskey = sesskey();

        if (!$prediction) {
            $data->hasprediction = false;
            $data->nopredictiontext = get_string('noprediction', 'block_studentperformancepredictor');
            return $data;
        }

        $data->hasprediction = true;

        // Prediction information
        $data->passprob = round($prediction->passprob * 100);
        $data->riskvalue = $prediction->riskvalue;
        $data->risktext = \block_studentperformancepredictor_get_risk_text($prediction->riskvalue);
        $data->riskclass = \block_studentperformancepredictor_get_risk_class($prediction->riskvalue);
        $data->lastupdate = userdate($prediction->timemodified);
        $data->predictionid = $prediction->id;

        // Add raw prediction data for chart rendering
        $data->chartdata = json_encode([
            'passprob' => $data->passprob,
            'failprob' => 100 - $data->passprob
        ]);

        // Get suggestions
        $suggestions = \block_studentperformancepredictor_get_suggestions($prediction->id);

        $data->hassuggestions = !empty($suggestions);
        $data->suggestions = [];

        foreach ($suggestions as $suggestion) {
            $suggestionData = new \stdClass();
            $suggestionData->id = $suggestion->id;
            $suggestionData->reason = $suggestion->reason;
            if (!empty($suggestion->cmid)) {
                $suggestionData->hasurl = true;
                $suggestionData->url = new \moodle_url('/mod/' . $suggestion->modulename . '/view.php', ['id' => $suggestion->cmid]);
                $suggestionData->name = $suggestion->cmname;
            } else {
                $suggestionData->hasurl = false;
                $suggestionData->name = get_string('generalstudy', 'block_studentperformancepredictor');
            }
            $suggestionData->viewed = $suggestion->viewed;
            $suggestionData->completed = $suggestion->completed;
            $data->suggestions[] = $suggestionData;
        }

        return $data;
    }
}