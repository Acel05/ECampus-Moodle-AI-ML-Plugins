<?php
// blocks/studentperformancepredictor/classes/analytics/training_manager.php

namespace block_studentperformancepredictor\analytics;

defined('MOODLE_INTERNAL') || die();

/**
 * Manages model training workflows.
 */
class training_manager {

    /**
     * Check if there's already pending training for a course.
     *
     * @param int $courseid Course ID
     * @return bool True if training is pending
     */
    public static function has_pending_training($courseid) {
        global $DB;

        // Check for pending training in block_spp_models
        $pending_count = $DB->count_records('block_spp_models', 
            ['courseid' => $courseid, 'trainstatus' => 'pending']);
        $training_count = $DB->count_records('block_spp_models', 
            ['courseid' => $courseid, 'trainstatus' => 'training']);

        if ($pending_count > 0 || $training_count > 0) {
            return true;
        }

        // Check adhoc tasks queue
        $task_count = $DB->count_records_sql(
            "SELECT COUNT(*) FROM {task_adhoc} 
             WHERE classname = ? AND customdata LIKE ?",
            [
                '\\block_studentperformancepredictor\\task\\adhoc_train_model',
                '%"courseid":' . $courseid . '%'
            ]
        );

        return $task_count > 0;
    }

    /**
     * Schedule model training.
     *
     * @param int $courseid Course ID
     * @param int $datasetid Dataset ID
     * @param string $algorithm Algorithm to use
     * @param array $options Additional options
     * @return bool Success
     */
    public static function schedule_training($courseid, $datasetid, $algorithm = null, $options = []) {
        global $DB, $USER;

        // Create a new model record in 'pending' state
        $model = new \stdClass();
        $model->courseid = $courseid;
        $model->datasetid = $datasetid;
        $model->modelname = ucfirst($algorithm ?: 'randomforest') . ' Model - ' . date('Y-m-d H:i');
        $model->algorithmtype = $algorithm ?: 'randomforest';
        $model->active = 0; // Will be activated after training
        $model->trainstatus = 'pending';
        $model->timecreated = time();
        $model->timemodified = time();
        $model->usermodified = $USER->id;

        $modelid = $DB->insert_record('block_spp_models', $model);

        if (!$modelid) {
            return false;
        }

        // Create adhoc task
        $task = new \block_studentperformancepredictor\task\adhoc_train_model();
        $task->set_custom_data([
            'courseid' => $courseid,
            'datasetid' => $datasetid,
            'algorithm' => $algorithm,
            'userid' => $USER->id,
            'modelid' => $modelid
        ]);

        // Queue task with high priority
        return \core\task\manager::queue_adhoc_task($task, true);
    }

    /**
     * Handle successful model training.
     * 
     * @param int $modelid The model ID in the database
     * @param array $trainingResponse The response from the backend API
     * @param int $courseid The course ID
     * @return bool Success
     */
    public static function handle_successful_training($modelid, $trainingResponse, $courseid) {
        global $DB, $USER;

        // Start transaction
        $transaction = $DB->start_delegated_transaction();

        try {
            // Get the model record
            $model = $DB->get_record('block_spp_models', ['id' => $modelid]);
            if (!$model) {
                debugging('Model record not found for ID: ' . $modelid, DEBUG_DEVELOPER);
                return false;
            }

            // Update with backend info
            $model->modelid = $trainingResponse['model_id'];
            $model->modelpath = $trainingResponse['model_path'] ?? null;
            $model->featureslist = isset($trainingResponse['feature_names']) ? json_encode($trainingResponse['feature_names']) : '[]';
            $model->accuracy = $trainingResponse['metrics']['accuracy'] ?? 0;
            $model->metrics = isset($trainingResponse['metrics']) ? json_encode($trainingResponse['metrics']) : null;
            $model->trainstatus = 'complete';
            $model->timemodified = time();
            $model->usermodified = $USER->id;

            // IMPORTANT: Automatically deactivate all other models and set this one active
            $DB->set_field('block_spp_models', 'active', 0, ['courseid' => $courseid]);
            $model->active = 1;

            // Save updated model record
            $DB->update_record('block_spp_models', $model);

            $transaction->allow_commit();

            // Immediately trigger prediction refresh
            if ($courseid > 0) {
                \block_studentperformancepredictor_trigger_prediction_refresh($courseid);
            }

            return true;
        } catch (\Exception $e) {
            $transaction->rollback();
            debugging('Error handling successful training: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return false;
        }
    }
}