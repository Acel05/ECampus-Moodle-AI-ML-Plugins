<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Student performance prediction reports for admin and teachers.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters
$courseid = optional_param('courseid', 0, PARAM_INT);
$admin = optional_param('admin', 0, PARAM_BOOL);

// Set up page
if ($admin) {
    // Admin view - either all courses or filtered by course
    require_login();
    require_capability('moodle/site:config', context_system::instance());

    $PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/reports.php', array('admin' => 1, 'courseid' => $courseid)));
    $PAGE->set_context(context_system::instance());
    $PAGE->set_title(get_string('adminreport', 'block_studentperformancepredictor'));
    $PAGE->set_heading(get_string('adminreport', 'block_studentperformancepredictor'));
    $PAGE->set_pagelayout('admin');

    // Output starts here
    echo $OUTPUT->header();

    // Show admin view
    $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
    $adminview = new \block_studentperformancepredictor\output\admin_view(0, $courseid); // 0 = sitewide, with optional filter
    echo $renderer->render_admin_view($adminview);

} else {
    // Teacher view - specific course
    if (empty($courseid)) {
        throw new moodle_exception('invalidcourseid', 'error');
    }

    $course = get_course($courseid);
    $context = context_course::instance($courseid);

    // Check permissions
    require_login($course);
    require_capability('block/studentperformancepredictor:viewallpredictions', $context);

    // Set up page layout
    $PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/reports.php', array('courseid' => $courseid)));
    $PAGE->set_context($context);
    $PAGE->set_title(get_string('detailedreport', 'block_studentperformancepredictor'));
    $PAGE->set_heading(format_string($course->fullname));
    $PAGE->set_pagelayout('standard');

    // Output starts here
    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('detailedreport', 'block_studentperformancepredictor'));

    // Check if there's an active model
    if (!block_studentperformancepredictor_has_active_model($courseid)) {
        echo $OUTPUT->notification(get_string('noactivemodel', 'block_studentperformancepredictor'), 'warning');
        echo html_writer::link(
            new moodle_url('/course/view.php', array('id' => $courseid)),
            get_string('backtocourse', 'block_studentperformancepredictor'),
            array('class' => 'btn btn-secondary')
        );
        echo $OUTPUT->footer();
        exit;
    }

    // Show teacher view
    $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
    $teacherview = new \block_studentperformancepredictor\output\teacher_view($courseid);
    echo $renderer->render_teacher_view($teacherview);
}

// Add a "Back" button
if ($admin) {
    echo html_writer::div(
        html_writer::link(
            new moodle_url('/admin/settings.php', ['section' => 'blocksettingstudentperformancepredictor']),
            get_string('backsettings', 'block_studentperformancepredictor'),
            ['class' => 'btn btn-secondary']
        ),
        'mt-3'
    );
} else {
    echo html_writer::div(
        html_writer::link(
            new moodle_url('/course/view.php', array('id' => $courseid)),
            get_string('backtocourse', 'block_studentperformancepredictor'),
            array('class' => 'btn btn-secondary')
        ),
        'mt-3'
    );
}

// Output footer
echo $OUTPUT->footer();