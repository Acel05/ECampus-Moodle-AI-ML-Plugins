<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Admin view renderer for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

// Add this line to include lib.php which contains the function definitions
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Admin view class for the admin dashboard.
 *
 * This class prepares data for the admin dashboard template.
 */
class admin_view implements \renderable, \templatable {
    /** @var int Course ID - for admin view this can be 0 to show all courses */
    protected $courseid;

    /** @var int The filter course ID if filtering by a specific course */
    protected $filter_courseid;

    /** @var bool Is this a site-wide admin view */
    protected $is_sitewide;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID (0 for all courses)
     * @param int $filter_courseid Optional course ID to filter by
     */
    public function __construct($courseid, $filter_courseid = 0) {
        $this->courseid = $courseid;
        $this->filter_courseid = $filter_courseid;
        $this->is_sitewide = ($courseid === 0);
    }

    /**
     * Export data for template.
     *
     * @param \renderer_base $output The renderer
     * @return \stdClass Data for template
     */
    public function export_for_template(\renderer_base $output) {
        global $CFG, $DB, $PAGE;

        $data = new \stdClass();
        $data->heading = get_string('modelmanagement', 'block_studentperformancepredictor');
        $data->courseid = $this->courseid;
        $data->is_sitewide = $this->is_sitewide;

        // Create URLs
        $data->managemodelsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', 
                                             ['courseid' => $this->courseid]);
        $data->managedatasetsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/managedatasets.php', 
                                               ['courseid' => $this->courseid]);
        $data->refreshpredictionsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/refreshpredictions.php', 
                                                   ['courseid' => $this->courseid]);

        // For site-wide admin, we need to get courses with active models
        if ($this->is_sitewide) {
            // Get courses with active models
            $courses_with_models = $this->get_courses_with_models();
            $data->has_courses = !empty($courses_with_models);
            $data->courses = $courses_with_models;

            // Check if we're filtering by a specific course
            if ($this->filter_courseid && isset($courses_with_models[$this->filter_courseid])) {
                $data->filter_courseid = $this->filter_courseid;
                $data->filter_coursename = $courses_with_models[$this->filter_courseid]->fullname;
                $data->is_filtered = true;

                // Create course selector URL
                $data->course_selector_url = new \moodle_url('/blocks/studentperformancepredictor/reports.php', 
                                                         ['admin' => 1]);

                // For filtered view, get stats and students for the selected course
                $active_courseid = $this->filter_courseid;
                $data->hasmodel = \block_studentperformancepredictor_has_active_model($active_courseid);

                if ($data->hasmodel) {
                    // Get risk statistics for this course
                    $riskStats = \block_studentperformancepredictor_get_course_risk_stats($active_courseid);

                    $data->totalstudents = $riskStats->total;
                    $data->highrisk = $riskStats->highrisk;
                    $data->mediumrisk = $riskStats->mediumrisk;
                    $data->lowrisk = $riskStats->lowrisk;

                    // Calculate percentages
                    if ($data->totalstudents > 0) {
                        $data->highriskpercent = round(($data->highrisk / $data->totalstudents) * 100);
                        $data->mediumriskpercent = round(($data->mediumrisk / $data->totalstudents) * 100);
                        $data->lowriskpercent = round(($data->lowrisk / $data->totalstudents) * 100);
                    } else {
                        $data->highriskpercent = 0;
                        $data->mediumriskpercent = 0;
                        $data->lowriskpercent = 0;
                    }

                    // Get students in this course by risk level
                    $data->students_highrisk = $this->get_students_by_risk_level(3, $active_courseid);
                    $data->students_mediumrisk = $this->get_students_by_risk_level(2, $active_courseid);
                    $data->students_lowrisk = $this->get_students_by_risk_level(1, $active_courseid);

                    // Check if we have students in each category
                    $data->has_highrisk_students = !empty($data->students_highrisk);
                    $data->has_mediumrisk_students = !empty($data->students_mediumrisk);
                    $data->has_lowrisk_students = !empty($data->students_lowrisk);

                    // Create chart data for this course
                    $data->haschart = true;
                    $chartData = [
                        'labels' => [
                            get_string('highrisk_label', 'block_studentperformancepredictor'),
                            get_string('mediumrisk_label', 'block_studentperformancepredictor'),
                            get_string('lowrisk_label', 'block_studentperformancepredictor')
                        ],
                        'data' => [$data->highrisk, $data->mediumrisk, $data->lowrisk]
                    ];
                    $data->chartdata = json_encode($chartData);
                }
            } else {
                // Not filtering - show aggregated stats for all courses
                $data->is_filtered = false;
                $data->sitewide_stats = $this->get_sitewide_risk_stats();

                // Get high risk students across all courses
                $data->all_highrisk_students = $this->get_all_students_by_risk_level(3);
                $data->has_highrisk_students = !empty($data->all_highrisk_students);

                // Create global chart data
                $data->haschart = true;
                $chartData = [
                    'labels' => [
                        get_string('highrisk_label', 'block_studentperformancepredictor'),
                        get_string('mediumrisk_label', 'block_studentperformancepredictor'),
                        get_string('lowrisk_label', 'block_studentperformancepredictor')
                    ],
                    'data' => [
                        $data->sitewide_stats->highrisk, 
                        $data->sitewide_stats->mediumrisk, 
                        $data->sitewide_stats->lowrisk
                    ]
                ];
                $data->chartdata = json_encode($chartData);
            }
        } else {
            // Course-specific admin view
            $data->hasmodel = \block_studentperformancepredictor_has_active_model($this->courseid);

            if ($data->hasmodel) {
                // Get risk statistics
                $riskStats = \block_studentperformancepredictor_get_course_risk_stats($this->courseid);

                $data->totalstudents = $riskStats->total;
                $data->highrisk = $riskStats->highrisk;
                $data->mediumrisk = $riskStats->mediumrisk;
                $data->lowrisk = $riskStats->lowrisk;

                // Calculate percentages
                if ($data->totalstudents > 0) {
                    $data->highriskpercent = round(($data->highrisk / $data->totalstudents) * 100);
                    $data->mediumriskpercent = round(($data->mediumrisk / $data->totalstudents) * 100);
                    $data->lowriskpercent = round(($data->lowrisk / $data->totalstudents) * 100);
                } else {
                    $data->highriskpercent = 0;
                    $data->mediumriskpercent = 0;
                    $data->lowriskpercent = 0;
                }

                // Get students by risk level
                $data->students_highrisk = $this->get_students_by_risk_level(3, $this->courseid);
                $data->students_mediumrisk = $this->get_students_by_risk_level(2, $this->courseid);
                $data->students_lowrisk = $this->get_students_by_risk_level(1, $this->courseid);

                // Check if we have students in each category
                $data->has_highrisk_students = !empty($data->students_highrisk);
                $data->has_mediumrisk_students = !empty($data->students_mediumrisk);
                $data->has_lowrisk_students = !empty($data->students_lowrisk);

                // Create chart data
                $data->haschart = true;
                $chartData = [
                    'labels' => [
                        get_string('highrisk_label', 'block_studentperformancepredictor'),
                        get_string('mediumrisk_label', 'block_studentperformancepredictor'),
                        get_string('lowrisk_label', 'block_studentperformancepredictor')
                    ],
                    'data' => [$data->highrisk, $data->mediumrisk, $data->lowrisk]
                ];
                $data->chartdata = json_encode($chartData);
            } else {
                $data->nomodeltext = get_string('noactivemodel', 'block_studentperformancepredictor');
            }
        }

        return $data;
    }

    /**
     * Get courses that have active prediction models.
     *
     * @return array Course objects with model information
     */
    protected function get_courses_with_models() {
        global $DB;

        $sql = "SELECT c.id, c.fullname, c.shortname, c.visible, 
                       COUNT(DISTINCT p.id) as prediction_count,
                       SUM(CASE WHEN p.riskvalue = 3 THEN 1 ELSE 0 END) as highrisk,
                       SUM(CASE WHEN p.riskvalue = 2 THEN 1 ELSE 0 END) as mediumrisk,
                       SUM(CASE WHEN p.riskvalue = 1 THEN 1 ELSE 0 END) as lowrisk
                FROM {course} c
                JOIN {block_spp_predictions} p ON p.courseid = c.id
                JOIN {block_spp_models} m ON p.modelid = m.id
                WHERE m.active = 1
                GROUP BY c.id, c.fullname, c.shortname, c.visible
                ORDER BY highrisk DESC, c.fullname ASC";

        $courses = $DB->get_records_sql($sql);

        // Format the course data for display
        foreach ($courses as $course) {
            // Calculate percentages
            $total = $course->prediction_count;
            if ($total > 0) {
                $course->highrisk_percent = round(($course->highrisk / $total) * 100);
                $course->mediumrisk_percent = round(($course->mediumrisk / $total) * 100);
                $course->lowrisk_percent = round(($course->lowrisk / $total) * 100);
            } else {
                $course->highrisk_percent = 0;
                $course->mediumrisk_percent = 0;
                $course->lowrisk_percent = 0;
            }

            // Add view URL
            $course->view_url = new \moodle_url('/blocks/studentperformancepredictor/reports.php', 
                                              ['admin' => 1, 'courseid' => $course->id]);
        }

        return $courses;
    }

    /**
     * Get aggregated risk statistics across all courses.
     *
     * @return object Object with risk statistics
     */
    protected function get_sitewide_risk_stats() {
        global $DB;

        $stats = new \stdClass();

        // Get counts from all predictions
        $sql = "SELECT COUNT(DISTINCT p.id) as total,
                       SUM(CASE WHEN p.riskvalue = 3 THEN 1 ELSE 0 END) as highrisk,
                       SUM(CASE WHEN p.riskvalue = 2 THEN 1 ELSE 0 END) as mediumrisk,
                       SUM(CASE WHEN p.riskvalue = 1 THEN 1 ELSE 0 END) as lowrisk
                FROM {block_spp_predictions} p
                JOIN {block_spp_models} m ON p.modelid = m.id
                WHERE m.active = 1";

        $result = $DB->get_record_sql($sql);

        if ($result) {
            $stats->total = $result->total;
            $stats->highrisk = $result->highrisk;
            $stats->mediumrisk = $result->mediumrisk;
            $stats->lowrisk = $result->lowrisk;

            // Calculate percentages
            if ($stats->total > 0) {
                $stats->highriskpercent = round(($stats->highrisk / $stats->total) * 100);
                $stats->highriskpercent = round(($stats->highrisk / $stats->total) * 100);
                $stats->mediumriskpercent = round(($stats->mediumrisk / $stats->total) * 100);
                $stats->lowriskpercent = round(($stats->lowrisk / $stats->total) * 100);
            } else {
                $stats->highriskpercent = 0;
                $stats->mediumriskpercent = 0;
                $stats->lowriskpercent = 0;
            }
        } else {
            // Default values if no predictions exist
            $stats->total = 0;
            $stats->highrisk = 0;
            $stats->mediumrisk = 0;
            $stats->lowrisk = 0;
            $stats->highriskpercent = 0;
            $stats->mediumriskpercent = 0;
            $stats->lowriskpercent = 0;
        }

        return $stats;
    }

    /**
     * Get students by risk level with prediction details for a specific course.
     *
     * @param int $risk_level Risk level (1=low, 2=medium, 3=high)
     * @param int $courseid Course ID
     * @return array Students with this risk level
     */
    protected function get_students_by_risk_level($risk_level, $courseid) {
        global $DB, $PAGE;

        $sql = "SELECT p.*, u.id as userid, u.firstname, u.lastname, u.email, u.picture, u.imagealt, 
                       u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename,
                       c.fullname as coursename, c.shortname as courseshortname
                FROM {block_spp_predictions} p
                JOIN {user} u ON p.userid = u.id
                JOIN {course} c ON p.courseid = c.id
                JOIN {block_spp_models} m ON p.modelid = m.id
                WHERE p.courseid = :courseid 
                AND p.riskvalue = :risklevel
                AND m.active = 1
                ORDER BY u.lastname, u.firstname";

        $params = [
            'courseid' => $courseid,
            'risklevel' => $risk_level
        ];

        $records = $DB->get_records_sql($sql, $params);
        $students = [];

        foreach ($records as $record) {
            // Get prediction details
            $prediction_data = json_decode($record->predictiondata, true);

            // Extract risk factors from prediction data
            $risk_factors = $this->extract_risk_factors($prediction_data, $risk_level);

            // Get user picture URL
            $user_picture = new \user_picture($record);
            $user_picture->size = 35; // Size in pixels
            $picture_url = $user_picture->get_url($PAGE);

            // Create student object
            $student = new \stdClass();
            $student->id = $record->userid;
            $student->fullname = fullname($record);
            $student->picture = $user_picture->get_url($PAGE)->out(false);
            $student->passprob = round($record->passprob * 100);
            $student->profileurl = new \moodle_url('/user/view.php', 
                                                 ['id' => $record->userid, 'course' => $courseid]);
            $student->risk_factors = $risk_factors;
            $student->prediction_id = $record->id;
            $student->coursename = $record->coursename;
            $student->courseshortname = $record->courseshortname;
            $student->generate_url = new \moodle_url('/blocks/studentperformancepredictor/generate_prediction.php', 
                                                   ['courseid' => $courseid, 
                                                    'userid' => $record->userid, 
                                                    'sesskey' => sesskey()]);

            $students[] = $student;
        }

        return $students;
    }

    /**
     * Get all high-risk students across all courses.
     *
     * @param int $risk_level Risk level (1=low, 2=medium, 3=high)
     * @return array Students with this risk level from all courses
     */
    protected function get_all_students_by_risk_level($risk_level) {
        global $DB, $PAGE;

        $sql = "SELECT p.*, u.id as userid, u.firstname, u.lastname, u.email, u.picture, u.imagealt, 
                       u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename,
                       c.id as courseid, c.fullname as coursename, c.shortname as courseshortname
                FROM {block_spp_predictions} p
                JOIN {user} u ON p.userid = u.id
                JOIN {course} c ON p.courseid = c.id
                JOIN {block_spp_models} m ON p.modelid = m.id
                WHERE p.riskvalue = :risklevel
                AND m.active = 1
                ORDER BY c.fullname, u.lastname, u.firstname";

        $params = [
            'risklevel' => $risk_level
        ];

        $records = $DB->get_records_sql($sql, $params);
        $students = [];

        foreach ($records as $record) {
            // Get prediction details
            $prediction_data = json_decode($record->predictiondata, true);

            // Extract risk factors from prediction data
            $risk_factors = $this->extract_risk_factors($prediction_data, $risk_level);

            // Get user picture URL
            $user_picture = new \user_picture($record);
            $user_picture->size = 35; // Size in pixels
            $picture_url = $user_picture->get_url($PAGE);

            // Create student object
            $student = new \stdClass();
            $student->id = $record->userid;
            $student->fullname = fullname($record);
            $student->picture = $user_picture->get_url($PAGE)->out(false);
            $student->passprob = round($record->passprob * 100);
            $student->profileurl = new \moodle_url('/user/view.php', 
                                                 ['id' => $record->userid, 'course' => $record->courseid]);
            $student->risk_factors = $risk_factors;
            $student->prediction_id = $record->id;
            $student->courseid = $record->courseid;
            $student->coursename = $record->coursename;
            $student->courseshortname = $record->courseshortname;
            $student->generate_url = new \moodle_url('/blocks/studentperformancepredictor/generate_prediction.php', 
                                                   ['courseid' => $record->courseid, 
                                                    'userid' => $record->userid, 
                                                    'sesskey' => sesskey()]);

            $students[] = $student;
        }

        return $students;
    }

    /**
     * Extract risk factors from prediction data.
     * 
     * Same implementation as in the teacher_view class.
     *
     * @param array $prediction_data Prediction data from backend
     * @param int $risk_level Risk level (1=low, 2=medium, 3=high)
     * @return array Risk factors
     */
    protected function extract_risk_factors($prediction_data, $risk_level) {
        $factors = [];

        // Check if we have backend data
        if (empty($prediction_data) || empty($prediction_data['backend'])) {
            return [get_string('nofactorsavailable', 'block_studentperformancepredictor')];
        }

        $backend_data = $prediction_data['backend'];

        // Add activity level factor
        if (isset($backend_data['features']['activity_level'])) {
            $activity = (int)$backend_data['features']['activity_level'];
            if ($risk_level == 3 && $activity < 5) {
                $factors[] = get_string('factor_low_activity', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $activity < 10) {
                $factors[] = get_string('factor_medium_activity', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $activity >= 15) {
                $factors[] = get_string('factor_high_activity', 'block_studentperformancepredictor');
            }
        }

        // Add submission factor
        if (isset($backend_data['features']['submission_count'])) {
            $submissions = (int)$backend_data['features']['submission_count'];
            if ($risk_level == 3 && $submissions < 2) {
                $factors[] = get_string('factor_low_submissions', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $submissions < 4) {
                $factors[] = get_string('factor_medium_submissions', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $submissions >= 5) {
                $factors[] = get_string('factor_high_submissions', 'block_studentperformancepredictor');
            }
        }

        // Add grade factor
        if (isset($backend_data['features']['grade_average'])) {
            $grade = (float)$backend_data['features']['grade_average'] * 100;
            if ($risk_level == 3 && $grade < 50) {
                $factors[] = get_string('factor_low_grades', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $grade < 70) {
                $factors[] = get_string('factor_medium_grades', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $grade >= 75) {
                $factors[] = get_string('factor_high_grades', 'block_studentperformancepredictor');
            }
        }

        // Add login recency factor
        if (isset($backend_data['features']['days_since_last_access'])) {
            $days = (int)$backend_data['features']['days_since_last_access'];
            if ($risk_level == 3 && $days > 7) {
                $factors[] = get_string('factor_not_logged_in', 'block_studentperformancepredictor', $days);
            } else if ($risk_level == 2 && $days > 3) {
                $factors[] = get_string('factor_few_days_since_login', 'block_studentperformancepredictor', $days);
            } else if ($risk_level == 1 && $days <= 1) {
                $factors[] = get_string('factor_recent_login', 'block_studentperformancepredictor');
            }
        }

        // Add modules accessed factor
        if (isset($backend_data['features']['current_course_modules_accessed'])) {
            $modules = (int)$backend_data['features']['current_course_modules_accessed'];
            if ($risk_level == 3 && $modules < 3) {
                $factors[] = get_string('factor_few_modules_accessed', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $modules < 6) {
                $factors[] = get_string('factor_some_modules_accessed', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $modules >= 8) {
                $factors[] = get_string('factor_many_modules_accessed', 'block_studentperformancepredictor');
            }
        }

        // If no specific factors were identified, add a default message
        if (empty($factors)) {
            if ($risk_level == 3) {
                $factors[] = get_string('factor_general_high_risk', 'block_studentperformancepredictor');
            } else if ($risk_level == 2) {
                $factors[] = get_string('factor_general_medium_risk', 'block_studentperformancepredictor');
            } else {
                $factors[] = get_string('factor_general_low_risk', 'block_studentperformancepredictor');
            }
        }

        return $factors;
    }
}