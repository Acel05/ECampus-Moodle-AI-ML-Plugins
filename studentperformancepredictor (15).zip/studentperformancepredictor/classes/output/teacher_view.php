<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Teacher view renderer for Student Performance Predictor.
 *
 * @package    block_studentperformancepredictor
 * @copyright  2023 Your Name <[Email]>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

// Add this line to include lib.php which contains the function definitions
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Teacher view class for the teacher dashboard.
 *
 * This class prepares data for the teacher dashboard template.
 */
class teacher_view implements \renderable, \templatable {
    /** @var int Course ID */
    protected $courseid;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     */
    public function __construct($courseid) {
        $this->courseid = $courseid;
    }

    /**
     * Export data for template.
     *
     * @param \renderer_base $output The renderer
     * @return \stdClass Data for template
     */
    public function export_for_template(\renderer_base $output) {
        global $CFG, $DB;

        $data = new \stdClass();
        $data->heading = get_string('courseperformance', 'block_studentperformancepredictor');
        $data->courseid = $this->courseid;

        // Check if there's an active model - use global namespace function
        $data->hasmodel = \block_studentperformancepredictor_has_active_model($this->courseid);

        if (!$data->hasmodel) {
            $data->nomodeltext = get_string('noactivemodel', 'block_studentperformancepredictor');
            return $data;
        }

        // Get risk statistics - use global namespace function
        $riskStats = \block_studentperformancepredictor_get_course_risk_stats($this->courseid);

        $data->totalstudents = $riskStats->total;
        $data->highrisk = $riskStats->highrisk;
        $data->mediumrisk = $riskStats->mediumrisk;
        $data->lowrisk = $riskStats->lowrisk;

        // Calculate percentages
        if ($data->totalstudents > 0) {
            $data->highriskpercent = round(($data->highrisk / $data->totalstudents) * 100);
            $data->mediumriskpercent = round(($data->mediumrisk / $data->totalstudents) * 100);
            $data->lowriskpercent = round(($data->lowrisk / $data->totalstudents) * 100);
        } else {
            $data->highriskpercent = 0;
            $data->mediumriskpercent = 0;
            $data->lowriskpercent = 0;
        }

        // Get students with predictions in this course, grouped by risk level
        $data->students_highrisk = $this->get_students_by_risk_level(3);
        $data->students_mediumrisk = $this->get_students_by_risk_level(2);
        $data->students_lowrisk = $this->get_students_by_risk_level(1);

        // Check if we have students in each category
        $data->has_highrisk_students = !empty($data->students_highrisk);
        $data->has_mediumrisk_students = !empty($data->students_mediumrisk);
        $data->has_lowrisk_students = !empty($data->students_lowrisk);

        // Create URL to detailed report
        $data->detailreporturl = new moodle_url('/blocks/studentperformancepredictor/reports.php', 
                                              ['id' => $this->courseid]);

        // Create chart data
        $data->haschart = true;
        $chartData = [
            'labels' => [
                get_string('highrisk_label', 'block_studentperformancepredictor'),
                get_string('mediumrisk_label', 'block_studentperformancepredictor'),
                get_string('lowrisk_label', 'block_studentperformancepredictor')
            ],
            'data' => [$data->highrisk, $data->mediumrisk, $data->lowrisk]
        ];
        $data->chartdata = json_encode($chartData);

        return $data;
    }

    /**
     * Get students by risk level with prediction details.
     *
     * @param int $risk_level Risk level (1=low, 2=medium, 3=high)
     * @return array Students with this risk level
     */
    protected function get_students_by_risk_level($risk_level) {
        global $DB, $OUTPUT;

        $sql = "SELECT p.*, u.id as userid, u.firstname, u.lastname, u.email, u.picture, u.imagealt, 
                       u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename
                FROM {block_spp_predictions} p
                JOIN {user} u ON p.userid = u.id
                JOIN {block_spp_models} m ON p.modelid = m.id
                WHERE p.courseid = :courseid 
                AND p.riskvalue = :risklevel
                AND m.active = 1
                ORDER BY u.lastname, u.firstname";

        $params = [
            'courseid' => $this->courseid,
            'risklevel' => $risk_level
        ];

        $records = $DB->get_records_sql($sql, $params);
        $students = [];

        foreach ($records as $record) {
            // Get prediction details
            $prediction_data = json_decode($record->predictiondata, true);

            // Extract risk factors from prediction data
            $risk_factors = $this->extract_risk_factors($prediction_data, $risk_level);

            // Get user picture URL
            $user_picture = new \user_picture($record);
            $user_picture->size = 35; // Size in pixels
            $picture_url = $user_picture->get_url($PAGE);

            // Create student object
            $student = new \stdClass();
            $student->id = $record->userid;
            $student->fullname = fullname($record);
            $student->picture = $user_picture->get_url($PAGE)->out(false);
            $student->passprob = round($record->passprob * 100);
            $student->profileurl = new \moodle_url('/user/view.php', 
                                                 ['id' => $record->userid, 'course' => $this->courseid]);
            $student->risk_factors = $risk_factors;
            $student->prediction_id = $record->id;
            $student->generate_url = new \moodle_url('/blocks/studentperformancepredictor/generate_prediction.php', 
                                                   ['courseid' => $this->courseid, 
                                                    'userid' => $record->userid, 
                                                    'sesskey' => sesskey()]);

            $students[] = $student;
        }

        return $students;
    }

    /**
     * Extract risk factors from prediction data.
     *
     * @param array $prediction_data Prediction data from backend
     * @param int $risk_level Risk level (1=low, 2=medium, 3=high)
     * @return array Risk factors
     */
    protected function extract_risk_factors($prediction_data, $risk_level) {
        $factors = [];

        // Check if we have backend data
        if (empty($prediction_data) || empty($prediction_data['backend'])) {
            return [get_string('nofactorsavailable', 'block_studentperformancepredictor')];
        }

        $backend_data = $prediction_data['backend'];

        // Add activity level factor
        if (isset($backend_data['features']['activity_level'])) {
            $activity = (int)$backend_data['features']['activity_level'];
            if ($risk_level == 3 && $activity < 5) {
                $factors[] = get_string('factor_low_activity', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $activity < 10) {
                $factors[] = get_string('factor_medium_activity', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $activity >= 15) {
                $factors[] = get_string('factor_high_activity', 'block_studentperformancepredictor');
            }
        }

        // Add submission factor
        if (isset($backend_data['features']['submission_count'])) {
            $submissions = (int)$backend_data['features']['submission_count'];
            if ($risk_level == 3 && $submissions < 2) {
                $factors[] = get_string('factor_low_submissions', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $submissions < 4) {
                $factors[] = get_string('factor_medium_submissions', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $submissions >= 5) {
                $factors[] = get_string('factor_high_submissions', 'block_studentperformancepredictor');
            }
        }

        // Add grade factor
        if (isset($backend_data['features']['grade_average'])) {
            $grade = (float)$backend_data['features']['grade_average'] * 100;
            if ($risk_level == 3 && $grade < 50) {
                $factors[] = get_string('factor_low_grades', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $grade < 70) {
                $factors[] = get_string('factor_medium_grades', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $grade >= 75) {
                $factors[] = get_string('factor_high_grades', 'block_studentperformancepredictor');
            }
        }

        // Add login recency factor
        if (isset($backend_data['features']['days_since_last_access'])) {
            $days = (int)$backend_data['features']['days_since_last_access'];
            if ($risk_level == 3 && $days > 7) {
                $factors[] = get_string('factor_not_logged_in', 'block_studentperformancepredictor', $days);
            } else if ($risk_level == 2 && $days > 3) {
                $factors[] = get_string('factor_few_days_since_login', 'block_studentperformancepredictor', $days);
            } else if ($risk_level == 1 && $days <= 1) {
                $factors[] = get_string('factor_recent_login', 'block_studentperformancepredictor');
            }
        }

        // Add modules accessed factor
        if (isset($backend_data['features']['current_course_modules_accessed'])) {
            $modules = (int)$backend_data['features']['current_course_modules_accessed'];
            if ($risk_level == 3 && $modules < 3) {
                $factors[] = get_string('factor_few_modules_accessed', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $modules < 6) {
                $factors[] = get_string('factor_some_modules_accessed', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $modules >= 8) {
                $factors[] = get_string('factor_many_modules_accessed', 'block_studentperformancepredictor');
            }
        }

        // If no specific factors were identified, add a default message
        if (empty($factors)) {
            if ($risk_level == 3) {
                $factors[] = get_string('factor_general_high_risk', 'block_studentperformancepredictor');
            } else if ($risk_level == 2) {
                $factors[] = get_string('factor_general_medium_risk', 'block_studentperformancepredictor');
            } else {
                $factors[] = get_string('factor_general_low_risk', 'block_studentperformancepredictor');
            }
        }

        return $factors;
    }
}