// blocks/studentperformancepredictor/amd/src/prediction_viewer.js

define(['jquery', 'core/ajax', 'core/notification', 'core/modal_factory', 'core/modal_events', 'core/str'], 
function($, Ajax, Notification, ModalFactory, ModalEvents, Str) {
    /**
     * Initialize suggestion management and prediction features.
     */
    var init = function() {
        // Handle marking suggestions as viewed
        $(document).on('click', '.spp-mark-viewed', function(e) {
            e.preventDefault();
            var button = $(this);
            var suggestionId = button.data('id');

            if (!suggestionId) {
                console.error('No suggestion ID found');
                return;
            }

            // Disable button to prevent multiple clicks
            button.prop('disabled', true);
            button.addClass('disabled');

            try {
                var promise = Ajax.call([{
                    methodname: 'block_studentperformancepredictor_mark_suggestion_viewed',
                    args: { suggestionid: suggestionId }
                }]);

                promise[0].done(function(response) {
                    if (response.status) {
                        Str.get_string('viewed', 'block_studentperformancepredictor').done(function(viewedStr) {
                            button.replaceWith('<span class="badge bg-secondary">' + viewedStr + '</span>');
                        }).fail(function() {
                            button.replaceWith('<span class="badge bg-secondary">Viewed</span>');
                        });
                    } else {
                        button.prop('disabled', false);
                        button.removeClass('disabled');
                        Notification.addNotification({ 
                            message: response.message || 'Unknown error', 
                            type: 'error' 
                        });
                    }
                }).fail(function(error) {
                    button.prop('disabled', false);
                    button.removeClass('disabled');
                    console.error('AJAX call failed:', error);
                    Notification.exception(error);
                });
            } catch (err) {
                console.error('Error calling AJAX:', err);
                button.prop('disabled', false);
                button.removeClass('disabled');
                Notification.exception(new Error('Failed to mark suggestion as viewed'));
            }
        });

        // Handle marking suggestions as completed
        $(document).on('click', '.spp-mark-completed', function(e) {
            e.preventDefault();
            var button = $(this);
            var suggestionId = button.data('id');

            if (!suggestionId) {
                console.error('No suggestion ID found');
                return;
            }

            // Disable button to prevent multiple clicks
            button.prop('disabled', true);
            button.addClass('disabled');

            try {
                var promise = Ajax.call([{
                    methodname: 'block_studentperformancepredictor_mark_suggestion_completed',
                    args: { suggestionid: suggestionId }
                }]);

                promise[0].done(function(response) {
                    if (response.status) {
                        Str.get_strings([
                            {key: 'completed', component: 'block_studentperformancepredictor'},
                            {key: 'viewed', component: 'block_studentperformancepredictor'}
                        ]).done(function(strings) {
                            button.replaceWith('<span class="badge bg-success">' + strings[0] + '</span>');
                            var viewedBtn = button.closest('.spp-suggestion-actions').find('.spp-mark-viewed');
                            if (viewedBtn.length) {
                                viewedBtn.replaceWith('<span class="badge bg-secondary">' + strings[1] + '</span>');
                            }
                        }).fail(function() {
                            button.replaceWith('<span class="badge bg-success">Completed</span>');
                            var viewedBtn = button.closest('.spp-suggestion-actions').find('.spp-mark-viewed');
                            if (viewedBtn.length) {
                                viewedBtn.replaceWith('<span class="badge bg-secondary">Viewed</span>');
                            }
                        });
                    } else {
                        button.prop('disabled', false);
                        button.removeClass('disabled');
                        Notification.addNotification({ 
                            message: response.message || 'Unknown error', 
                            type: 'error' 
                        });
                    }
                }).fail(function(error) {
                    button.prop('disabled', false);
                    button.removeClass('disabled');
                    console.error('AJAX call failed:', error);
                    Notification.exception(error);
                });
            } catch (err) {
                console.error('Error calling AJAX:', err);
                button.prop('disabled', false);
                button.removeClass('disabled');
                Notification.exception(new Error('Failed to mark suggestion as completed'));
            }
        });

        // Handle teacher refresh predictions button
        $('.spp-refresh-predictions').on('click', function(e) {
            e.preventDefault();
            var button = $(this);

            // Disable button to prevent multiple clicks
            button.prop('disabled', true);
            button.addClass('disabled');

            var courseId = button.data('course-id');
            if (!courseId) {
                courseId = $('.block_studentperformancepredictor').data('course-id');
            }

            if (!courseId) {
                button.prop('disabled', false);
                button.removeClass('disabled');
                Str.get_string('error:nocourseid', 'block_studentperformancepredictor').done(function(msg) {
                    Notification.addNotification({ message: msg, type: 'error' });
                }).fail(function() {
                    Notification.addNotification({ message: 'No course ID', type: 'error' });
                });
                return;
            }

            Str.get_strings([
                {key: 'refreshconfirmation', component: 'block_studentperformancepredictor'},
                {key: 'refresh', component: 'block_studentperformancepredictor'},
                {key: 'cancel', component: 'moodle'},
                {key: 'refreshing', component: 'block_studentperformancepredictor'}
            ]).done(function(strings) {
                ModalFactory.create({
                    type: ModalFactory.types.SAVE_CANCEL,
                    title: strings[0],
                    body: strings[0]
                }).done(function(modal) {
                    modal.setSaveButtonText(strings[1]);

                    modal.getRoot().on(ModalEvents.save, function() {
                        var loadingMessage = $('<div class="spp-loading"><i class="fa fa-spinner fa-spin"></i> ' + strings[3] + '</div>');
                        button.after(loadingMessage);

                        try {
                            var promise = Ajax.call([{
                                methodname: 'block_studentperformancepredictor_refresh_predictions',
                                args: { courseid: courseId }
                            }]);

                            promise[0].done(function(response) {
                                button.prop('disabled', false);
                                button.removeClass('disabled');
                                loadingMessage.remove();

                                if (response.status) {
                                    Notification.addNotification({ message: response.message, type: 'success' });
                                    setTimeout(function() { window.location.reload(); }, 1500);
                                } else {
                                    Notification.addNotification({ message: response.message, type: 'error' });
                                }
                            }).fail(function(error) {
                                button.prop('disabled', false);
                                button.removeClass('disabled');
                                loadingMessage.remove();
                                console.error('AJAX call failed:', error);
                                Notification.exception(error);
                            });
                        } catch (err) {
                            button.prop('disabled', false);
                            button.removeClass('disabled');
                            loadingMessage.remove();
                            console.error('Error calling AJAX:', err);
                            Notification.exception(new Error('Failed to refresh predictions'));
                        }
                    });

                    modal.getRoot().on(ModalEvents.cancel, function() {
                        button.prop('disabled', false);
                        button.removeClass('disabled');
                    });

                    modal.show();
                }).catch(function(err) {
                    console.error('Error creating modal:', err);
                    button.prop('disabled', false);
                    button.removeClass('disabled');
                    Notification.exception(err);
                });
            }).catch(function(err) {
                console.error('Error loading strings:', err);
                button.prop('disabled', false);
                button.removeClass('disabled');
                Notification.exception(err);
            });
        });

        // Handle student generate prediction button with AJAX
        $('.spp-generate-prediction, .spp-update-prediction').on('click', function(e) {
            e.preventDefault();
            var button = $(this);
            var url = button.attr('href');

            // Disable button and show loading
            button.prop('disabled', true);
            button.closest('div').find('.spp-prediction-loading').show();

            // Extract course and user IDs
            var blockElement = $('.block_studentperformancepredictor');
            var courseId = button.data('course-id') || blockElement.data('course-id');
            var userId = button.data('user-id') || blockElement.data('user-id');

            // Add parameters to URL
            if (url.indexOf('?') !== -1) {
                url += '&redirect=0';
            } else {
                url += '?redirect=0';
            }

            // Add userid and courseid if not already in the URL
            if (url.indexOf('userid=') === -1 && userId) {
                url += '&userid=' + userId;
            }

            if (url.indexOf('courseid=') === -1 && courseId) {
                url += '&courseid=' + courseId;
            }

            // Add sesskey
            url += '&sesskey=' + M.cfg.sesskey;

            // Call the endpoint
            $.ajax({
                url: url,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        Str.get_string('predictiongenerated', 'block_studentperformancepredictor').done(function(msg) {
                            Notification.addNotification({ message: msg, type: 'success' });
                        });

                        // Check if this is a student row in a table (for teacher's dashboard)
                        var studentRow = button.closest('tr');
                        if (studentRow.length) {
                            // Highlight the row to indicate update
                            studentRow.addClass('table-success');
                            setTimeout(function() {
                                studentRow.removeClass('table-success');
                            }, 3000);

                            // Update pass probability in the row
                            if (response.passprob) {
                                var probCell = studentRow.find('td:eq(1)');
                                if (probCell.length) {
                                    probCell.html('<span class="badge badge-' + 
                                                (response.riskvalue == 3 ? 'danger' : 
                                                response.riskvalue == 2 ? 'warning' : 'success') + 
                                                '">' + response.passprob + '%</span>');
                                }
                            }

                            // Don't reload the page for individual student updates
                        } else {
                            // Reload the page to show new prediction for student view
                            setTimeout(function() {
                                window.location.reload();
                            }, 1000);
                        }
                    } else {
                        // Show error
                        button.prop('disabled', false);
                        button.closest('div').find('.spp-prediction-loading').hide();

                        Notification.addNotification({ 
                            message: response.error || 'Unknown error', 
                            type: 'error' 
                        });
                    }
                },
                error: function(xhr, status, error) {
                    // Handle error
                    button.prop('disabled', false);
                    button.closest('div').find('.spp-prediction-loading').hide();
                    console.error('AJAX error:', xhr, status, error);

                    Str.get_string('predictionerror', 'block_studentperformancepredictor').done(function(msg) {
                        Notification.addNotification({ message: msg, type: 'error' });
                    });
                }
            });
        });
    };

    return {
        init: init
    };
});