// blocks/studentperformancepredictor/amd/src/teacher_dashboard.js

define(['jquery'], function($) {

    /**
     * Initialize the teacher dashboard
     */
    var init = function() {
        // Handle risk category card collapsing
        $('.spp-risk-card .card-header').on('click', function() {
            var $header = $(this);
            var $card = $header.closest('.card');
            var $collapseSection = $card.find('.collapse');
            var $indicator = $header.find('.collapse-indicator i');

            // Toggle the collapse section directly
            $collapseSection.collapse('toggle');

            // Update the collapse indicator icon on shown/hidden events
            $collapseSection.on('shown.bs.collapse', function() {
                $indicator.removeClass('fa-chevron-down').addClass('fa-chevron-up');
            });

            $collapseSection.on('hidden.bs.collapse', function() {
                $indicator.removeClass('fa-chevron-up').addClass('fa-chevron-down');
            });
        });
    };

    return {
        init: init
    };
});