// blocks/studentperformancepredictor/amd/src/chart_renderer.js

define(['jquery'], function($) {

    /**
     * Initialize the admin dashboard
     */
    var init = function() {
        // Handle risk category card collapsing
        $('.spp-risk-card .card-header').on('click', function() {
            var $header = $(this);
            var $card = $header.closest('.card');
            var $collapseSection = $card.find('.collapse');
            var $indicator = $header.find('.collapse-indicator i');

            // Toggle the collapse section directly
            $collapseSection.collapse('toggle');

            // Update the collapse indicator icon on shown/hidden events
            $collapseSection.on('shown.bs.collapse', function() {
                $indicator.removeClass('fa-chevron-down').addClass('fa-chevron-up');
            });

            $collapseSection.on('hidden.bs.collapse', function() {
                $indicator.removeClass('fa-chevron-up').addClass('fa-chevron-down');
            });
        });
    };

    return {
        init: init
    };
});
define(['jquery', 'core/ajax', 'core/str', 'core/notification', 'core/modal_factory', 'core/modal_events'], 
function($, Ajax, Str, Notification, ModalFactory, ModalEvents) {

    /**
     * Initialize admin interface.
     * 
     * @param {int} courseId Course ID
     */
    var init = function(courseId) {
        try {
            // Handle dataset upload form
            $('#spp-dataset-upload-form').on('submit', function(e) {
                e.preventDefault();

                // Validate form
                var form = $(this)[0];
                if (!form.checkValidity()) {
                    if (typeof form.reportValidity === 'function') {
                        form.reportValidity();
                    }
                    return;
                }

                var formData = new FormData(form);
                var submitButton = $(this).find('input[type="submit"]');
                var originalText = submitButton.val();
                submitButton.prop('disabled', true);

                // Load 'uploading' string asynchronously for button and status
                Str.get_string('uploading', 'moodle').done(function(uploadingStr) {
                    submitButton.val(uploadingStr);
                    $('#spp-upload-status').html(
                        '<div class="spp-loading"><i class="fa fa-spinner fa-spin"></i>' + uploadingStr + '</div>'
                    );
                }).fail(function() {
                    submitButton.val('Uploading...');
                    $('#spp-upload-status').html(
                        '<div class="spp-loading"><i class="fa fa-spinner fa-spin"></i>Uploading...</div>'
                    );
                });

                $.ajax({
                    url: M.cfg.wwwroot + '/blocks/studentperformancepredictor/admin/upload_dataset.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        submitButton.prop('disabled', false);
                        submitButton.val(originalText);
                        $('#spp-upload-status').empty();

                        try {
                            // Properly handle response which might be string or object
                            var responseData;
                            if (typeof response === 'string') {
                                try {
                                    responseData = JSON.parse(response);
                                } catch (e) {
                                    console.error('Invalid JSON response', response);
                                    Notification.exception(new Error('Invalid server response'));
                                    return;
                                }
                            } else {
                                responseData = response;
                            }

                            if (responseData && responseData.success) {
                                // Show success message
                                var msg = responseData.message;
                                if (!msg) {
                                    Str.get_string('datasetsaved', 'block_studentperformancepredictor').done(function(s) {
                                        Notification.addNotification({ message: s, type: 'success' });
                                    });
                                } else {
                                    Notification.addNotification({ message: msg, type: 'success' });
                                }
                                setTimeout(function() { window.location.reload(); }, 1500);
                            } else {
                                var msg = responseData ? responseData.message : '';
                                if (!msg) {
                                    Str.get_string('datasetsaveerror', 'block_studentperformancepredictor').done(function(s) {
                                        Notification.addNotification({ message: s, type: 'error' });
                                    });
                                } else {
                                    Notification.addNotification({ message: msg, type: 'error' });
                                }
                            }
                        } catch (e) {
                            console.error('Error handling response:', e);
                            Str.get_string('datasetsaveerror', 'block_studentperformancepredictor').done(function(s) {
                                Notification.addNotification({ message: s, type: 'error' });
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX error:', status, error);
                        submitButton.prop('disabled', false);
                        submitButton.val(originalText);
                        $('#spp-upload-status').empty();

                        // Get response error message if available
                        var errorMessage = error;
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (response && response.message) {
                                errorMessage = response.message;
                            }
                        } catch (e) {
                            // Use default error message if JSON parsing fails
                        }

                        Str.get_string('uploaderror', 'block_studentperformancepredictor').done(function(s) {
                            Notification.addNotification({ message: s + ': ' + errorMessage, type: 'error' });
                        });
                    }
                });
            });

            // Handle model training form
            $('#spp-train-model-form').on('submit', function(e) {
                e.preventDefault();
                var datasetId = $('#datasetid').val();
                var algorithm = $('#algorithm').val();
                if (!datasetId) {
                    Str.get_string('selectdataset', 'block_studentperformancepredictor').done(function(s) {
                        Notification.addNotification({ message: s, type: 'error' });
                    });
                    return;
                }
                var submitButton = $(this).find('input[type="submit"]');
                var originalText = submitButton.val();
                submitButton.prop('disabled', true);
                Str.get_string('training', 'block_studentperformancepredictor').done(function(trainingStr) {
                    submitButton.val(trainingStr);
                });

                // Using traditional form submission for better file handling compatibility
                var form = $(this)[0];
                form.submit();
            });

            // Handle dataset deletion
            $('.spp-delete-dataset').on('click', function(e) {
                e.preventDefault();

                var button = $(this);
                var datasetId = button.data('dataset-id');

                button.prop('disabled', true);

                // Confirm deletion.
                Str.get_strings([
                    {key: 'confirmdeletedataset', component: 'block_studentperformancepredictor'},
                    {key: 'delete', component: 'core'},
                    {key: 'cancel', component: 'core'}
                ]).done(function(strings) {
                    ModalFactory.create({
                        type: ModalFactory.types.SAVE_CANCEL,
                        title: strings[0],
                        body: strings[0]
                    }).done(function(modal) {
                        modal.setSaveButtonText(strings[1]);

                        // When the user confirms deletion
                        modal.getRoot().on(ModalEvents.save, function() {
                            $.ajax({
                                url: M.cfg.wwwroot + '/blocks/studentperformancepredictor/admin/ajax_delete_dataset.php',
                                type: 'POST',
                                data: {
                                    datasetid: datasetId,
                                    courseid: courseId,
                                    sesskey: M.cfg.sesskey
                                },
                                dataType: 'json',
                                success: function(response) {
                                    if (response.success) {
                                        // Reload page to update dataset list.
                                        window.location.reload();
                                    } else {
                                        button.prop('disabled', false);

                                        // Show error message.
                                        Notification.addNotification({
                                            message: response.message,
                                            type: 'error'
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    button.prop('disabled', false);

                                    // Try to parse error message from response
                                    var errorMessage = error;
                                    try {
                                        var response = JSON.parse(xhr.responseText);
                                        if (response && response.message) {
                                            errorMessage = response.message;
                                        }
                                    } catch (e) {
                                        // Use default error message
                                    }

                                    // Show error message.
                                    Str.get_string('actionerror', 'block_studentperformancepredictor').done(function(s) {
                                        Notification.addNotification({
                                            message: s + ': ' + errorMessage,
                                            type: 'error'
                                        });
                                    });
                                }
                            });
                        });

                        // When the modal is cancelled, re-enable the button
                        modal.getRoot().on(ModalEvents.cancel, function() {
                            button.prop('disabled', false);
                        });

                        modal.show();
                    }).catch(function(error) {
                        console.error('Error creating modal:', error);
                        button.prop('disabled', false);
                    });
                }).catch(function(error) {
                    console.error('Error loading strings:', error);
                    button.prop('disabled', false);
                });
            });

            // Handle model toggle (activate/deactivate)
            $('.spp-toggle-model-status').on('click', function(e) {
                e.preventDefault();

                var button = $(this);
                var modelId = button.data('model-id');
                var isActive = button.data('is-active');

                button.prop('disabled', true);

                // Confirm action based on current state
                var confirmKey = isActive ? 'confirmdeactivate' : 'confirmactivate';

                Str.get_strings([
                    {key: confirmKey, component: 'block_studentperformancepredictor'},
                    {key: isActive ? 'deactivate' : 'activate', component: 'block_studentperformancepredictor'},
                    {key: 'cancel', component: 'core'}
                ]).done(function(strings) {
                    ModalFactory.create({
                        type: ModalFactory.types.SAVE_CANCEL,
                        title: strings[0],
                        body: strings[0]
                    }).done(function(modal) {
                        modal.setSaveButtonText(strings[1]);

                        // When user confirms
                        modal.getRoot().on(ModalEvents.save, function() {
                            $.ajax({
                                url: M.cfg.wwwroot + '/blocks/studentperformancepredictor/admin/ajax_toggle_model.php',
                                type: 'POST',
                                data: {
                                    modelid: modelId,
                                    courseid: courseId,
                                    active: isActive ? 0 : 1,
                                    sesskey: M.cfg.sesskey
                                },
                                dataType: 'json',
                                success: function(response) {
                                    if (response.success) {
                                        window.location.reload();
                                    } else {
                                        button.prop('disabled', false);
                                        Notification.addNotification({
                                            message: response.message,
                                            type: 'error'
                                        });
                                    }
                                },
                                error: function(xhr, status, error) {
                                    button.prop('disabled', false);

                                    var errorMessage = error;
                                    try {
                                        var response = JSON.parse(xhr.responseText);
                                        if (response && response.message) {
                                            errorMessage = response.message;
                                        }
                                    } catch (e) {
                                        // Use default message
                                    }

                                    Str.get_string('actionerror', 'block_studentperformancepredictor').done(function(s) {
                                        Notification.addNotification({
                                            message: s + ': ' + errorMessage,
                                            type: 'error'
                                        });
                                    });
                                }
                            });
                        });

                        // When cancelled
                        modal.getRoot().on(ModalEvents.cancel, function() {
                            button.prop('disabled', false);
                        });

                        modal.show();
                    });
                });
            });

        } catch (e) {
            console.error('Error initializing admin interface:', e);
            // Show a generic error notification
            Str.get_string('jserror', 'moodle').done(function(s) {
                Notification.exception(new Error(s + ': ' + e.message));
            });
        }
    };

    return {
        init: init
    };
});
define(['jquery', 'core/chartjs', 'core/str'], function($, Chart, Str) {

    /**
     * Initialize student prediction chart.
     */
    var init = function() {
        var chartElement = document.getElementById('spp-prediction-chart');
        if (!chartElement) {
            return;
        }

        try {
            var chartData = {};
            try {
                chartData = JSON.parse(chartElement.dataset.chartdata || '{"passprob":0,"failprob":100}');
            } catch (e) {
                console.error('Error parsing chart data:', e);
                chartData = {"passprob":0,"failprob":100};
            }

            var ctx = chartElement.getContext('2d');

            Str.get_strings([
                {key: 'passingchance', component: 'block_studentperformancepredictor'},
                {key: 'failingchance', component: 'block_studentperformancepredictor'}
            ]).done(function(labels) {
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: labels,
                        datasets: [{
                            data: [chartData.passprob, chartData.failprob],
                            backgroundColor: [
                                '#28a745', // Green for passing
                                '#dc3545'  // Red for failing
                            ],
                            borderWidth: 1,
                            hoverBackgroundColor: [
                                '#218838', // Darker green on hover
                                '#c82333'  // Darker red on hover
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        cutoutPercentage: 70,
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 15,
                                boxWidth: 12
                            }
                        },
                        tooltips: {
                            callbacks: {
                                label: function(tooltipItem, data) {
                                    var dataset = data.datasets[tooltipItem.datasetIndex];
                                    var value = dataset.data[tooltipItem.index];
                                    return data.labels[tooltipItem.index] + ': ' + value + '%';
                                }
                            }
                        },
                        animation: {
                            animateScale: true,
                            animateRotate: true,
                            duration: 1000
                        }
                    }
                });
            }).fail(function() {
                // Fallback labels if string loading fails
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Passing', 'Failing'],
                        datasets: [{
                            data: [chartData.passprob, chartData.failprob],
                            backgroundColor: ['#28a745', '#dc3545'],
                            borderWidth: 1,
                            hoverBackgroundColor: ['#218838', '#c82333']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        cutoutPercentage: 70
                    }
                });
            });
        } catch (e) {
            console.error('Error initializing chart:', e);
            Str.get_string('charterror', 'block_studentperformancepredictor').done(function(msg) {
                chartElement.innerHTML = '<div class="alert alert-warning">' + msg + '</div>';
            }).fail(function() {
                chartElement.innerHTML = '<div class="alert alert-warning">Chart error</div>';
            });
        }
    };

    /**
     * Initialize teacher view chart.
     */
    var initTeacherChart = function() {
        var chartElement = document.getElementById('spp-teacher-chart');
        if (!chartElement) {
            return;
        }

        try {
            var chartData = {};
            try {
                chartData = JSON.parse(chartElement.dataset.chartdata || '{"labels":[],"data":[]}');
            } catch (e) {
                console.error('Error parsing chart data:', e);
                chartData = {"labels":[],"data":[]};
            }

            var ctx = chartElement.getContext('2d');

            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: chartData.labels,
                    datasets: [{
                        data: chartData.data,
                        backgroundColor: [
                            '#dc3545',  // High risk - Red
                            '#ffc107',  // Medium risk - Yellow
                            '#28a745'   // Low risk - Green
                        ],
                        borderWidth: 1,
                        hoverBackgroundColor: [
                            '#c82333',  // Darker red on hover
                            '#e0a800',  // Darker yellow on hover
                            '#218838'   // Darker green on hover
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            boxWidth: 12
                        }
                    },
                    tooltips: {
                        callbacks: {
                            label: function(tooltipItem, data) {
                                var dataset = data.datasets[tooltipItem.datasetIndex];
                                var total = dataset.data.reduce(function(previousValue, currentValue) {
                                    return previousValue + currentValue;
                                });
                                var currentValue = dataset.data[tooltipItem.index];
                                var percentage = Math.round((currentValue / total) * 100);
                                return data.labels[tooltipItem.index] + ': ' + currentValue + ' (' + percentage + '%)';
                            }
                        }
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true,
                        duration: 1000
                    }
                }
            });
        } catch (e) {
            console.error('Error initializing teacher chart:', e);
            Str.get_string('charterror', 'block_studentperformancepredictor').done(function(msg) {
                chartElement.innerHTML = '<div class="alert alert-warning">' + msg + '</div>';
            }).fail(function() {
                chartElement.innerHTML = '<div class="alert alert-warning">Chart error</div>';
            });
        }
    };

    /**
     * Initialize admin view chart.
     */
    var initAdminChart = function() {
        var chartElement = document.getElementById('spp-admin-chart');
        if (!chartElement) {
            return;
        }

        try {
            var chartData = {};
            try {
                chartData = JSON.parse(chartElement.dataset.chartdata || '{"labels":[],"data":[]}');
            } catch (e) {
                console.error('Error parsing chart data:', e);
                chartData = {"labels":[],"data":[]};
            }

            var ctx = chartElement.getContext('2d');

            Str.get_string('studentcount', 'block_studentperformancepredictor').done(function(label) {
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: chartData.labels,
                        datasets: [{
                            label: label,
                            data: chartData.data,
                            backgroundColor: [
                                '#dc3545',  // High risk - Red
                                '#ffc107',  // Medium risk - Yellow
                                '#28a745'   // Low risk - Green
                            ],
                            borderWidth: 1,
                            hoverBackgroundColor: [
                                '#c82333',  // Darker red on hover
                                '#e0a800',  // Darker yellow on hover
                                '#218838'   // Darker green on hover
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                    precision: 0
                                },
                                gridLines: {
                                    drawBorder: true,
                                    color: 'rgba(0, 0, 0, 0.1)'
                                }
                            }],
                            xAxes: [{
                                gridLines: {
                                    display: false
                                }
                            }]
                        },
                        legend: {
                            display: false
                        },
                        tooltips: {
                            callbacks: {
                                label: function(tooltipItem, data) {
                                    var dataset = data.datasets[tooltipItem.datasetIndex];
                                    var total = dataset.data.reduce(function(previousValue, currentValue) {
                                        return previousValue + currentValue;
                                    });
                                    var currentValue = dataset.data[tooltipItem.index];
                                    var percentage = Math.round((currentValue / total) * 100);
                                    return data.labels[tooltipItem.index] + ': ' + currentValue + ' (' + percentage + '%)';
                                }
                            }
                        },
                        animation: {
                            duration: 1000,
                            easing: 'easeOutQuart'
                        }
                    }
                });
            }).fail(function() {
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: chartData.labels,
                        datasets: [{
                            label: 'Student count',
                            data: chartData.data,
                            backgroundColor: ['#dc3545', '#ffc107', '#28a745'],
                            borderWidth: 1,
                            hoverBackgroundColor: ['#c82333', '#e0a800', '#218838']
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false
                    }
                });
            });
        } catch (e) {
            console.error('Error initializing admin chart:', e);
            Str.get_string('charterror', 'block_studentperformancepredictor').done(function(msg) {
                chartElement.innerHTML = '<div class="alert alert-warning">' + msg + '</div>';
            }).fail(function() {
                chartElement.innerHTML = '<div class="alert alert-warning">Chart error</div>';
            });
        }
    };

    return {
        init: init,
        initTeacherChart: initTeacherChart,
        initAdminChart: initAdminChart
    };
});
