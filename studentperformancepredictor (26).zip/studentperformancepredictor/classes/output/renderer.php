<?php
// blocks/studentperformancepredictor/classes/output/renderer.php

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

use plugin_renderer_base;

/**
 * Renderer for Student Performance Predictor block.
 */
class renderer extends plugin_renderer_base {
    /**
     * Renders student_view.
     *
     * @param student_view $studentview The student view object
     * @return string HTML
     */
    public function render_student_view(student_view $studentview) {
        $data = $studentview->export_for_template($this);
        return $this->render_from_template('block_studentperformancepredictor/student_dashboard', $data);
    }

    /**
     * Renders teacher_view.
     *
     * @param teacher_view $teacherview The teacher view object
     * @return string HTML
     */
    public function render_teacher_view(teacher_view $teacherview) {
        $data = $teacherview->export_for_template($this);

        // Initialize teacher dashboard JavaScript
        $this->page->requires->js_call_amd('block_studentperformancepredictor/teacher_dashboard', 'init');

        return $this->render_from_template('block_studentperformancepredictor/teacher_dashboard', $data);
    }

    /**
     * Renders admin_view.
     *
     * @param admin_view $adminview The admin view object
     * @return string HTML
     */
    public function render_admin_view(admin_view $adminview) {
        $data = $adminview->export_for_template($this);

        // Initialize admin dashboard JavaScript
        $this->page->requires->js_call_amd('block_studentperformancepredictor/admin_dashboard', 'init');

        // Initialize chart renderer for the admin view
        $this->page->requires->js_call_amd('block_studentperformancepredictor/chart_renderer', 'initAdminChart');

        return $this->render_from_template('block_studentperformancepredictor/admin_dashboard', $data);
    }
}