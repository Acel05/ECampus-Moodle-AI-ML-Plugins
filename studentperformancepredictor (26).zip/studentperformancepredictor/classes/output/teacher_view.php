<?php
// blocks/studentperformancepredictor/classes/output/teacher_view.php

namespace block_studentperformancepredictor\output;

defined('MOODLE_INTERNAL') || die();

// Add this line to include lib.php which contains the function definitions
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

/**
 * Teacher view class for the teacher dashboard.
 *
 * This class prepares data for the teacher dashboard template.
 */
class teacher_view implements \renderable, \templatable {
    /** @var int Course ID */
    protected $courseid;

    /**
     * Constructor.
     *
     * @param int $courseid Course ID
     */
    public function __construct($courseid) {
        $this->courseid = $courseid;
    }

    /**
     * Export data for template.
     *
     * @param \renderer_base $output The renderer
     * @return \stdClass Data for template
     */
    public function export_for_template(\renderer_base $output) {
        global $CFG, $DB, $USER;

        $data = new \stdClass();
        $data->heading = get_string('courseperformance', 'block_studentperformancepredictor');
        $data->courseid = $this->courseid;

        // Get course info
        $course = get_course($this->courseid);
        $data->coursename = format_string($course->fullname);
        $data->courseshortname = format_string($course->shortname);

        // Get teacher's courses for selector
        $teachercourses = [];
        $courses = enrol_get_users_courses($USER->id);
        foreach ($courses as $c) {
            if ($c->id == SITEID) {
                continue;
            }
            $context = \context_course::instance($c->id);
            if (has_capability('block/studentperformancepredictor:viewallpredictions', $context)) {
                $teachercourses[] = [
                    'id' => $c->id,
                    'name' => format_string($c->fullname),
                    'shortname' => format_string($c->shortname),
                    'selected' => ($c->id == $this->courseid)
                ];
            }
        }

        $data->has_multiple_courses = count($teachercourses) > 1;
        $data->teachercourses = $teachercourses;

        // Check if there's an active model - use global namespace function
        $data->hasmodel = \block_studentperformancepredictor_has_active_model($this->courseid);

        if (!$data->hasmodel) {
            $data->nomodeltext = get_string('noactivemodel', 'block_studentperformancepredictor');
            return $data;
        }

        // Get risk statistics - use global namespace function
        $riskStats = \block_studentperformancepredictor_get_course_risk_stats($this->courseid);

        $data->totalstudents = $riskStats->total;
        $data->highrisk = $riskStats->highrisk;
        $data->mediumrisk = $riskStats->mediumrisk;
        $data->lowrisk = $riskStats->lowrisk;
        $data->missing_predictions = $riskStats->missing ?? 0;

        // Calculate percentages
        if ($data->totalstudents > 0) {
            $data->highriskpercent = round(($data->highrisk / $data->totalstudents) * 100);
            $data->mediumriskpercent = round(($data->mediumrisk / $data->totalstudents) * 100);
            $data->lowriskpercent = round(($data->lowrisk / $data->totalstudents) * 100);
        } else {
            $data->highriskpercent = 0;
            $data->mediumriskpercent = 0;
            $data->lowriskpercent = 0;
        }

        // Get the last refresh time
        $lastrefresh = get_config('block_studentperformancepredictor', 'lastrefresh_' . $this->courseid);
        $data->has_lastrefresh = !empty($lastrefresh);
        if ($data->has_lastrefresh) {
            $data->lastrefresh = userdate($lastrefresh);
            $data->lastrefresh_ago = format_time(time() - $lastrefresh);
        }

        // Get students with predictions in this course, grouped by risk level
        $data->students_highrisk = $this->get_students_by_risk_level(3);
        $data->students_mediumrisk = $this->get_students_by_risk_level(2);
        $data->students_lowrisk = $this->get_students_by_risk_level(1);

        // Get students with no predictions
        $data->students_missing = $this->get_students_without_predictions();

        // Check if we have students in each category
        $data->has_highrisk_students = !empty($data->students_highrisk);
        $data->has_mediumrisk_students = !empty($data->students_mediumrisk);
        $data->has_lowrisk_students = !empty($data->students_lowrisk);
        $data->has_missing_predictions = !empty($data->students_missing);

        // Create URL to detailed report
        $data->detailreporturl = new \moodle_url('/blocks/studentperformancepredictor/reports.php', 
                                              ['courseid' => $this->courseid]);

        // Create URL for refreshing predictions
        $data->refreshpredictionsurl = new \moodle_url('/blocks/studentperformancepredictor/admin/refreshpredictions.php', 
                                              ['courseid' => $this->courseid]);

        // Create chart data
        $data->haschart = true;
        $chartData = [
            'labels' => [
                get_string('highrisk_label', 'block_studentperformancepredictor'),
                get_string('mediumrisk_label', 'block_studentperformancepredictor'),
                get_string('lowrisk_label', 'block_studentperformancepredictor')
            ],
            'data' => [$data->highrisk, $data->mediumrisk, $data->lowrisk]
        ];
        $data->chartdata = json_encode($chartData);

        return $data;
    }

    /**
     * Get students by risk level with prediction details.
     *
     * @param int $risk_level Risk level (1=low, 2=medium, 3=high)
     * @return array Students with this risk level
     */
    protected function get_students_by_risk_level($risk_level) {
        global $DB, $PAGE;

        $sql = "SELECT p.*, u.id as userid, u.firstname, u.lastname, u.email, u.picture, u.imagealt, 
                       u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename,
                       m.courseid as modelcourseid, m.id as modelid
                FROM {block_spp_predictions} p
                JOIN {user} u ON p.userid = u.id
                JOIN {block_spp_models} m ON p.modelid = m.id
                WHERE p.courseid = :courseid 
                AND p.riskvalue = :risklevel
                AND m.active = 1
                ORDER BY u.lastname, u.firstname";

        $params = [
            'courseid' => $this->courseid,
            'risklevel' => $risk_level
        ];

        $records = $DB->get_records_sql($sql, $params);
        $students = [];

        foreach ($records as $record) {
            // Get prediction details
            $prediction_data = json_decode($record->predictiondata, true);

            // Extract risk factors from prediction data
            $risk_factors = $this->extract_risk_factors($prediction_data, $risk_level);

            // Get user picture URL
            $user_picture = new \user_picture($record);
            $user_picture->size = 35; // Size in pixels

            // Create student object
            $student = new \stdClass();
            $student->id = $record->userid;
            $student->fullname = fullname($record);
            $student->picture = $user_picture->get_url($PAGE)->out(false);
            $student->passprob = round($record->passprob * 100);
            $student->profileurl = new \moodle_url('/user/view.php', 
                                                 ['id' => $record->userid, 'course' => $this->courseid]);
            $student->risk_factors = $risk_factors;
            $student->prediction_id = $record->id;
            $student->generate_url = new \moodle_url('/blocks/studentperformancepredictor/generate_prediction.php', 
                                                   ['courseid' => $this->courseid, 
                                                    'userid' => $record->userid, 
                                                    'sesskey' => sesskey()]);

            // Flag if this is from a global model
            $student->isglobalmodel = ($record->modelcourseid == 0);

            // Get incomplete activities
            $student->incomplete_activities = $this->get_student_incomplete_activities($record->userid);
            $student->has_incomplete_activities = !empty($student->incomplete_activities);

            // Get grade information
            $student->grade = $this->get_student_course_grade($record->userid);

            // Get last access information
            $student->lastaccess = $this->get_student_last_access($record->userid);

            $students[] = $student;
        }

        return $students;
    }

    /**
     * Get students without predictions
     * 
     * @return array Students without predictions
     */
    protected function get_students_without_predictions() {
        global $DB, $PAGE;

        $sql = "SELECT DISTINCT u.id, u.firstname, u.lastname, u.email, u.picture, u.imagealt, 
                       u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename
                FROM {user} u
                JOIN {user_enrolments} ue ON ue.userid = u.id
                JOIN {enrol} e ON e.id = ue.enrolid
                LEFT JOIN {block_spp_predictions} p ON p.userid = u.id AND p.courseid = :courseid
                WHERE e.courseid = :courseid2
                AND p.id IS NULL
                ORDER BY u.lastname, u.firstname";

        $params = [
            'courseid' => $this->courseid,
            'courseid2' => $this->courseid
        ];

        $records = $DB->get_records_sql($sql, $params);
        $students = [];

        foreach ($records as $record) {
            // Get user picture URL
            $user_picture = new \user_picture($record);
            $user_picture->size = 35; // Size in pixels

            // Create student object
            $student = new \stdClass();
            $student->id = $record->id;
            $student->fullname = fullname($record);
            $student->picture = $user_picture->get_url($PAGE)->out(false);
            $student->profileurl = new \moodle_url('/user/view.php', 
                                                 ['id' => $record->id, 'course' => $this->courseid]);
            $student->generate_url = new \moodle_url('/blocks/studentperformancepredictor/generate_prediction.php', 
                                                   ['courseid' => $this->courseid, 
                                                    'userid' => $record->id, 
                                                    'sesskey' => sesskey()]);

            // Get incomplete activities
            $student->incomplete_activities = $this->get_student_incomplete_activities($record->id);
            $student->has_incomplete_activities = !empty($student->incomplete_activities);

            // Get grade information
            $student->grade = $this->get_student_course_grade($record->id);

            // Get last access information
            $student->lastaccess = $this->get_student_last_access($record->id);

            $students[] = $student;
        }

        return $students;
    }

    /**
     * Get student incomplete activities
     * 
     * @param int $userid User ID
     * @return array Incomplete activities
     */
    protected function get_student_incomplete_activities($userid) {
        global $DB;

        $course = get_course($this->courseid);
        $modinfo = get_fast_modinfo($course, $userid);
        $completion = new \completion_info($course);
        $activities = [];

        foreach ($modinfo->get_cms() as $cm) {
            if (!$cm->uservisible || $cm->modname == 'label') {
                continue;
            }

            if ($completion->is_enabled($cm)) {
                $data = $completion->get_data($cm, false, $userid);
                if ($data->completionstate != COMPLETION_COMPLETE && $data->completionstate != COMPLETION_COMPLETE_PASS) {
                    $activities[] = [
                        'name' => $cm->name,
                        'url' => $cm->url->out(false),
                        'modname' => $cm->modname,
                        'icon' => $cm->get_icon_url()->out(false)
                    ];
                }
            }
        }

        return $activities;
    }

    /**
     * Get student course grade
     * 
     * @param int $userid User ID
     * @return object Grade information
     */
    protected function get_student_course_grade($userid) {
        global $DB;

        $result = new \stdClass();
        $result->grade = null;
        $result->grademax = 100;
        $result->percentage = 0;
        $result->hasgrades = false;

        // Get course grade
        $grade = grade_get_course_grade($userid, $this->courseid);
        if ($grade && isset($grade->grade) && $grade->grade !== null) {
            $result->grade = $grade->grade;
            $result->grademax = $grade->grade_item->grademax;
            $result->percentage = ($grade->grade / $grade->grade_item->grademax) * 100;
            $result->hasgrades = true;

            // Determine grade class based on percentage
            if ($result->percentage >= 70) {
                $result->gradeclass = 'text-success';
            } else if ($result->percentage >= 50) {
                $result->gradeclass = 'text-warning';
            } else {
                $result->gradeclass = 'text-danger';
            }
        }

        return $result;
    }

    /**
     * Get student last access
     * 
     * @param int $userid User ID
     * @return object Last access information
     */
    protected function get_student_last_access($userid) {
        global $DB;

        $result = new \stdClass();
        $result->timestamp = 0;
        $result->timeago = '';
        $result->hasaccess = false;

        // Get last course access
        $lastaccess = $DB->get_record('user_lastaccess', [
            'userid' => $userid,
            'courseid' => $this->courseid
        ]);

        if ($lastaccess) {
            $result->timestamp = $lastaccess->timeaccess;
            $result->timeago = format_time(time() - $lastaccess->timeaccess);
            $result->hasaccess = true;

            // Determine access class based on time
            $dayspassed = (time() - $lastaccess->timeaccess) / (60 * 60 * 24);
            if ($dayspassed <= 3) {
                $result->accessclass = 'text-success';
            } else if ($dayspassed <= 7) {
                $result->accessclass = 'text-warning';
            } else {
                $result->accessclass = 'text-danger';
            }
        }

        return $result;
    }

    /**
     * Extract risk factors from prediction data.
     *
     * @param array $prediction_data Prediction data from backend
     * @param int $risk_level Risk level (1=low, 2=medium, 3=high)
     * @return array Risk factors
     */
    protected function extract_risk_factors($prediction_data, $risk_level) {
        $factors = [];

        // Check if we have backend data
        if (empty($prediction_data) || empty($prediction_data['backend'])) {
            return [get_string('nofactorsavailable', 'block_studentperformancepredictor')];
        }

        $backend_data = $prediction_data['backend'];

        // Add activity level factor
        if (isset($backend_data['features']['activity_level'])) {
            $activity = (int)$backend_data['features']['activity_level'];
            if ($risk_level == 3 && $activity < 5) {
                $factors[] = get_string('factor_low_activity', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $activity < 10) {
                $factors[] = get_string('factor_medium_activity', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $activity >= 15) {
                $factors[] = get_string('factor_high_activity', 'block_studentperformancepredictor');
            }
        }

        // Add submission factor
        if (isset($backend_data['features']['submission_count'])) {
            $submissions = (int)$backend_data['features']['submission_count'];
            if ($risk_level == 3 && $submissions < 2) {
                $factors[] = get_string('factor_low_submissions', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $submissions < 4) {
                $factors[] = get_string('factor_medium_submissions', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $submissions >= 5) {
                $factors[] = get_string('factor_high_submissions', 'block_studentperformancepredictor');
            }
        }

        // Add grade factor
        if (isset($backend_data['features']['grade_average'])) {
            $grade = (float)$backend_data['features']['grade_average'] * 100;
            if ($risk_level == 3 && $grade < 50) {
                $factors[] = get_string('factor_low_grades', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $grade < 70) {
                $factors[] = get_string('factor_medium_grades', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $grade >= 75) {
                $factors[] = get_string('factor_high_grades', 'block_studentperformancepredictor');
            }
        }

        // Add login recency factor
        if (isset($backend_data['features']['days_since_last_access'])) {
            $days = (int)$backend_data['features']['days_since_last_access'];
            if ($risk_level == 3 && $days > 7) {
                $factors[] = get_string('factor_not_logged_in', 'block_studentperformancepredictor', $days);
            } else if ($risk_level == 2 && $days > 3) {
                $factors[] = get_string('factor_few_days_since_login', 'block_studentperformancepredictor', $days);
            } else if ($risk_level == 1 && $days <= 1) {
                $factors[] = get_string('factor_recent_login', 'block_studentperformancepredictor');
            }
        }

        // Add modules accessed factor
        if (isset($backend_data['features']['current_course_modules_accessed'])) {
            $modules = (int)$backend_data['features']['current_course_modules_accessed'];
            if ($risk_level == 3 && $modules < 3) {
                $factors[] = get_string('factor_few_modules_accessed', 'block_studentperformancepredictor');
            } else if ($risk_level == 2 && $modules < 6) {
                $factors[] = get_string('factor_some_modules_accessed', 'block_studentperformancepredictor');
            } else if ($risk_level == 1 && $modules >= 8) {
                $factors[] = get_string('factor_many_modules_accessed', 'block_studentperformancepredictor');
            }
        }

        // If no specific factors were identified, add a default message
        if (empty($factors)) {
            if ($risk_level == 3) {
                $factors[] = get_string('factor_general_high_risk', 'block_studentperformancepredictor');
            } else if ($risk_level == 2) {
                $factors[] = get_string('factor_general_medium_risk', 'block_studentperformancepredictor');
            } else {
                $factors[] = get_string('factor_general_low_risk', 'block_studentperformancepredictor');
            }
        }

        return $factors;
    }
}