<?php
// blocks/studentperformancepredictor/admin/viewmodel.php

require_once('../../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters
$id = required_param('id', PARAM_INT); // Model ID
$courseid = required_param('courseid', PARAM_INT);

// Set up context
$course = get_course($courseid);
$context = context_course::instance($courseid);

// Check permissions
require_login($course);
require_capability('block/studentperformancepredictor:managemodels', $context);

// Get model
$model = $DB->get_record('block_spp_models', ['id' => $id], '*', MUST_EXIST);

// Set up page
$PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/admin/viewmodel.php', ['id' => $id, 'courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('modeldetails', 'block_studentperformancepredictor'));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_pagelayout('standard');

// Algorithm options for display
$algorithmoptions = [
    'randomforest' => get_string('algorithm_randomforest', 'block_studentperformancepredictor'),
    'logisticregression' => get_string('algorithm_logisticregression', 'block_studentperformancepredictor'),
    'svm' => get_string('algorithm_svm', 'block_studentperformancepredictor'),
    'decisiontree' => get_string('algorithm_decisiontree', 'block_studentperformancepredictor'),
    'knn' => get_string('algorithm_knn', 'block_studentperformancepredictor')
];

// Output starts here
echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('modeldetails', 'block_studentperformancepredictor') . ': ' . format_string($model->modelname));

// Model basic info
$table = new html_table();
$table->attributes['class'] = 'generaltable';
$table->head = [
    get_string('property', 'block_studentperformancepredictor'),
    get_string('value', 'block_studentperformancepredictor')
];
$table->data = [];

$table->data[] = [get_string('modelname', 'block_studentperformancepredictor'), format_string($model->modelname)];
$table->data[] = [get_string('algorithm', 'block_studentperformancepredictor'), isset($algorithmoptions[$model->algorithmtype]) ? 
    $algorithmoptions[$model->algorithmtype] : $model->algorithmtype];
$table->data[] = [get_string('created', 'block_studentperformancepredictor'), userdate($model->timecreated)];
$table->data[] = [get_string('status', 'block_studentperformancepredictor'), 
    $model->active ? get_string('active', 'block_studentperformancepredictor') : get_string('inactive', 'block_studentperformancepredictor')];
$table->data[] = [get_string('trainstatus', 'block_studentperformancepredictor'), ucfirst($model->trainstatus)];

echo html_writer::table($table);

// Display all available metrics
if (!empty($model->metrics)) {
    $metrics = json_decode($model->metrics, true);

    echo html_writer::start_div('model-metrics card p-3 mt-4');
    echo html_writer::tag('h4', get_string('modelmetrics', 'block_studentperformancepredictor'));

    echo html_writer::start_tag('ul', ['class' => 'list-group']);

    // Accuracy with cross-validation
    $acc_data = new stdClass();
    $acc_data->accuracy = round(($metrics['accuracy'] ?? 0) * 100, 2);
    $acc_data->cv_accuracy = round(($metrics['cv_accuracy'] ?? 0) * 100, 2);
    echo html_writer::tag('li', 
        get_string('modelaccuracydetail', 'block_studentperformancepredictor', $acc_data),
        ['class' => 'list-group-item' . (($metrics['overfitting_warning'] ?? false) ? ' list-group-item-warning' : '')]);

    // Other metrics
    if (isset($metrics['precision'])) {
        echo html_writer::tag('li', get_string('metrics_precision', 'block_studentperformancepredictor') . ': ' . 
            round($metrics['precision'] * 100, 2) . '%', ['class' => 'list-group-item']);
    }
    if (isset($metrics['recall'])) {
        echo html_writer::tag('li', get_string('metrics_recall', 'block_studentperformancepredictor') . ': ' . 
            round($metrics['recall'] * 100, 2) . '%', ['class' => 'list-group-item']);
    }
    if (isset($metrics['f1'])) {
        echo html_writer::tag('li', get_string('metrics_f1', 'block_studentperformancepredictor') . ': ' . 
            round($metrics['f1'] * 100, 2) . '%', ['class' => 'list-group-item']);
    }
    if (isset($metrics['roc_auc'])) {
        echo html_writer::tag('li', get_string('metrics_roc_auc', 'block_studentperformancepredictor') . ': ' . 
            round($metrics['roc_auc'], 3), ['class' => 'list-group-item']);
    }
    if (isset($metrics['overfitting_ratio'])) {
        echo html_writer::tag('li', get_string('metrics_overfitting_ratio', 'block_studentperformancepredictor') . ': ' . 
            round($metrics['overfitting_ratio'], 2), 
            ['class' => 'list-group-item' . ($metrics['overfitting_warning'] ? ' list-group-item-warning' : '')]);
    }

    echo html_writer::end_tag('ul');

    // Display feature importance if available
    if (isset($metrics['top_features']) && !empty($metrics['top_features'])) {
        echo html_writer::tag('h5', get_string('topfeatures', 'block_studentperformancepredictor'), ['class' => 'mt-4']);

        echo html_writer::start_tag('ul', ['class' => 'list-group']);
        foreach ($metrics['top_features'] as $feature => $importance) {
            echo html_writer::tag('li', 
                $feature . ': ' . round($importance * 100, 2) . '%', 
                ['class' => 'list-group-item']);
        }
        echo html_writer::end_tag('ul');
    }

    echo html_writer::end_div();
}

// Show error message if model training failed
if ($model->trainstatus == 'failed' && !empty($model->errormessage)) {
    echo $OUTPUT->notification($model->errormessage, 'error');
}

// Actions
echo html_writer::start_div('mt-4');
if (!$model->active) {
    echo html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/admin/activatemodel.php', 
            ['modelid' => $model->id, 'courseid' => $courseid, 'sesskey' => sesskey()]),
        get_string('activate', 'block_studentperformancepredictor'),
        ['class' => 'btn btn-primary']
    );
} else {
    echo html_writer::link(
        new moodle_url('/blocks/studentperformancepredictor/admin/activatemodel.php', 
            ['deactivate' => 1, 'courseid' => $courseid, 'sesskey' => sesskey()]),
        get_string('deactivate', 'block_studentperformancepredictor'),
        ['class' => 'btn btn-secondary']
    );
}

echo ' ';
echo html_writer::link(
    new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]),
    get_string('back', 'core'),
    ['class' => 'btn btn-secondary']
);
echo html_writer::end_div();

// Footer
echo $OUTPUT->footer();