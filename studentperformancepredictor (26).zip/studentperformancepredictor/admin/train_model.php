<?php
// blocks/studentperformancepredictor/admin/train_model.php

// Basic Moodle config
require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/moodlelib.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

use block_studentperformancepredictor\analytics\training_manager;

// Get and validate parameters
$courseid = required_param('courseid', PARAM_INT);
$datasetid = required_param('datasetid', PARAM_INT);
$algorithm = optional_param('algorithm', null, PARAM_ALPHANUMEXT);

// Security checks first
require_login();
require_sesskey();

// Determine redirect URL based on course
$redirect_url = ($courseid == 0) 
    ? new moodle_url('/blocks/studentperformancepredictor/admin/trainglobalmodel.php')
    : new moodle_url('/blocks/studentperformancepredictor/admin/managemodels.php', ['courseid' => $courseid]);

// Set up page and context
if ($courseid == 0) {
    // Global model - need site admin permission
    admin_externalpage_setup('blocksettingstudentperformancepredictor');
    require_capability('moodle/site:config', context_system::instance());

    // Set up URL
    $url = new moodle_url('/blocks/studentperformancepredictor/admin/train_model.php', ['courseid' => 0]);
    $PAGE->set_url($url);
    $PAGE->set_context(context_system::instance());

    // Check if global models are enabled
    if (!get_config('block_studentperformancepredictor', 'enableglobalmodel')) {
        \core\notification::add(
            get_string('globalmodeldisabled', 'block_studentperformancepredictor'),
            \core\notification::ERROR
        );
        redirect($redirect_url);
    }

    // Set up page title for global model
    $PAGE->set_title(get_string('trainglobalmodel', 'block_studentperformancepredictor'));
    $PAGE->set_heading(get_string('trainglobalmodel', 'block_studentperformancepredictor'));
    $PAGE->set_pagelayout('admin');

    // Verify dataset exists (for global model it can be from any course)
    if (!$DB->record_exists('block_spp_datasets', ['id' => $datasetid])) {
        \core\notification::add(
            get_string('dataset_not_found', 'block_studentperformancepredictor'),
            \core\notification::ERROR
        );
        redirect($redirect_url);
    }
} else {
    // Course-specific model
    $course = get_course($courseid);
    $coursecontext = context_course::instance($courseid);

    // Check capability and require login with the course
    require_login($course);
    require_capability('block/studentperformancepredictor:managemodels', $coursecontext);

    // Set up page with the course context
    $url = new moodle_url('/blocks/studentperformancepredictor/admin/train_model.php', ['courseid' => $courseid]);
    $PAGE->set_url($url);
    $PAGE->set_context($coursecontext);

    // Set up page title
    $PAGE->set_title($course->shortname . ': ' . get_string('training_model', 'block_studentperformancepredictor'));
    $PAGE->set_heading($course->fullname);

    // Verify dataset exists and belongs to the course
    if (!$DB->record_exists('block_spp_datasets', ['id' => $datasetid, 'courseid' => $courseid])) {
        \core\notification::add(
            get_string('dataset_not_found', 'block_studentperformancepredictor'),
            \core\notification::ERROR
        );
        redirect($redirect_url);
    }
}

// Check for pending training
if (training_manager::has_pending_training($courseid)) {
    \core\notification::add(
        get_string('training_already_scheduled', 'block_studentperformancepredictor'),
        \core\notification::WARNING
    );
    redirect($redirect_url);
}

// Schedule training (backend-driven orchestration)
$success = false;
$error_message = '';

try {
    // This will queue a training task that calls the Python backend /train endpoint
    $success = training_manager::schedule_training($courseid, $datasetid, $algorithm);
    if (!$success) {
        $error_message = get_string('trainingschedulefailed', 'block_studentperformancepredictor');
    }
} catch (\Exception $e) {
    $success = false;
    $error_message = $e->getMessage();
}

// Add appropriate notification - we will store this in session before redirecting
if ($success) {
    \core\notification::success(get_string('model_training_queued_backend', 'block_studentperformancepredictor'));
} else {
    \core\notification::error($error_message);
}

// Redirect back to appropriate page
redirect($redirect_url);