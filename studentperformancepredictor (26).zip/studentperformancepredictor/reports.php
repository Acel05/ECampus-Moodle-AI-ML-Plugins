<?php
// blocks/studentperformancepredictor/reports.php

require_once('../../config.php');
require_once($CFG->dirroot . '/blocks/studentperformancepredictor/lib.php');

// Get parameters
$courseid = optional_param('courseid', 0, PARAM_INT);
$id = optional_param('id', 0, PARAM_INT); // For backward compatibility
$admin = optional_param('admin', 0, PARAM_BOOL);

// If id is provided but courseid is not, use id as courseid
if ($id > 0 && $courseid == 0) {
    $courseid = $id;
}

// Set up page
if ($admin) {
    // Admin view - either all courses or filtered by course
    require_login();
    require_capability('moodle/site:config', context_system::instance());

    $PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/reports.php', array('admin' => 1, 'courseid' => $courseid)));
    $PAGE->set_context(context_system::instance());
    $PAGE->set_title(get_string('adminreport', 'block_studentperformancepredictor'));
    $PAGE->set_heading(get_string('adminreport', 'block_studentperformancepredictor'));
    $PAGE->set_pagelayout('admin');

    // Output starts here
    echo $OUTPUT->header();

    // Show admin view
    $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
    $adminview = new \block_studentperformancepredictor\output\admin_view(0, $courseid); // 0 = sitewide, with optional filter
    echo $renderer->render_admin_view($adminview);

} else {
    // Teacher view - specific course
    if (empty($courseid)) {
        // If no courseid specified, check if the user teaches any courses
        $teachercourses = [];
        $allcourses = get_courses();
        foreach ($allcourses as $course) {
            if ($course->id == SITEID) {
                continue;
            }
            $coursecontext = context_course::instance($course->id);
            if (has_capability('block/studentperformancepredictor:viewallpredictions', $coursecontext)) {
                $teachercourses[$course->id] = $course;
            }
        }

        if (count($teachercourses) == 1) {
            // If the user teaches only one course, redirect directly to that course
            $course = reset($teachercourses);
            redirect(new moodle_url('/blocks/studentperformancepredictor/reports.php', ['courseid' => $course->id]));
        } elseif (count($teachercourses) > 1) {
            // If the user teaches multiple courses, show a course selection page
            $PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/reports.php'));
            $PAGE->set_context(context_system::instance());
            $PAGE->set_title(get_string('selectcourse', 'block_studentperformancepredictor'));
            $PAGE->set_heading(get_string('selectcourse', 'block_studentperformancepredictor'));
            $PAGE->set_pagelayout('standard');

            echo $OUTPUT->header();
            echo $OUTPUT->heading(get_string('selectcourse', 'block_studentperformancepredictor'));

            // Display course selection table
            $table = new html_table();
            $table->head = [
                get_string('coursename', 'block_studentperformancepredictor'),
                get_string('actions', 'block_studentperformancepredictor')
            ];
            $table->data = [];

            foreach ($teachercourses as $course) {
                $row = [];
                $row[] = format_string($course->fullname);
                $row[] = html_writer::link(
                    new moodle_url('/blocks/studentperformancepredictor/reports.php', ['courseid' => $course->id]),
                    get_string('viewdetails', 'block_studentperformancepredictor'),
                    ['class' => 'btn btn-primary btn-sm']
                );
                $table->data[] = $row;
            }

            echo html_writer::table($table);
            echo $OUTPUT->footer();
            exit;
        } else {
            // No courses found where the user is a teacher
            throw new moodle_exception('nocoursesfound', 'block_studentperformancepredictor');
        }
    }

    $course = get_course($courseid);
    $context = context_course::instance($courseid);

    // Check permissions
    require_login($course);
    require_capability('block/studentperformancepredictor:viewallpredictions', $context);

    // Set up page layout
    $PAGE->set_url(new moodle_url('/blocks/studentperformancepredictor/reports.php', array('courseid' => $courseid)));
    $PAGE->set_context($context);
    $PAGE->set_title(get_string('detailedreport', 'block_studentperformancepredictor'));
    $PAGE->set_heading(format_string($course->fullname));
    $PAGE->set_pagelayout('standard');

    // Output starts here
    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('detailedreport', 'block_studentperformancepredictor'));

    // Check if there's an active model
    if (!block_studentperformancepredictor_has_active_model($courseid)) {
        echo $OUTPUT->notification(get_string('noactivemodel', 'block_studentperformancepredictor'), 'warning');
        echo html_writer::link(
            new moodle_url('/course/view.php', array('id' => $courseid)),
            get_string('backtocourse', 'block_studentperformancepredictor'),
            array('class' => 'btn btn-secondary')
        );
        echo $OUTPUT->footer();
        exit;
    }

    // Show teacher view
    $renderer = $PAGE->get_renderer('block_studentperformancepredictor');
    $teacherview = new \block_studentperformancepredictor\output\teacher_view($courseid);
    echo $renderer->render_teacher_view($teacherview);
}

// Add a "Back" button
if ($admin) {
    echo html_writer::div(
        html_writer::link(
            new moodle_url('/admin/settings.php', ['section' => 'blocksettingstudentperformancepredictor']),
            get_string('backsettings', 'block_studentperformancepredictor'),
            ['class' => 'btn btn-secondary']
        ),
        'mt-3'
    );
} else {
    echo html_writer::div(
        html_writer::link(
            new moodle_url('/course/view.php', array('id' => $courseid)),
            get_string('backtocourse', 'block_studentperformancepredictor'),
            array('class' => 'btn btn-secondary')
        ),
        'mt-3'
    );
}

// Output footer
echo $OUTPUT->footer();